import subprocess
import time
time.sleep(30)
while 1:
    time.sleep(60)
    subprocess.run(["condor_q", "-bet"])
    subprocess.run(["pegasus-status", "submitdir/work/"])
    out = subprocess.check_output(["pegasus-status", "submitdir/work/"])
    out = str(out)
    lines = out.split('\\n')

    for linei in lines:
        if linei.startswith('Summary') and '(Failure' in linei:
            print('Job submission has failed')
            exit(1)

    for i in range(len(lines)):
        if 'UNREADY' in lines[i]:
            status_line = i + 1
            break
    else:
        raise RuntimeError(
            'No UNREADY line found in pegasus-status output, check logs'
        )

    stats = lines[status_line].split(' ')
    stats = [s for s in stats if s != '']

    unready = int(stats[0])
    ready = int(stats[1])
    pre = int(stats[2])
    queued = int(stats[3])
    post = int(stats[4])
    done = int(stats[5])
    failed = int(stats[6])
    pc_done = stats[7]

    finished = (unready == 0 and ready == 0 and queued == 0 and post == 0)
    passed = (finished and failed == 0) and pc_done == '100.0'

    if passed:
        print("workflow has completed successfully")
        time.sleep(30)
        exit(0)

    if failed != 0:
        print("workflow has a failed job, ending now")
        subprocess.run(["bash", "./stop"])
        # Need to wait here to make sure it fully exits before uploading logs!
        time.sleep(30)
        exit(1)
