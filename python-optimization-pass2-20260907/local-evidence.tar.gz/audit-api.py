"""Read-only independent terminal audit of the pass-two API experiment."""
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/home/xangma/pycbc-torch-python-optimization-pass2-20260907')


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT))
    os.chdir(ROOT)
    campaign = load('campaign', 'optimize-campaign.py')
    gate = load('gate', 'profile-gates.py')
    compare = load('compare', 'compare-candidate.py')
    api = load('api', 'verify-api.py')
    control = campaign.control
    status = control.read(ROOT / 'api-status.json')
    launch = control.read(ROOT / 'api-launch.json')
    assert status['state'] == 'complete' and status['finished']
    assert status['source_unchanged'] and status['child_pid'] is None
    assert status['pid'] == status['pgid'] == launch['pid'] == launch['pgid']
    groups = {status['pid'], status['pgid']}
    groups.add(control.read(ROOT / 'source-staging-launch.json')['pid'])
    stages = {}
    for path in (ROOT / 'stages').glob('*.json'):
        stage = control.read(path)
        assert stage['state'] == 'complete' and stage['returncode'] == 0
        groups.update((stage['pid'], stage['pgid']))
        stages[path.name] = control.digest(path)
    active = [p for p in gate.process_table() if p['pid'] in groups or p['pgid'] in groups]
    assert not active, active
    with campaign.LOCK.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        pins = campaign.pins()
        release = campaign.gates()
        assert status['helper_sha256'] == pins
        before = control.read(ROOT / 'api-before.json')
        after = control.read(ROOT / 'api-after.json')
        compare.validate_window(before, after)
        fresh = compare.take_snapshot(ROOT / 'source-baseline', ROOT / 'source-candidate')
        compare.validate_window(after, fresh)
        summary = control.read(ROOT / 'api-summary.json')
        assert status['result_sha256'] == control.digest(ROOT / 'api-summary.json')
        assert api.summarize(before, after, pins) == summary
        previous = before['finished_at']
        for role, repeat in api.ORDER:
            stage = control.read(ROOT / 'stages' / f'api-{role}-r{repeat}.json')
            assert previous <= stage['started'] <= stage['finished']
            previous = stage['finished']
        assert previous <= after['started_at']
        result = dict(state='validated-complete', utc=time.time(),
                      host=status['host'], cwd=str(ROOT),
                      api_status_sha256=control.digest(ROOT / 'api-status.json'),
                      api_summary_sha256=control.digest(ROOT / 'api-summary.json'),
                      source_staging_sha256=control.digest(ROOT / 'source-staging.json'),
                      helper_manifest_sha256=control.digest(ROOT / 'staged-helpers.json'),
                      owned_groups=sorted(groups), active_owned_processes=active,
                      independent_lock_reacquired=True, all_pins_unchanged=True,
                      profile_release_sha256=release['release_sha256'],
                      stages=stages, evidence_sha256=summary['evidence_sha256'],
                      workers=summary['workers'], cells=len(summary['cells']),
                      all_raw_cells=summary['workers'] * len(summary['cells']),
                      all_bitwise_parity=all(x['exact_parity'] for x in summary['cells']),
                      source_snapshot=fresh)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    raise SystemExit(main())
