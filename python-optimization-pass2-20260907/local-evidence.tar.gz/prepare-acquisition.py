"""Prepare a new local bundle; no network operations or remote execution."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OLD = Path('/Users/xangma/repos/pycbc/artifacts/torch-python-optimization-r4-20260907')
PROFILE = Path('/Users/xangma/repos/pycbc/artifacts/torch-profiling-20260907-r3/acquisition')
SOURCE = Path('/private/tmp/pycbc-torch-python-optimization-pass2-20260907')
DEST = ROOT / 'acquisition'
BASE = 'd2647addb884ead3249914ebc980f3c132076d93'
CANDIDATE = 'af4f0bd598ec1e2d7c6ce702d6c05850d7871039'
OLD_BASE = '9578a710479b924e882857c4dffab6ed372a634b'
OLD_CANDIDATE = '9e6a688a5190d6e1ddc655fbe352cc206085d5c6'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])


def main():
    assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
    assert not git('status', '--porcelain')
    DEST.mkdir(exist_ok=False)
    manifest = json.loads((OLD / 'transfer-manifest.json').read_text())
    originals = {}
    for path in sorted((OLD / 'acquisition').iterdir()):
        if (path.is_file() and path.name in manifest
                and path.name not in ('profile-release.json', 'staged-helpers.json')):
            data = path.read_bytes()
            assert sha(data) == manifest[path.name]
            (DEST / path.name).write_bytes(data)
            originals[path.name] = sha(data)
    assert len(originals) == 23
    for name in ['stage-sources.py']:
        data = (OLD / name).read_bytes()
        assert sha(data) == manifest[name]
        (DEST / name).write_bytes(data)
        originals[name] = sha(data)
    data = (PROFILE / 'predecessor-pins.json').read_bytes()
    (DEST / 'predecessor-pins.json').write_bytes(data)
    originals['predecessor-pins.json'] = sha(data)
    baseline = git('show', BASE + ':pycbc/types/array_torch.py')
    candidate = (SOURCE / 'pycbc/types/array_torch.py').read_bytes()
    patch = git('diff', '--no-ext-diff', '--no-textconv', '--binary',
                '--full-index', BASE, CANDIDATE, '--')
    (DEST / 'baseline-array-torch.py').write_bytes(baseline)
    (ROOT / 'candidate.patch').write_bytes(patch)
    assert sha(git('diff', '--binary', BASE, CANDIDATE)) == json.loads(
        (ROOT / 'candidate-validation.json').read_text())['source_after']['diff_sha256']
    native = json.loads((DEST / 'native-provenance.json').read_text())
    native.update(target_revision=BASE, candidate_revision=CANDIDATE,
                  previous_provenance_sha256=originals['native-provenance.json'])
    for entry in native['extensions']:
        entry['staged_from'] = '/home/xangma/pycbc-torch-profile-20260907-r3/source/' + entry['relative_path']
    (DEST / 'native-provenance.json').write_text(json.dumps(native, indent=2) + '\n')
    replacements = {
        OLD_BASE: BASE, OLD_CANDIDATE: CANDIDATE,
        '06c76d2bd544f9ac96fbb407356e59bb7ef675a1edc47860f9470cf0e92f3b09': sha(patch),
        '165dab77054c0657aafcd315c3c9b7026f15fd41dcc8e9ae0fd40cc266998626': sha(baseline),
        'bde2a213bc135fd3f2ee2d1414ffbbf0a2aaa4da72ec722f9fab94eed37102d5': sha(candidate),
        originals['native-provenance.json']: sha((DEST / 'native-provenance.json').read_bytes()),
    }
    path = DEST / 'compare-candidate.py'
    text = path.read_text()
    # Replace simultaneously: the old candidate module is the new baseline.
    import re
    text = re.sub('|'.join(map(re.escape, replacements)),
                  lambda match: replacements[match[0]], text)
    path.write_text(text)
    path = DEST / 'benchmark-squared-norm.py'
    path.write_text(path.read_text().replace(OLD_BASE, BASE))
    path = DEST / 'stage-sources.py'
    path.write_text(path.read_text().replace('torch-python-optimization-r4-20260907',
                                            'torch-python-optimization-pass2-20260907'))
    bundle = DEST / 'source-candidate.bundle'
    git('bundle', 'create', str(bundle),
        'refs/heads/codex/torch-python-optimization-pass2-20260907', '^' + BASE)
    git('bundle', 'verify', str(bundle))
    lineage = dict(baseline=BASE, candidate=CANDIDATE, source=str(SOURCE),
                   changed_files=git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines(),
                   exact_full_index_patch_sha256=sha(patch),
                   module_sha256={'baseline': sha(baseline), 'candidate': sha(candidate)},
                   executable_sha256=sha((SOURCE / 'bin/pycbc_inspiral').read_bytes()),
                   bundle_sha256=sha(bundle.read_bytes()), copied_original_sha256=originals,
                   state='LOCAL DRAFT: profiler gates/release/manifest still need preparation')
    (ROOT / 'candidate-lineage.json').write_text(json.dumps(lineage, indent=2) + '\n')
    print(json.dumps(lineage, indent=2))


if __name__ == '__main__':
    main()
