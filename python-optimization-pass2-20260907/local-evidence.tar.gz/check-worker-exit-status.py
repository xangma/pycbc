"""Exercise the actual validation entry point with controlled pytest outcomes."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/pycbc-torch-python-optimization-pass2-20260907')
DRIVER = ROOT / 'validate-candidate.py'


def main():
    results = []
    with tempfile.TemporaryDirectory(prefix='pycbc-worker-exit-') as directory:
        for expected in (1, 0):
            test = Path(directory) / 'test_control.py'
            test.write_text('def test_control():\n    assert ' + str(expected == 0) + '\n')
            code = """
import runpy, sys
import pytest
original = pytest.main
test, driver = sys.argv[1:]
pytest.main = lambda args: original(['-q', '--tb=short', test])
sys.argv = [driver, 'candidate-focused']
runpy.run_path(driver, run_name='__main__')
"""
            command = [sys.executable, '-c', code, str(test), str(DRIVER)]
            environment = dict(os.environ, PYTHONPATH=str(SOURCE),
                               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                               MKL_NUM_THREADS='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
            log = ROOT / f'worker-exit-control-{expected}.log'
            with log.open('x') as stream:
                child = subprocess.Popen(command, cwd=SOURCE, env=environment,
                                         stdout=stream, stderr=subprocess.STDOUT,
                                         start_new_session=True)
                try:
                    actual = child.wait(timeout=45)
                finally:
                    if child.poll() is None:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
            results.append(dict(expected=expected, actual=actual, pid=child.pid,
                                pgid=child.pid, log=str(log),
                                log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
            assert actual == expected, results[-1]
    record = dict(state='complete', finished=time.time(),
                  driver_sha256=hashlib.sha256(DRIVER.read_bytes()).hexdigest(),
                  acquired_driver_sha256=hashlib.sha256(
                      (ROOT / 'validate-candidate-acquired.py').read_bytes()).hexdigest(),
                  runs=results)
    (ROOT / 'worker-exit-control.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


if __name__ == '__main__':
    raise SystemExit(main())
