"""Local exploratory guard/public-API diagnostics; never edit runtime source."""
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import sys
import time
import timeit

import numpy as np
import torch

from pycbc import scheme
from pycbc.types import Array, array_torch


ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/pycbc-torch-python-optimization-pass2-20260907')


def guard_current(tensor):
    return (type(tensor) is torch.Tensor and tensor.device.type == 'cpu'
            and tensor.numel() >= 4096 and not tensor.is_conj())


def guard_size_first(tensor):
    return (type(tensor) is torch.Tensor and tensor.numel() >= 4096
            and tensor.device.type == 'cpu' and not tensor.is_conj())


def guard_direct_cpu(tensor):
    return (type(tensor) is torch.Tensor and tensor.is_cpu
            and tensor.numel() >= 4096 and not tensor.is_conj())


def guard_size_first_direct_cpu(tensor):
    return (type(tensor) is torch.Tensor and tensor.numel() >= 4096
            and tensor.is_cpu and not tensor.is_conj())


def main():
    assert Path(array_torch.__file__).resolve() == SOURCE / 'pycbc/types/array_torch.py'
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    source = Path(array_torch.__file__).read_bytes()
    functions = {}
    guards = [guard_current, guard_size_first, guard_direct_cpu,
              guard_size_first_direct_cpu]
    for guard in guards:
        node = next(n for n in ast.parse(source).body
                    if isinstance(n, ast.FunctionDef) and n.name == 'squared_norm')
        guard_node = next(n for n in ast.parse(Path(__file__).read_text()).body
                          if isinstance(n, ast.FunctionDef) and n.name == guard.__name__)
        node.body[1].body[0].test = guard_node.body[0].value
        namespace = dict(vars(array_torch))
        exec(compile(ast.fix_missing_locations(ast.Module(
            body=[node], type_ignores=[])), '<local-provisional-guard>', 'exec'), namespace)
        functions[guard.__name__] = namespace['squared_norm']
    baseline = array_torch.squared_norm
    records = dict(
        scope=('Exploratory local guard and public Array.squared_norm costs. '
               'One worker; variants rotated within samples. Not accepted '
               'paired fresh-worker evidence or executable measurements.'),
        baseline='d2647addb884ead3249914ebc980f3c132076d93',
        source_sha256=hashlib.sha256(source).hexdigest(),
        harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        host=platform.node(), platform=platform.platform(), python=sys.version,
        torch=torch.__version__, numpy=np.__version__, pid=os.getpid(),
        torch_threads=torch.get_num_threads(), guard_cells=[], api_cells=[])
    for size in [16, 4095, 4096, 131072]:
        tensor = torch.ones(size, dtype=torch.complex64)
        expected = guard_current(tensor)
        for guard in guards:
            assert guard(tensor) == expected
            samples = timeit.repeat(lambda: guard(tensor), repeat=7, number=10000)
            records['guard_cells'].append(dict(
                size=size, variant=guard.__name__,
                nanoseconds_per_call=[sample * 1e5 for sample in samples],
                median_ns=statistics.median(samples) * 1e5))
    context = scheme.TorchScheme('cpu', num_threads=1)
    try:
        with context:
            for dtype in [torch.complex64, torch.complex128]:
                for size, stride in [(16, 1), (4095, 1), (4096, 1),
                                     (131072, 1), (4096, 3)]:
                    generator = torch.Generator().manual_seed(2017)
                    tensor = torch.randn(size * stride + 1, generator=generator,
                                         dtype=dtype)[1::stride]
                    original = tensor.clone()
                    array = Array(array_torch.TorchArrayData(tensor), copy=False)
                    expected = baseline(array).tensor
                    samples = {name: [] for name in functions}
                    for repeat in range(7):
                        order = list(functions)
                        if repeat % 2:
                            order.reverse()
                        for name in order:
                            array_torch.squared_norm = functions[name]
                            scheme._import_cache.clear()
                            for _ in range(5):
                                actual = array.squared_norm()._data.tensor
                            integer = torch.int32 if dtype == torch.complex64 else torch.int64
                            assert torch.equal(actual.view(integer), expected.view(integer))
                            start = time.perf_counter_ns()
                            for _ in range(100):
                                array.squared_norm()
                            samples[name].append((time.perf_counter_ns() - start) / 100)
                    assert torch.equal(tensor, original)
                    records['api_cells'].append(dict(
                        dtype=str(dtype), size=size, stride=stride,
                        nanoseconds_per_call=samples,
                        medians_ns={name: statistics.median(values)
                                    for name, values in samples.items()},
                        bitwise_parity=True, input_unchanged=True))
    finally:
        array_torch.squared_norm = baseline
        scheme._import_cache.clear()
        del context
        scheme.Scheme._single = None
    assert Path(array_torch.__file__).read_bytes() == source
    with (ROOT / 'dispatch-probe.json').open('x') as output:
        output.write(json.dumps(records, indent=2) + '\n')
    for row in records['guard_cells']:
        print('guard', row['size'], row['variant'], round(row['median_ns'], 1))
    for row in records['api_cells']:
        print('api', row['dtype'], row['size'], row['stride'],
              {name: round(value, 1) for name, value in row['medians_ns'].items()})


if __name__ == '__main__':
    main()
