#!/usr/bin/env python3
"""Two bounded, separately reviewed phases on shared len; fresh outputs only."""
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import threading
import time

import campaign_controls as control


ROOT = Path(__file__).resolve().parent
PROFILE = Path('/home/xangma/pycbc-torch-profile-20260907-r3')
PROFILE_PID = 1591583
PROFILER = '01a07ac4-9675-7983-9923-90de72db82d5'
OWNER = '01a079bf-abfd-7cd2-bd6a-3893ab4f0d53'
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
BOUNDS = {'api': (900, 180), 'executable': (10800, 900)}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pins():
    value = control.read(ROOT / 'staged-helpers.json')
    required = {'optimize-campaign.py', 'api-worker.py', 'verify-api.py',
                'campaign_controls.py', 'profile-gates.py', 'compare-candidate.py',
                'benchmark-squared-norm.py', 'baseline-array-torch.py',
                'test_lock_lifecycle.py', 'threadpoolctl-provenance.json',
                'predecessor-pins.json', 'test_optimize_campaign.py',
                'test_compare_candidate.py', 'test_checked_inspiral.py',
                'test_run_case_verified.py'}
    compare = load('candidate_comparator', 'compare-candidate.py')
    required.update(compare.HELPERS)
    if not required <= value.keys() or any(Path(name).name != name for name in value):
        raise ValueError('Incomplete or invalid staged helper manifest')
    if value != {name: control.digest(ROOT / name) for name in value}:
        raise ValueError('Staged helper bytes changed')
    compare.trusted_helpers()
    if value['baseline-array-torch.py'] != compare.MODULE_SHA['baseline']:
        raise ValueError('Frozen baseline module differs')
    return value


def gates():
    if PROFILE_PID <= 0:
        raise ValueError('Profiler acquisition PID has not yet been pinned')
    helper = load('profile_gates', 'profile-gates.py')
    predecessors = helper.check_all_predecessors()
    status = control.read(PROFILE / 'profile-status.json')
    groups = {PROFILE_PID}
    for path in (PROFILE / 'stages').glob('*.json'):
        receipt = control.read(path)
        groups.update(receipt.get(k) for k in ('pid', 'pgid'))
    helper.validate_predecessor(status, PROFILE_PID, helper.process_table(), groups)
    if (status.get('science_parity') != 'pass' or status.get('native_trace') != 'captured'
            or status.get('source_unchanged') is not True
            or status.get('qualifications_passed') != 3
            or status.get('timing_workers') != 9):
        raise ValueError('Profiler did not satisfy its final acquisition gates')
    lifecycle_sha = {}
    for name in ('runner-self-test', 'runtime-self-test', 'comparator-self-test'):
        path = PROFILE / 'stages' / (name + '.json')
        lifecycle = control.read(path)
        if lifecycle.get('state') != 'complete' or lifecycle.get('returncode') != 0:
            raise ValueError('Profiler Linux self-tests did not pass: ' + name)
        lifecycle_sha[name] = control.digest(path)
    release_path = ROOT / 'profile-release.json'
    release = control.read(release_path)
    audit_path = PROFILE / 'terminal-audit.json'
    audit = control.read(audit_path)
    if (release.get('profile_root') != str(PROFILE) or release.get('profile_pid') != PROFILE_PID
            or release.get('released_by_thread') != PROFILER
            or not release.get('message') or not release.get('release_received_utc')
            or release.get('profile_status_sha256') != control.digest(PROFILE / 'profile-status.json')
            or release.get('profile_terminal_audit_sha256') != control.digest(audit_path)):
        raise ValueError('Missing explicit, verified profiling-task release')
    if (audit.get('state') != 'validated-complete'
            or audit.get('profile_status_sha256') != release['profile_status_sha256']
            or audit.get('active_owned_processes') != []
            or audit.get('independent_lock_reacquired') is not True
            or audit.get('all_pins_unchanged') is not True
            or audit.get('timing_workers') != 9
            or audit.get('source') != dict(path=str(helper.SOURCE),
                                          commit=helper.REVISION, status='')):
        raise ValueError('Profiler terminal audit does not establish a clean release')
    for name, digest in audit['stages'].items():
        if Path(name).name != name or control.digest(PROFILE / 'stages' / name) != digest:
            raise ValueError('Profiler audited stage changed')
    export = PROFILE.with_name(PROFILE.name + '-export')
    final_path = export / 'release-audit.json'
    final = control.read(final_path)
    if (release.get('profile_release_audit_sha256') != control.digest(final_path)
            or final.get('state') != 'validated-release'
            or final.get('profile_status_sha256') != release['profile_status_sha256']
            or final.get('terminal_audit_sha256') != release['profile_terminal_audit_sha256']
            or final.get('export_status_sha256') != control.digest(export / 'export-status.json')
            or final.get('archive_stage_sha256') != control.digest(export / 'stages/archive.json')
            or final.get('active_owned_processes') != []
            or final.get('independent_lock_reacquired') is not True
            or final.get('source_unchanged') is not True
            or final.get('all_source_native_input_helper_pins_unchanged') is not True):
        raise ValueError('Profiler export and final release audit failed')
    if any(p['pid'] in final['owned_groups'] or p['pgid'] in final['owned_groups']
           for p in helper.process_table()):
        raise ValueError('Profiler science/export process groups remain active')
    return dict(predecessors=predecessors, profiler=status, release=release,
                release_sha256=control.digest(release_path),
                lifecycle_sha256=lifecycle_sha, terminal_audit_sha256=control.digest(audit_path),
                final_release_audit_sha256=control.digest(final_path))


def api_review():
    status = control.read(ROOT / 'api-status.json')
    if status.get('state') != 'complete' or not status.get('finished'):
        raise ValueError('API phase has not completed successfully')
    helper = load('profile_gates', 'profile-gates.py')
    if any(p['pid'] == status['pid'] or p['pgid'] == status['pgid']
           for p in helper.process_table()):
        raise ValueError('API supervisor or its group remains active')
    for path in (ROOT / 'stages').glob('*.json'):
        receipt = control.read(path)
        if receipt.get('pgid') and control.active_group(receipt['pgid']):
            raise ValueError('An earlier optimization process group remains active')
    review = control.read(ROOT / 'api-review.json')
    compare = load('candidate_comparator', 'compare-candidate.py')
    summary = control.read(ROOT / 'api-summary.json')
    if (status.get('helper_sha256') != pins() or
            status.get('result_sha256') != control.digest(ROOT / 'api-summary.json') or
            any(control.digest(path) != sha for path, sha in summary['evidence_sha256'].items())):
        raise ValueError('API evidence or helpers changed after phase completion')
    if (review.get('decision') != 'proceed' or review.get('reviewed_by_thread') != OWNER
            or review.get('candidate_revision') != compare.CANDIDATE
            or review.get('api_summary_sha256') != control.digest(ROOT / 'api-summary.json')
            or not review.get('cutoff_assessment') or not review.get('reviewed_utc')):
        raise ValueError('API results/cutoff require explicit primary-agent assessment')
    return review


class Campaign(control.Campaign):
    def __init__(self, phase):
        super().__init__(ROOT, timeout=BOUNDS[phase][1])
        self.phase = phase

    def update(self, **values):
        self.state.update(values)
        control.save(ROOT / (self.phase + '-status.json'), self.state)

    def observe(self):
        with (ROOT / (self.phase + '-host-samples.jsonl')).open('x') as stream:
            while not self.stop.is_set():
                value = dict(utc=time.time(), monotonic_ns=time.monotonic_ns(),
                             current=self.state.get('current'), child_pid=self.state.get('child_pid'))
                for name in ('stat', 'loadavg', 'meminfo'):
                    value['proc_' + name] = Path('/proc', name).read_text()
                try:
                    value['processes'] = subprocess.check_output(
                        ['ps', '-eo', 'pid,ppid,psr,nlwp,pcpu,pmem,comm', '--sort=-pcpu'],
                        text=True, timeout=3, stderr=subprocess.DEVNULL)
                except (OSError, subprocess.SubprocessError) as error:
                    value['processes_error'] = repr(error)
                stream.write(json.dumps(value) + '\n')
                stream.flush()
                self.stop.wait(5)

    def snapshot(self, suffix, baseline, candidate):
        compare = load('candidate_comparator', 'compare-candidate.py')
        value = compare.take_snapshot(baseline, candidate)
        compare.save(ROOT / (self.phase + '-' + suffix + '.json'), value)
        return value

    def case(self, name, mode, source):
        compare = load('candidate_comparator', 'compare-candidate.py')
        self.stage(name, [sys.executable, ROOT / 'run-case-verified.py', '--config',
                         ROOT / 'config.json', '--case', name, '--mode', mode,
                         '--scheme', 'torch:cpu:1', '--source', source, '--bank', compare.BANK,
                         '--segment-length', '512', '--start-pad', '112', '--end-pad', '16'])
        return ROOT / 'runs' / name

    def cross(self, name, base, candidate, after):
        self.stage(name, [sys.executable, ROOT / 'compare-candidate.py', 'compare',
                         '--baseline', base / 'triggers.hdf', '--candidate',
                         candidate / 'triggers.hdf', '--before',
                         ROOT / 'executable-before.json', '--after', after,
                         '--output', ROOT / name])
        result = control.read(ROOT / name / 'cross-revision-comparison.json')
        if result.get('status') != 'pass':
            raise ValueError('Cross-revision science did not pass')


def api_phase(campaign, baseline, candidate, manifest, before):
    api = load('verify_api', 'verify-api.py')
    campaign.stage('optimization-lock-self-test', [sys.executable, '-m', 'pytest', '-q',
                   '-rA', ROOT / 'test_lock_lifecycle.py', ROOT / 'test_optimize_campaign.py',
                   ROOT / 'test_compare_candidate.py', ROOT / 'test_checked_inspiral.py',
                   ROOT / 'test_run_case_verified.py'])
    campaign.stage('threadpoolctl-compatibility', [sys.executable, ROOT / 'optimize-campaign.py',
                                                '--compatibility-check'])
    for role, repeat in api.ORDER:
        campaign.stage(f'api-{role}-r{repeat}', ['taskset', '-c', '8', sys.executable,
                       ROOT / 'api-worker.py', '--source', candidate,
                       '--variant', role, '--repeat', str(repeat)])
    after = campaign.snapshot('after', baseline, candidate)
    control.save(ROOT / 'api-summary.json', api.summarize(before, after, manifest))


def executable_phase(campaign, baseline, candidate, before):
    compare = load('candidate_comparator', 'compare-candidate.py')
    api = load('verify_api', 'verify-api.py')
    sources = dict(baseline=baseline, candidate=candidate)
    qualified, qualifications, timed = {}, {}, {'baseline': [], 'candidate': []}
    bank_hash = compare.INPUTS[compare.BANK]
    for role, source in sources.items():
        qualified[role] = campaign.case('qualify-' + role, 'qualify', source)
        qualifications[role] = control.qualify(qualified[role] / 'qualification.json', 384, bank_hash)
    campaign.snapshot('after-qualification', baseline, candidate)
    campaign.cross('qualification-parity', qualified['baseline'], qualified['candidate'],
                   ROOT / 'executable-after-qualification.json')
    for role, repeat in api.ORDER:
        timed[role].append(campaign.case(f'{role}-r{repeat}', 'timing', sources[role]))
    after = campaign.snapshot('after', baseline, candidate)
    compare.validate_window(before, after)
    runtimes, metrics = [], {'baseline': [], 'candidate': []}
    for role in sources:
        for folder in [qualified[role], *timed[role]]:
            runtimes.append(compare.validate_receipt(control.read(folder / 'receipt.json'),
                                                     role, before, after))
        if campaign.compare(role + '-repeat-parity', qualified[role] / 'triggers.hdf',
                            [p / 'triggers.hdf' for p in timed[role]]) != 'pass':
            raise ValueError('Same-source repeat science did not pass')
        metrics[role] = [control.timing(folder, 384, compare.REVISIONS[role], bank_hash,
                                       qualifications[role]) for folder in timed[role]]
    if len({r['pid'] for r in runtimes}) != 8:
        raise ValueError('Executable workers are not eight fresh processes')
    for key in ('torch_version', 'torch_cuda_version'):
        if len({r[key] for r in runtimes}) != 1:
            raise ValueError('Executable runtime versions differ')
    for repeat in (1, 2, 3):
        campaign.cross(f'timing-parity-r{repeat}', ROOT / 'runs' / f'baseline-r{repeat}',
                       ROOT / 'runs' / f'candidate-r{repeat}', ROOT / 'executable-after.json')
    summary = dict(scope='Shared-host finite workload: 384 templates, 1904 valid seconds; '
                        'identical startup verification included in full executable wall time',
                   science_parity='pass', metrics=metrics, full_wall={})
    for role, rows in metrics.items():
        seconds = [r['full_wall_seconds'] for r in rows]
        summary['full_wall'][role] = dict(seconds=seconds, median=statistics.median(seconds),
                                         minimum=min(seconds), maximum=max(seconds))
    summary['ratio'] = (summary['full_wall']['baseline']['median'] /
                        summary['full_wall']['candidate']['median'])
    control.save(ROOT / 'executable-summary.json', summary)


def compatibility_check():
    # Import and exercise the pinned, Python-3.11-compatible helper on len itself.
    previous = os.environ.get('KMP_DUPLICATE_LIB_OK')
    try:
        import threadpoolctl
    finally:
        if previous is None:
            os.environ.pop('KMP_DUPLICATE_LIB_OK', None)
        else:
            os.environ['KMP_DUPLICATE_LIB_OK'] = previous
    runtime = load('checked_runtime', 'checked-inspiral.py')
    actual = dict(path=str(Path(threadpoolctl.__file__).resolve()),
                  version=threadpoolctl.__version__, sha256=control.digest(threadpoolctl.__file__))
    if actual != runtime.expected_threadpoolctl() or sys.version_info[:2] != (3, 11):
        raise ValueError('Bundled native-threadpool helper is not the expected len runtime')
    print(json.dumps(dict(python=sys.version, threadpoolctl=actual,
                          threadpools=threadpoolctl.threadpool_info())))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=tuple(BOUNDS))
    parser.add_argument('--shared-host', action='store_true')
    parser.add_argument('--compatibility-check', action='store_true')
    args = parser.parse_args()
    if args.compatibility_check:
        compatibility_check()
        return
    if not args.phase or not args.shared_host or not sys.platform.startswith('linux'):
        parser.error('An explicit phase, --shared-host and Linux are required')
    compare = load('candidate_comparator', 'compare-candidate.py')
    if sys.executable != compare.PYTHON:
        raise ValueError('Run with the pinned reference venv Python')
    baseline, candidate = ROOT / 'source-baseline', ROOT / 'source-candidate'
    manifest = pins()
    gates()
    if args.phase == 'executable':
        api_review()
    # Never explicitly unlock: a surviving descendant retains this open description.
    with LOCK.open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if pins() != manifest:
            raise ValueError('Operational helpers changed while acquiring the lock')
        dependency = gates()
        review = api_review() if args.phase == 'executable' else None
        with (ROOT / (args.phase + '-started.json')).open('x') as stream:
            json.dump(dict(started=time.time(), pid=os.getpid()), stream)
        if args.phase == 'api':
            for folder in ('stages', 'runs', 'api-results', 'api-launches'):
                (ROOT / folder).mkdir(exist_ok=False)
        runtime = load('checked_runtime', 'checked-inspiral.py')
        environment = runtime.clean_environment(os.environ, control.read(ROOT / 'config.json'), candidate)
        os.environ.clear()
        os.environ.update(environment)
        os.environ['PYCBC_BENCHMARK_LOCK_FD'] = str(lock.fileno())
        campaign = Campaign(args.phase)
        interrupted = False

        def stop(signum, frame):
            nonlocal interrupted
            if not interrupted:
                interrupted = True
                if control._stop_deferrals:
                    control._pending_stop = signum
                else:
                    raise control.Cancelled(f'Received signal {signum}')

        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM):
            signal.signal(sig, stop)
        signal.setitimer(signal.ITIMER_REAL, BOUNDS[args.phase][0])
        campaign.update(phase=args.phase, lock=str(LOCK), lock_fd=lock.fileno(),
                        dependencies=dependency, api_review=review, helper_sha256=manifest,
                        total_timeout_seconds=BOUNDS[args.phase][0], next_check_seconds=60,
                        numerical_worker_core=8, smt_sibling=72)
        campaign.observer = threading.Thread(target=campaign.observe, daemon=True)
        campaign.observer.start()
        try:
            before = campaign.snapshot('before', baseline, candidate)
            if args.phase == 'api':
                api_phase(campaign, baseline, candidate, manifest, before)
            else:
                executable_phase(campaign, baseline, candidate, before)
            if pins() != manifest:
                raise ValueError('Operational helper manifest drifted during phase')
            campaign.update(state='complete', current=None, command=None, finished=time.time(),
                            source_unchanged=True, result_sha256=control.digest(
                                ROOT / (args.phase + '-summary.json')))
        except BaseException as error:
            campaign.update(state='cancelled' if isinstance(error, control.Cancelled) else 'failed',
                            error=repr(error), finished=time.time())
            raise
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            campaign.stop.set()
            campaign.observer.join(timeout=10)
            for name in campaign.state['completed']:
                record = control.read(ROOT / 'stages' / (name + '.json'))
                if control.active_group(record['pgid']):
                    raise RuntimeError('Owned stage group remained active after cleanup')


if __name__ == '__main__':
    main()
