#!/usr/bin/env python3
"""Validate only the pinned squared_norm revision pair, then compare triggers.

Snapshot both clean checkouts before and after the measured campaign. Compare
untouched run receipts with the frozen comparator first. A separate result makes
two documented in-memory substitutions after validating provenance: source
revision and the path of the byte-identical executable. No input, CLI, numerical,
identity, threshold, or native-binary differences are excused.
"""

import argparse
import copy
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import socket
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent
BASE = "d2647addb884ead3249914ebc980f3c132076d93"
CANDIDATE = "af4f0bd598ec1e2d7c6ce702d6c05850d7871039"
REVISIONS = {"baseline": BASE, "candidate": CANDIDATE}
CHANGED = ["pycbc/types/array_torch.py", "test/test_torch_squared_norm.py"]
DIFF_SHA = "cba88c8de4dd93df8c0c72c2aec3a661aa22f4745b91d80a94922d23729956e8"
EXEC_SHA = "d4af378d77aa5f66bcc018db32fe372360e53b22542e539ea3a2e53d31d8fa8a"
MODULE_SHA = {
    "baseline": "bde2a213bc135fd3f2ee2d1414ffbbf0a2aaa4da72ec722f9fab94eed37102d5",
    "candidate": "fe26a42d634f43e6bc319547f401772ccc429ddcbdc6689d322bd0f8bb1b12ce",
}
HELPERS = {
    "compare-triggers.py": "f0af115a2bf2d3a5a85152cb1f61d9b7570a460efd6d420566c5a2b74ac8f1b5",
    "run-case.py": "243eef653386a76d1ead4b92542bc84088e882df9011faab5a8154154da9c456",
    "qualify-inspiral.py": "234ff35cc4d54ab2e9dfd5d475d825a328346183adaf516f46df4653e50450b7",
    "config.json": "2cdf795f4c5c902823d039beb1a6f29a64a441e4c4ab781cb414c92257b5fbe4",
    "native-provenance.json": "bd43422b8082e26f42cde0c03af4d34a8457679f24177d3df37f1d8452cc1dfd",
    "checked-inspiral.py": "1b7e1efed640ec77c0579289a80a7946a34f1c42861d07cfe8c01794c25be735",
    "run-case-verified.py": "9bd95de06906a43aaad78285ca8fc9aa0a1eed410491049d63662e2d4de42b1f",
    "threadpoolctl.py": "12fb9526b6a74d2e686b7ec148dc165c3587999b14fa86984aa180e10802400b",
    "threadpoolctl-LICENSE": "81ac619075248b06e53660b652d10e485f4675f5d0ae0f97ea22370da1f7e23b",
}
BANK = "/home/xangma/pycbc-torch-reference-protocol-20260907/inputs/bank-compressed.hdf"
FRAME = "/home/xangma/pycbc_bench_repo/docs/_include/H-H1_LOSC_CLN_4_V1-1187007040-2048.gwf"
INPUTS = {
    BANK: "26050d48322a1d71092bb0e024e71a89ace56b3e7b1c5e4cf20c7b769213fb7f",
    FRAME: "580e238054474fd09be900c47217bbcd0497ab84d1756f886647e934352e4865",
}
PYTHON = "/home/xangma/pycbc-torch-split-20260905/venv/bin/python"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def git(path, *args):
    return subprocess.check_output(["git", "-C", str(path), *args])


def trusted_helpers():
    for name, expected in HELPERS.items():
        require(digest(ROOT / name) == expected, f"Changed helper: {name}")
    return dict(HELPERS, **{"compare-candidate.py": digest(__file__)})


def expected_native():
    return {item["relative_path"]: item["sha256"]
            for item in read(ROOT / "native-provenance.json")["extensions"]}


def inspect_sources(baseline, candidate):
    """Read actual git/working-tree/native bytes; do not alter either source."""
    snapshots = {}
    for role, path in (("baseline", baseline), ("candidate", candidate)):
        path = Path(path).resolve()
        native = {str(p.relative_to(path)): digest(p)
                  for p in sorted((path / "pycbc").rglob("*"))
                  if p.is_file() and p.suffix in (".so", ".dylib", ".pyd")}
        snapshots[role] = {
            "path": str(path),
            "source_snapshot": {
                "commit": git(path, "rev-parse", "HEAD").decode().strip(),
                "status": git(path, "status", "--porcelain",
                              "--untracked-files=all").decode(),
                "tracked_diff": git(path, "diff", "HEAD", "--").decode(),
            },
            "module_sha256": digest(path / "pycbc/types/array_torch.py"),
            "executable_sha256": digest(path / "bin/pycbc_inspiral"),
            "native_sha256": native,
        }
    patch = git(candidate, "diff", "--no-ext-diff", "--no-textconv",
                "--binary", "--full-index", BASE, CANDIDATE, "--")
    return {
        "sources": snapshots,
        "changed_files": git(candidate, "diff", "--name-only", BASE,
                             CANDIDATE, "--").decode().splitlines(),
        "diff_sha256": hashlib.sha256(patch).hexdigest(),
    }


def validate_snapshot(snapshot):
    require(snapshot["helpers"] == trusted_helpers(), "Helper provenance changed")
    require(snapshot["input_sha256"] == INPUTS, "Campaign inputs changed")
    require(snapshot["changed_files"] == CHANGED, "Unexpected source file diff")
    require(snapshot["diff_sha256"] == DIFF_SHA, "Unexpected exact source diff")
    require(set(snapshot["sources"]) == set(REVISIONS), "Wrong source roles")
    for role, revision in REVISIONS.items():
        source = snapshot["sources"][role]
        require(source["source_snapshot"] == {
            "commit": revision, "status": "", "tracked_diff": ""
        }, f"Unexpected or dirty {role} source")
        require(source["module_sha256"] == MODULE_SHA[role], "Module bytes differ")
        require(source["executable_sha256"] == EXEC_SHA, "Executable bytes differ")
        require(source["native_sha256"] == expected_native(), "Native bytes differ")
        require(Path(source["path"]).is_absolute(), "Source path must be absolute")
    require(snapshot["sources"]["baseline"]["path"] !=
            snapshot["sources"]["candidate"]["path"], "Checkouts must be distinct")


def take_snapshot(baseline, candidate):
    started = time.time()
    snapshot = dict(inspect_sources(baseline, candidate), helpers=trusted_helpers(),
                    input_sha256={p: digest(p) for p in INPUTS},
                    hostname=socket.gethostname(), started_at=started,
                    finished_at=time.time())
    validate_snapshot(snapshot)
    return snapshot


def validate_window(before, after):
    validate_snapshot(before)
    validate_snapshot(after)
    for key in ("sources", "helpers", "input_sha256", "changed_files",
                "diff_sha256", "hostname"):
        require(before[key] == after[key], f"Before/after drift: {key}")
    require(before["started_at"] <= before["finished_at"] <=
            after["started_at"] <= after["finished_at"], "Invalid provenance window")


def validate_receipt(receipt, role, before, after):
    source = before["sources"][role]
    require(receipt["source"] == source["path"], "Unexpected source checkout")
    require(receipt["source_info"] == source["source_snapshot"],
            "Run source snapshot differs from allowed role")
    require(receipt["source_status_after"] == "", "Source dirtied during run")
    require(receipt["hostname"] == before["hostname"], "Host differs")
    start = datetime.fromisoformat(receipt["started_utc"]).timestamp()
    stop = datetime.fromisoformat(receipt["finished_utc"]).timestamp()
    require(before["finished_at"] <= start <= stop <= after["started_at"],
            "Run lies outside source/native provenance window")
    require(receipt["state"] == "complete" and receipt["returncode"] == 0,
            "Run did not complete successfully")
    require(receipt["mode"] in ("timing", "qualify"), "Unexpected run mode")
    require(receipt["scheme"] == "torch:cpu:1", "Unexpected processing scheme")
    require((receipt["segment_length"], receipt["start_pad"], receipt["end_pad"])
            == (512, 112, 16), "Unexpected segment geometry")
    config = read(ROOT / "config.json")
    root = Path(receipt["cwd"])
    case = receipt["case"]
    require(root.is_absolute() and Path(case).name == case, "Invalid case path")
    executable = str(Path(source["path"]) / "bin/pycbc_inspiral")
    cli = [executable, *config["common_args"], "--bank-file", BANK,
           "--processing-scheme", "torch:cpu:1", "--segment-length", "512",
           "--segment-start-pad", "112", "--segment-end-pad", "16",
           "--output", str(root / "runs" / case / "triggers.hdf")]
    require(receipt["executable_cli"] == cli, "Unexpected executable CLI")
    workload = cli
    if receipt["mode"] == "qualify":
        workload = [str(root / "qualify-inspiral.py"), "--receipt",
                   str(root / "runs" / case / "qualification.json"), "--", *cli]
    command = [PYTHON, str(root / "checked-inspiral.py"), "--receipt",
               str(root / "runs" / case / "runtime.json"),
               "--config", str(root / "config.json"), "--source", source["path"],
               "--", *workload]
    command = ["/usr/bin/time", "-v", "-o", str(root / "runs" / case / "time.txt"),
               "taskset", "-c", str(config["core"]), *command]
    require(receipt["command"] == command, "Unexpected worker command or affinity")
    expected = dict(INPUTS, **{
        executable: EXEC_SHA,
        str(root / "config.json"): HELPERS["config.json"],
        str(root / "run-case-verified.py"): HELPERS["run-case-verified.py"],
        str(root / "checked-inspiral.py"): HELPERS["checked-inspiral.py"],
    })
    if receipt["mode"] == "qualify":
        expected[str(root / "qualify-inspiral.py")] = HELPERS["qualify-inspiral.py"]
    require(receipt["input_sha256"] == expected == receipt["input_sha256_after"],
            "Run inputs or helpers differ")
    spec = importlib.util.spec_from_file_location("checked_inspiral",
                                                 ROOT / "checked-inspiral.py")
    runtime_helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime_helper)
    environment = runtime_helper.fixed_environment(config, source["path"])
    require(receipt["environment"] == environment, "Unexpected execution environment")
    runtime_path = root / "runs" / case / "runtime.json"
    require(digest(runtime_path) == receipt["runtime_sha256"], "Runtime receipt changed")
    runtime = read(runtime_path)
    require(runtime["state"] == "complete", "Runtime checks did not complete")
    require(runtime["helper_sha256"] == HELPERS["checked-inspiral.py"],
            "Runtime helper differs")
    require(runtime["command"] == workload, "Runtime workload differs")
    require(runtime["hostname"] == receipt["hostname"], "Runtime host differs")
    require(runtime["source"] == runtime["imported_source"] == source["path"] and
            runtime["imported_module"] == source["path"] + "/pycbc/types/array_torch.py",
            "Runtime imported another source")
    require(runtime["module_sha256"] == MODULE_SHA[role], "Imported module differs")
    require(runtime["environment"] == environment, "Runtime environment differs")
    require(start <= runtime["started_at"] <= runtime["before_executable"]["observed_at"]
            <= runtime["at_first_bank"]["observed_at"]
            <= runtime["after_executable"]["observed_at"]
            <= runtime["finished_at"] <= stop, "Runtime observations outside run")
    for phase in ("before_executable", "at_first_bank", "after_executable"):
        runtime_helper.check(runtime[phase], environment, bank=phase == "at_first_bank")
    require(runtime["pid"] > 0 and bool(runtime["torch_version"]),
            "Missing runtime identity")
    return runtime


def frozen_comparator():
    trusted_helpers()
    spec = importlib.util.spec_from_file_location("frozen_trigger_comparator",
                                                 ROOT / "compare-triggers.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def cross_revision(compare, base, candidate, receipts, before, after):
    validate_window(before, after)
    items = [copy.deepcopy(base), copy.deepcopy(candidate)]
    substitutions = []
    runtimes = []
    for role, original, item, receipt in zip(REVISIONS, (base, candidate),
                                            items, receipts):
        runtimes.append(validate_receipt(receipt, role, before, after))
        require(not item["metadata"]["issues"], "Invalid original run metadata")
        require(item["metadata"]["source_snapshot"] == receipt["source_info"],
                "Loaded source metadata differs from receipt")
        executable = receipt["executable_cli"][0]
        hashes = item["metadata"]["consumed_input_sha256"]
        require(hashes == dict(INPUTS, **{executable: EXEC_SHA}),
                "Consumed data or executable hashes differ")
        del hashes[executable]
        hashes["role:byte-identical-bin/pycbc_inspiral"] = EXEC_SHA
        item["metadata"]["source_snapshot"] = {
            "authorized_pair": [BASE, CANDIDATE], "diff_sha256": DIFF_SHA,
        }
        substitutions.append({
            "role": role, "source_before": original["metadata"]["source_snapshot"],
            "source_after": item["metadata"]["source_snapshot"],
            "executable_path_before": executable,
            "executable_role_after": "role:byte-identical-bin/pycbc_inspiral",
            "verified_executable_sha256": EXEC_SHA,
        })
    require(runtimes[0]["pid"] != runtimes[1]["pid"], "Workers must be fresh processes")
    for key in ("torch_version", "torch_cuda_version"):
        require(runtimes[0][key] == runtimes[1][key], "Runtime versions differ")
    result = compare.compare(*items, compare.DEFAULTS)
    return {"status": result["status"], "scope": "cross-revision scientific parity",
            "tolerances": dict(compare.DEFAULTS), "substitutions": substitutions,
            "comparison": result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    snapshot = commands.add_parser("snapshot")
    snapshot.add_argument("--baseline-source", required=True, type=Path)
    snapshot.add_argument("--candidate-source", required=True, type=Path)
    snapshot.add_argument("--output", required=True, type=Path)
    compare = commands.add_parser("compare")
    for name in ("baseline", "candidate", "before", "after", "output"):
        compare.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    if args.action == "snapshot":
        save(args.output, take_snapshot(args.baseline_source, args.candidate_source))
        return 0
    args.output.mkdir(parents=True, exist_ok=False)
    frozen = frozen_comparator()
    try:
        base, candidate = frozen.load(args.baseline), frozen.load(args.candidate)
        raw = frozen.compare(base, candidate, frozen.DEFAULTS)
    except (KeyError, OSError, TypeError, ValueError) as error:
        raw = {"status": "fail", "error": str(error)}
    save(args.output / "raw-strict-comparison.json", raw)
    try:
        require("error" not in raw, "Strict comparator could not load the evidence")
        require(raw["status"] == "fail", "Exact different revisions must fail strict comparison")
        receipts = [read(p.with_name("receipt.json"))
                    for p in (args.baseline, args.candidate)]
        for item, path in zip((base, candidate), (args.baseline, args.candidate)):
            require(item["receipt_sha256"] == digest(path.with_name("receipt.json")),
                    "Receipt changed after strict comparison")
        result = cross_revision(frozen, base, candidate, receipts,
                                read(args.before), read(args.after))
    except (KeyError, OSError, TypeError, ValueError) as error:
        result = {"status": "fail", "scope": "cross-revision scientific parity",
                  "error": str(error)}
    save(args.output / "cross-revision-comparison.json", result)
    print(json.dumps({"raw_strict": raw["status"], "cross_revision": result["status"]}))
    return {"pass": 0, "fail": 1, "review": 2}[result["status"]]


if __name__ == "__main__":
    sys.exit(main())
