"""Validate every fresh-worker cell from the frozen squared-norm experiment."""
import importlib.util
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent
ORDER = [('baseline', 1), ('candidate', 1), ('candidate', 2),
         ('baseline', 2), ('baseline', 3), ('candidate', 3)]
CELLS = {(dtype, size, stride) for dtype in ('complex64', 'complex128')
         for size, stride in [(n, 1) for n in
                              (16, 512, 4095, 4096, 8193, 131072, 1048577)]
         + [(4096, 3), (131072, 3), (1048577, 3)]}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_worker(value, launch, stage, variant, before, after, pins):
    compare = load('candidate_comparator', 'compare-candidate.py')
    runtime = load('checked_runtime', 'checked-inspiral.py')
    require = compare.require
    candidate = before['sources']['candidate']['path']
    require(value['variant'] == variant and value['base_revision'] == compare.BASE,
            'Unexpected API source role')
    for key, expected in {
        'baseline_source_sha256': compare.MODULE_SHA['baseline'],
        'candidate_source_sha256': compare.MODULE_SHA['candidate'],
        'candidate_source': candidate + '/pycbc/types/array_torch.py',
        'harness_sha256': pins['benchmark-squared-norm.py'],
        'threads': 1, 'interop_threads': 1, 'host': before['hostname'],
    }.items():
        require(value[key] == expected, 'API worker differs: ' + key)
    require(stage['state'] == 'complete' and stage['returncode'] == 0,
            'API stage did not complete')
    require(value['pid'] == launch['pid'] == stage['pid'] == stage['pgid'],
            'API process did not exec directly from the stage')
    require(before['finished_at'] <= stage['started'] <= launch['started_at'] <=
            value['before']['time_ns'] / 1e9 <= value['after']['time_ns'] / 1e9 <=
            stage['finished'] <= after['started_at'], 'API worker outside source window')
    for phase in ('before', 'after'):
        require(value[phase]['affinity'] == [8] and
                value[phase]['smt_siblings'] == {'8': '8,72'},
                'API worker affinity differs')
    environment = runtime.fixed_environment(compare.read(ROOT / 'config.json'), candidate)
    require(launch['environment'] == environment, 'API environment was not sanitized')
    require(value['thread_environment'] == {key: '1' for key in
            ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
             'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')}, 'API thread env differs')
    require(launch['hostname'] == before['hostname'] and launch['affinity'] == [8],
            'API launch host/affinity differs')
    require(launch['helper_sha256'] == pins['api-worker.py'] and
            launch['harness_sha256'] == pins['benchmark-squared-norm.py'],
            'API helper bytes differ')
    require(launch['inherited_lock']['fd'] >= 3 and launch['inherited_lock']['path'] ==
            '/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock',
            'API lock descriptor differs')
    case = launch['command'][-1]
    require(launch['command'] == [compare.PYTHON, str(ROOT / 'benchmark-squared-norm.py'),
            '--worker', '--variant', variant, '--baseline-source',
            str(ROOT / 'baseline-array-torch.py'), '--output', case],
            'Unexpected API worker command')
    require(len(value['cells']) == len(CELLS) and
            {(r['dtype'], r['size'], r['stride']) for r in value['cells']} == CELLS,
            'Missing or duplicated API cells')
    for cell in value['cells']:
        samples = cell['seconds_per_call']
        require(len(samples) == 7 and all(math.isfinite(x) and x > 0 for x in samples),
                'Invalid API timing samples')
        require(type(cell['calls_per_sample']) is int and
                1 <= cell['calls_per_sample'] <= 10000, 'Invalid API call count')
        require(cell['median_seconds'] == statistics.median(samples), 'Incorrect API median')
        require(cell['exact_parity'] is True and cell['input_unchanged'] is True,
                'API qualification failed')
        for key in ('input_sha256', 'output_sha256'):
            require(len(cell[key]) == 64 and all(c in '0123456789abcdef' for c in cell[key]),
                    'Invalid API data digest')


def summarize(before, after, pins):
    compare = load('candidate_comparator', 'compare-candidate.py')
    compare.validate_window(before, after)
    expected = {f'{role}-r{repeat}.json' for role, repeat in ORDER}
    for folder in ('api-results', 'api-launches'):
        compare.require({p.name for p in (ROOT / folder).glob('*.json')} == expected,
                        'API worker set incomplete or unexpected')
    workers, hashes, grouped = [], {}, {}
    for role, repeat in ORDER:
        name = f'{role}-r{repeat}'
        paths = [ROOT / 'api-results' / (name + '.json'),
                 ROOT / 'api-launches' / (name + '.json'),
                 ROOT / 'stages' / ('api-' + name + '.json')]
        worker, launch, stage = [compare.read(path) for path in paths]
        compare.require(launch['command'][-1] == str(paths[0]), 'API output path differs')
        compare.require(stage['command'] == ['taskset', '-c', '8', compare.PYTHON,
                        str(ROOT / 'api-worker.py'), '--source',
                        before['sources']['candidate']['path'], '--variant', role,
                        '--repeat', str(repeat)], 'API stage command differs')
        validate_worker(worker, launch, stage, role, before, after, pins)
        hashes.update({str(p): compare.digest(p) for p in paths})
        workers.append(worker)
        for cell in worker['cells']:
            key = (cell['dtype'], cell['size'], cell['stride'])
            group = grouped.setdefault(key, {'baseline': [], 'candidate': [],
                                             'input': set(), 'output': set()})
            group[role].append(cell['median_seconds'])
            group['input'].add(cell['input_sha256'])
            group['output'].add(cell['output_sha256'])
    compare.require(len({w['pid'] for w in workers}) == 6, 'API workers reused a PID')
    for key in ('host', 'platform', 'python', 'torch', 'numpy'):
        compare.require(len({w[key] for w in workers}) == 1, 'API versions differ: ' + key)
    result = dict(scope=workers[0]['scope'], workers=6, repeats_per_role=3,
                  samples_per_cell=7, source_diff_sha256=compare.DIFF_SHA,
                  environment={k: workers[0][k] for k in
                               ('host', 'platform', 'python', 'torch', 'numpy')},
                  evidence_sha256=hashes, cells=[])
    for (dtype, size, stride), group in sorted(grouped.items()):
        compare.require(len(group['input']) == len(group['output']) == 1,
                        'API data differ between workers')
        compare.require(len(group['baseline']) == len(group['candidate']) == 3,
                        'API repeats incomplete')
        row = dict(dtype=dtype, size=size, stride=stride, exact_parity=True,
                   input_sha256=next(iter(group['input'])),
                   output_sha256=next(iter(group['output'])))
        for role in ('baseline', 'candidate'):
            row[role] = dict(seconds=group[role], median=statistics.median(group[role]),
                             minimum=min(group[role]), maximum=max(group[role]))
        row['ratio'] = row['baseline']['median'] / row['candidate']['median']
        result['cells'].append(row)
    compare.require(hashes == {p: compare.digest(p) for p in hashes},
                    'API evidence changed while verifying')
    return result
