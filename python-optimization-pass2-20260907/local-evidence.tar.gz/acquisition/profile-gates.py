"""Read-only predecessor gates inherited from the integrated profiling campaign."""

from pathlib import Path

import campaign_controls as control

ROOT = Path(__file__).resolve().parent

REFERENCE = Path('/home/xangma/pycbc-torch-reference-protocol-20260907')

BATCH = Path('/home/xangma/pycbc-torch-current-batch-sweep-20260907-r4')

CONVERGENCE = Path('/home/xangma/pycbc-torch-convergence-20260907')

SOURCE = Path('/home/xangma/pycbc-torch-profile-20260907-r3/source')

REVISION = 'd2647addb884ead3249914ebc980f3c132076d93'

BATCH_STATUS_SHA256 = 'a19f0d8862c7a05be182cfa3e8031ac3fe919ff210b7abede1490166adf40d32'

LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')

PREDECESSORS = [(CONVERGENCE, 'convergence-status.json', 340874),
                (BATCH, 'batch-status.json', 3789112)]

def process_table(proc=Path('/proc')):
    result = []
    for path in proc.iterdir():
        if not path.name.isdigit():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if fields[0] != 'Z':
                result.append(dict(pid=int(path.name), ppid=int(fields[1]),
                                   pgid=int(fields[2]), start_ticks=int(fields[19])))
        except FileNotFoundError:
            continue
    return result

class NotReady(ValueError):
    pass

def validate_predecessor(status, expected_pid, live, owned_groups):
    if status.get('pid') != expected_pid:
        raise ValueError('Predecessor identity differs from the coordination record')
    if status.get('state') in ('starting', 'waiting', 'running'):
        raise NotReady('Predecessor has not finished')
    if status.get('state') != 'complete' or not status.get('finished'):
        raise ValueError('Predecessor is not successfully terminal; inspect it first')
    owned_pids = {expected_pid, status.get('child_pid')}
    groups = set(owned_groups) | {status.get('pgid'), status.get('child_pgid')}
    if any(p['pid'] in owned_pids or p['pgid'] in groups for p in live):
        raise NotReady('Predecessor still has an active owned process/group')

def check_predecessors():
    live = process_table()
    result = []
    for root, filename, pid in PREDECESSORS:
        status = control.read(root / filename)
        groups = {pid}
        for receipt in (root / 'stages').glob('*.json'):
            value = control.read(receipt)
            groups.update(value.get(key) for key in ('pid', 'pgid'))
        validate_predecessor(status, pid, live, groups)
        result.append(dict(path=str(root / filename), status=status,
                           sha256=control.digest(root / filename),
                           owned_groups=sorted(g for g in groups if g)))
    batch_status = result[1]['status']
    if (batch_status.get('qualifications_passed') != 36 or
            batch_status.get('timing_workers') != 54 or
            batch_status.get('source_unchanged') is not True):
        raise ValueError('Batch campaign lacks its final qualification/timing gates')
    if result[1]['sha256'] != BATCH_STATUS_SHA256:
        raise ValueError('Batch completion differs from the reviewed R4 receipt')
    return result

def check_all_predecessors():
    result = check_predecessors()
    live = process_table()
    for entry in control.read(ROOT / 'predecessor-pins.json'):
        root = Path(entry['path']).parent
        status = control.read(entry['path'])
        if control.digest(entry['path']) != entry['sha256']:
            raise ValueError('Predecessor terminal receipt changed')
        groups = set(entry['owned_groups'])
        for receipt in (root / 'stages').glob('*.json'):
            value = control.read(receipt)
            groups.update(value.get(key) for key in ('pid', 'pgid'))
        validate_predecessor(status, entry['pid'], live, groups)
        result.append(dict(entry, status=status))
    return result
