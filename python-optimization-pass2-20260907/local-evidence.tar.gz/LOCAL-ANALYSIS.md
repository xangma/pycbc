# Preliminary local analysis

The fresh editable environment built successfully from d2647add; imports resolve to the new isolated worktree, with Torch 2.9.1. All build/controller groups were checked inactive. Runtime source remains clean and unchanged.

`probe-dispatch.py` records exploratory, single-worker guard and public-API timings in `dispatch-probe.json`; provisional functions were constructed in memory from the exact baseline AST. No source edit was made. All compared outputs were bitwise identical and inputs unchanged.

At lengths 16 and 4095, checking numel before constructing a device object reduced the isolated predicate from roughly 216–224 ns to 95–102 ns in this run. Public calls at size 16 improved by about 0.1–0.2 microseconds. The large-vector samples and some predicate samples were noisy; they are not accepted paired fresh-worker results and support no executable benefit or candidate decision. The profiling task was asked to send new completed hotspot attribution early while it continues its authorized campaign.

Do not choose a candidate from this diagnostic alone. Await the new CPU/Torch profile, compare expected whole-workload benefit and contracts, then implement and test one narrow Python change. Remote staging/measurement remains held for profiler release and the inherited whole-job flock.
