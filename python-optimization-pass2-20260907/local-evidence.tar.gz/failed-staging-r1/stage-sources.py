"""Create only the new candidate pair after checking the reviewed release gates."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def git(source, *args):
    return subprocess.check_output(['git', '-C', str(source), *args])


def main():
    campaign = load('campaign', 'optimize-campaign.py')
    compare = load('compare', 'compare-candidate.py')
    gate = load('gate', 'profile-gates.py')
    expected_root = Path('/home/xangma/pycbc-torch-python-optimization-pass2-20260907')
    assert ROOT == expected_root
    assert sys.executable == compare.PYTHON
    assert os.environ['OMP_NUM_THREADS'] == os.environ['OPENBLAS_NUM_THREADS'] == '1'
    transfer = json.loads((ROOT / 'transfer-manifest.json').read_text())
    for filename, expected in transfer.items():
        assert Path(filename).name == filename
        assert compare.digest(ROOT / filename) == expected, filename
    helpers = campaign.pins()
    campaign.gates()
    with campaign.LOCK.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        release = campaign.gates()
        assert campaign.pins() == helpers
        origin = gate.SOURCE.resolve()
        assert git(origin, 'rev-parse', 'HEAD').decode().strip() == compare.BASE
        assert git(origin, 'status', '--porcelain') == b''
        baseline, candidate = ROOT / 'source-baseline', ROOT / 'source-candidate'
        assert not baseline.exists() and not candidate.exists()
        provenance = json.loads((ROOT / 'native-provenance.json').read_text())
        native_paths = ['setup.py', 'setup.cfg', 'pyproject.toml', 'MANIFEST.in', 'pycbc/lib']
        native_paths += [':(glob)**/*.' + suffix for suffix in
                         ('pyx', 'pxd', 'pxi', 'c', 'h', 'hpp', 'cpp', 'cu')]
        assert git(origin, 'diff', provenance['source_revision'], compare.BASE,
                   '--', *native_paths) == b''
        native = compare.expected_native()
        assert native == {str(p.relative_to(origin)): compare.digest(p)
                          for p in (origin / 'pycbc').rglob('*.so')}
        for role, dest, revision in (('baseline', baseline, compare.BASE),
                                     ('candidate', candidate, compare.CANDIDATE)):
            subprocess.run(['git', 'clone', '--no-hardlinks', '--no-checkout',
                            str(origin), str(dest)], check=True)
            if role == 'candidate':
                git(dest, 'bundle', 'verify', str(ROOT / 'source-candidate.bundle'))
                git(dest, 'fetch', str(ROOT / 'source-candidate.bundle'),
                    'refs/heads/codex/torch-python-optimization-pass2-20260907')
            git(dest, 'checkout', '--detach', revision)
            assert git(dest, 'diff', compare.BASE, revision, '--', *native_paths) == b''
            for relative, expected in native.items():
                original, target = origin / relative, dest / relative
                assert compare.digest(original) == expected
                assert not target.exists()
                shutil.copyfile(original, target)
                assert compare.digest(target) == expected
        snapshot = compare.take_snapshot(baseline, candidate)
        assert campaign.pins() == helpers
        compare.save(ROOT / 'source-staging.json', dict(
            created_epoch=time.time(), pid=os.getpid(), pgid=os.getpgrp(),
            source_snapshot=snapshot, predecessor_release=release,
            transfer_manifest_sha256=compare.digest(ROOT / 'transfer-manifest.json'),
            staging_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
        print(json.dumps(dict(state='complete', baseline=str(baseline), candidate=str(candidate),
                              source_staging_sha256=compare.digest(ROOT / 'source-staging.json'))))


if __name__ == '__main__':
    main()
