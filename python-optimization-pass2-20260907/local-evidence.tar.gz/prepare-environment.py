"""Bounded local editable installation into this pass's fresh environment."""
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time


ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/pycbc-torch-python-optimization-pass2-20260907')
VENV = Path('/private/tmp/pycbc-python-optimization-pass2-20260907-venv')
BASE = '/Users/xangma/miniconda3/envs/pycbc313/bin/python'
STATE = dict(host=socket.gethostname(), cwd=str(SOURCE), pid=os.getpid(),
             pgid=os.getpgrp(), started=time.time(), state='running', stages=[])


def record():
    temporary = ROOT / 'environment-status.tmp'
    temporary.write_text(json.dumps(STATE, indent=2) + '\n')
    temporary.replace(ROOT / 'environment-status.json')


def interrupted(signum, frame):
    raise InterruptedError(f'Received signal {signum}')


def run(command, timeout):
    stage = dict(command=command, started=time.time(), timeout_seconds=timeout)
    child = subprocess.Popen(command, cwd=SOURCE, start_new_session=True)
    stage.update(pid=child.pid, pgid=child.pid)
    STATE['stages'].append(stage)
    record()
    try:
        result = child.wait(timeout=timeout)
        stage.update(returncode=result, finished=time.time())
        record()
        if result:
            raise RuntimeError(f'Stage returned {result}')
    finally:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()


def main():
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    if VENV.exists():
        raise RuntimeError('Environment must be fresh')
    record()
    try:
        run([BASE, '-m', 'venv', '--system-site-packages', str(VENV)], 60)
        run([str(VENV / 'bin/python'), '-m', 'pip', 'install', '-e', '.',
             '--no-deps', '--no-build-isolation'], 360)
        run([str(VENV / 'bin/python'), '-c',
             'import pycbc, torch; from pathlib import Path; '
             f'assert Path(pycbc.__file__).resolve() == '
             f'Path({str(SOURCE / "pycbc/__init__.py")!r}); '
             'print(pycbc.__file__); print(torch.__version__)'], 60)
        STATE['state'] = 'complete'
    except BaseException as exc:
        STATE.update(state='failed', error=repr(exc))
        raise
    finally:
        STATE['finished'] = time.time()
        record()


if __name__ == '__main__':
    main()
