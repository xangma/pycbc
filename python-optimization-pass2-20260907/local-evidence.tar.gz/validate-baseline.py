"""Run baseline array contracts once in the new editable environment."""
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/pycbc-torch-python-optimization-pass2-20260907')
REVISION = 'd2647addb884ead3249914ebc980f3c132076d93'
TESTS = [
    'test/test_array.py', 'test/test_torch_squared_norm.py',
    'test/test_array_torch_reductions.py', 'test/test_torch_ops.py',
    'test/test_torch_backend_protocol.py', 'test/test_torch_backend_coercion.py',
    'test/test_torch_context_conversion.py',
]


def source_record():
    revision = subprocess.check_output(
        ['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(
        ['git', '-C', str(SOURCE), 'status', '--porcelain'], text=True)
    assert revision == REVISION and not status
    return dict(revision=revision, status=status, sha256={
        name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest()
        for name in ('pycbc/types/array_torch.py',
                     'pycbc/types/array_torch_numpy.py', *TESTS)})


def worker():
    import pycbc
    import pytest
    import torch

    assert Path(pycbc.__file__).resolve() == SOURCE / 'pycbc/__init__.py'
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    print(json.dumps(dict(pycbc=pycbc.__file__, torch=torch.__version__,
                          python=sys.version, pid=os.getpid())), flush=True)
    return pytest.main(['-q', '-ra', '--tb=short', *TESTS])


def main():
    if sys.argv[1:] == ['worker']:
        return worker()
    state = dict(host=socket.gethostname(), cwd=str(SOURCE), pid=os.getpid(),
                 pgid=os.getpgrp(), started=time.time(), state='running',
                 timeout_seconds=300, source_before=source_record())
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               MKL_NUM_THREADS='1', PYTHONPATH=str(SOURCE),
               PYCBC_TEST_SCHEME='torch:cpu')
    state['environment'] = {key: env[key] for key in (
        'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
        'PYTHONPATH', 'PYCBC_TEST_SCHEME')}
    state['command'] = [sys.executable, str(Path(__file__).resolve()), 'worker']

    def save():
        temp = ROOT / 'baseline-tests-status.tmp'
        temp.write_text(json.dumps(state, indent=2) + '\n')
        temp.replace(ROOT / 'baseline-tests-status.json')

    def interrupted(signum, frame):
        raise InterruptedError(f'Received signal {signum}')

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    child = None
    save()
    try:
        child = subprocess.Popen(state['command'], cwd=SOURCE, env=env,
                                 start_new_session=True)
        state.update(child_pid=child.pid, child_pgid=child.pid)
        save()
        state['returncode'] = child.wait(timeout=300)
        state['source_after'] = source_record()
        assert state['source_after'] == state['source_before']
        state['state'] = 'complete' if state['returncode'] == 0 else 'failed'
        return state['returncode']
    except BaseException as exc:
        state.update(state='failed', error=repr(exc))
        raise
    finally:
        if child is not None:
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        state['finished'] = time.time()
        save()


if __name__ == '__main__':
    raise SystemExit(main())
