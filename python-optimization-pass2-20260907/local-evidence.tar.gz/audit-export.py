"""Read-only export release audit; JSON stdout, no scientific execution."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/home/xangma/pycbc-torch-python-optimization-pass2-20260907')
EXPORT = ROOT.with_name(ROOT.name + '-export')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT))
    os.chdir(ROOT)
    spec = importlib.util.spec_from_file_location('campaign', ROOT / 'optimize-campaign.py')
    campaign = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(campaign)
    compare = campaign.load('compare', 'compare-candidate.py')
    gates = campaign.load('gates', 'profile-gates.py')
    status = read(EXPORT / 'export-status.json')
    launch = read(EXPORT / 'export-launch.json')
    manifest = read(EXPORT / 'evidence-manifest.json')
    assert status['state'] == 'complete' and status['finished']
    assert status['all_pins_unchanged'] is True
    assert status['pid'] == status['pgid'] == launch['pid'] == launch['pgid']
    assert status['archive_sha256'] == digest(EXPORT / 'evidence.tar.gz')
    assert status['archive_bytes'] == (EXPORT / 'evidence.tar.gz').stat().st_size
    assert status['manifest_sha256'] == digest(EXPORT / 'evidence-manifest.json')
    assert launch['helper_sha256'] == digest(EXPORT / 'export-evidence.py')
    groups = set(status['scientific_owned_groups']) | {status['pid'], status['pgid']}
    assert manifest['scientific_owned_groups'] == status['scientific_owned_groups']
    active = [p for p in gates.process_table()
              if p['pid'] in groups or p['pgid'] in groups]
    assert active == [], active
    with campaign.LOCK.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        pins = campaign.pins()
        release = campaign.gates()
        campaign.api_review()
        assert pins == manifest['helper_sha256']
        assert manifest['profile_release_sha256'] == release['release_sha256']
        fresh = compare.take_snapshot(ROOT / 'source-baseline', ROOT / 'source-candidate')
        compare.validate_window(manifest['source_snapshot'], fresh)
        hashes = {}
        for directory, folders, names in os.walk(ROOT):
            folders[:] = sorted(n for n in folders if n not in
                                {'source-baseline', 'source-candidate', '__pycache__', '.pytest_cache'})
            for name in sorted(names):
                path = Path(directory) / name
                assert path.is_file() and not path.is_symlink()
                hashes[str(path.relative_to(ROOT))] = digest(path)
        assert hashes == manifest['files']
        assert len(hashes) == status['files']
        output = dict(state='validated-release', host='len', checked_epoch=time.time(),
                      owned_groups=sorted(groups), active_owned_processes=[],
                      shared_lock_reacquired=True, all_pins_unchanged=True,
                      all_exported_files_unchanged=True, files=len(hashes),
                      archive_sha256=status['archive_sha256'],
                      manifest_sha256=status['manifest_sha256'],
                      export_status_sha256=digest(EXPORT / 'export-status.json'),
                      export_launch_sha256=digest(EXPORT / 'export-launch.json'),
                      export_helper_sha256=digest(EXPORT / 'export-evidence.py'),
                      source_snapshot=fresh)
        print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    raise SystemExit(main())
