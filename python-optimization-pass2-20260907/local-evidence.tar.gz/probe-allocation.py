"""Bounded local screening; the checked-out runtime stays unchanged."""
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import statistics
import sys
import time

import numpy as np
import pytest
import torch

from pycbc import scheme
from pycbc.types import Array, array_torch


ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/pycbc-torch-python-optimization-pass2-20260907')


def timeout(signum, frame):
    raise TimeoutError('Local screening exceeded 120 seconds')


def main():
    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(120)
    assert Path(array_torch.__file__).resolve() == SOURCE / 'pycbc/types/array_torch.py'
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    source = Path(array_torch.__file__).read_bytes()
    baseline = array_torch.squared_norm
    node = next(n for n in ast.parse(source).body
                if isinstance(n, ast.FunctionDef) and n.name == 'squared_norm')
    node.body[1].body[0].body = ast.parse(
        'out = tensor.real.square()\nout.add_(tensor.imag.square())').body
    namespace = dict(vars(array_torch))
    exec(compile(ast.fix_missing_locations(ast.Module(
        body=[node], type_ignores=[])), '<local-allocation-screen>', 'exec'), namespace)
    candidate = namespace['squared_norm']
    records = dict(
        scope=('Exploratory Apple CPU screening of one allocation-only change. '
               'Same-worker alternating variants; not accepted paired fresh-worker '
               'evidence, Linux evidence, or executable measurements.'),
        baseline='d2647addb884ead3249914ebc980f3c132076d93',
        source_sha256=hashlib.sha256(source).hexdigest(),
        harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        candidate_source=ast.unparse(node),
        host=platform.node(), platform=platform.platform(), python=sys.version,
        torch=torch.__version__, numpy=np.__version__, pid=os.getpid(),
        torch_threads=torch.get_num_threads(), cells=[])
    try:
        array_torch.squared_norm = candidate
        scheme._import_cache.clear()
        records['contract_test_exit_code'] = int(pytest.main([
            '-q', str(SOURCE / 'test/test_torch_squared_norm.py')]))
        assert records['contract_test_exit_code'] == 0
        context = scheme.TorchScheme('cpu', num_threads=1)
        try:
            with context:
                for dtype in [torch.complex64, torch.complex128]:
                    for size, stride in [(16, 1), (4095, 1), (4096, 1),
                                         (131072, 1), (1048577, 1),
                                         (4096, 3), (131072, 3), (1048577, 3)]:
                        generator = torch.Generator().manual_seed(2017)
                        tensor = torch.randn(size * stride + 1, generator=generator,
                                             dtype=dtype)[1::stride]
                        original = tensor.clone()
                        array = Array(array_torch.TorchArrayData(tensor), copy=False)
                        expected = baseline(array).tensor
                        variants = {'baseline': baseline, 'reuse_result': candidate}
                        samples = {name: [] for name in variants}
                        iterations = max(10, min(500, 1048576 // size))
                        for repeat in range(9):
                            order = list(variants)
                            if repeat % 2:
                                order.reverse()
                            for name in order:
                                array_torch.squared_norm = variants[name]
                                scheme._import_cache.clear()
                                for _ in range(3):
                                    actual = array.squared_norm()._data.tensor
                                integer = torch.int32 if dtype == torch.complex64 else torch.int64
                                assert torch.equal(actual.view(integer), expected.view(integer))
                                start = time.perf_counter_ns()
                                for _ in range(iterations):
                                    array.squared_norm()
                                samples[name].append((time.perf_counter_ns() - start) / iterations)
                        assert torch.equal(tensor, original)
                        medians = {name: statistics.median(values)
                                   for name, values in samples.items()}
                        records['cells'].append(dict(
                            dtype=str(dtype), size=size, stride=stride,
                            iterations=iterations, nanoseconds_per_call=samples,
                            medians_ns=medians,
                            speedup=medians['baseline'] / medians['reuse_result'],
                            bitwise_parity=True, input_unchanged=True))
                        print(dtype, size, stride, records['cells'][-1]['speedup'], flush=True)
        finally:
            del context
            scheme.Scheme._single = None
    finally:
        array_torch.squared_norm = baseline
        scheme._import_cache.clear()
        records['source_unchanged'] = Path(array_torch.__file__).read_bytes() == source
        records['completed_cells'] = len(records['cells'])
        (ROOT / 'allocation-probe.json').write_text(json.dumps(records, indent=2) + '\n')
        signal.alarm(0)
    assert records['source_unchanged']


if __name__ == '__main__':
    print('pid', os.getpid(), 'pgid', os.getpgrp(), flush=True)
    main()
