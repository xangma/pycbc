"""Untimed eager-first, byte-exact verification of every normal graph call."""
import contextlib
import hashlib
import importlib.util
from math import sqrt
from pathlib import Path
import time

import torch

import offline_graph


spec = importlib.util.spec_from_file_location(
    "original_qualification", Path(__file__).with_name("qualify-inspiral.py"))
donor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(donor)


def snapshot(value):
    tensor = value if type(value) is torch.Tensor else value._data.tensor
    values = tensor.detach().cpu().numpy().copy()
    return str(values.dtype), tuple(values.shape), values.tobytes()


def certificate(value):
    dtype, shape, data = value
    return dict(dtype=dtype, shape=shape, nbytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


class Qualification(donor.Qualification):
    def __init__(self, *args):
        super().__init__(*args)
        self.graphs = dict(captures=[], calls=[], replays=0,
                          retention_checks=0, retained_nonempty=0,
                          capture_contexts=[])
        self.data["offline_graph"] = self.graphs
        self.retained = []
        self.controller = None
        self.active_capture = None

    def verify_retained(self):
        for pair, expected in self.retained:
            assert tuple(snapshot(array) for array in pair) == expected
            self.graphs["retention_checks"] += 1

    def install(self):
        super().install()
        from pycbc.filter import matchedfilter

        replay = torch.cuda.CUDAGraph.replay

        def observed_replay(graph):
            result = replay(graph)
            self.graphs["replays"] += 1
            return result

        self.patch(torch.cuda.CUDAGraph, "replay", observed_replay)
        graph_context = torch.cuda.graph

        @contextlib.contextmanager
        def observed_context(*args, **kwargs):
            assert self.active_capture is not None
            torch.cuda.synchronize()
            start = time.perf_counter()
            self.active_capture["setup_and_three_warmups_seconds"] = (
                start - self.active_capture["start_perf"])
            with graph_context(*args, **kwargs):
                yield
            torch.cuda.synchronize()
            self.active_capture["capture_seconds"] = time.perf_counter() - start
            self.graphs["capture_contexts"].append(self.active_capture["segment"])

        self.patch(torch.cuda, "graph", observed_context)
        capture = offline_graph.capture_symmetric_cuda_graph

        def observed_capture(control, segnum, window, template_norm=1.0):
            assert self.active_capture is None
            record = dict(segment=segnum, window=window, warmups=3,
                          start_perf=time.perf_counter())
            self.active_capture = record
            try:
                assert capture(control, segnum, window, template_norm) is True
                torch.cuda.synchronize()
                record["total_capture_setup_seconds"] = time.perf_counter() - record.pop("start_perf")
                record["binding"] = offline_graph.graph_signature(control, segnum, window)
                self.graphs["captures"].append(record)
                return True
            finally:
                self.active_capture = None

        self.patch(offline_graph, "capture_symmetric_cuda_graph", observed_capture)
        initialize = matchedfilter.MatchedFilterControl.__init__

        def observed_init(control, *args, **kwargs):
            initialize(control, *args, **kwargs)
            assert self.controller is None
            self.controller = control
            signature = offline_graph.controller_signature(control, 4096)
            self.graphs["initial_binding"] = signature
            selected = control.matched_filter_and_cluster
            torch.cuda.reset_peak_memory_stats(signature["device"])
            self.graphs["memory_before_calls"] = self.memory()

            def observed_filter(segnum, template_norm, window, epoch=None):
                self.verify_retained()
                offline_graph.assert_binding(control, window, signature)
                offline_graph.assert_graph_bindings(control)
                inputs = (snapshot(control.htilde), snapshot(control.segments[segnum]))
                norm = (4.0 * control.delta_f) / sqrt(template_norm)
                control.correlators[segnum].correlate()
                control.ifft.execute()
                eager_values, eager_indices = control.threshold_and_clusterers[
                    segnum].threshold_and_cluster(control.snr_threshold / norm, window)
                expected_full = (snapshot(control.corr_mem), snapshot(control.snr_mem))
                expected_sparse = (snapshot(eager_indices), snapshot(eager_values))
                first_use = (segnum, window) not in getattr(control, "_cuda_graphs", {})
                before = self.graphs["replays"]
                start = time.perf_counter() if first_use else None
                result = selected(segnum, template_norm, window, epoch=epoch)
                assert self.graphs["replays"] == before + 1
                actual_full = (snapshot(control.corr_mem), snapshot(control.snr_mem))
                assert actual_full == expected_full, "Full correlation/SNR byte mismatch"
                assert (snapshot(control.htilde), snapshot(control.segments[segnum])) == inputs
                offline_graph.assert_binding(control, window, signature)
                offline_graph.assert_graph_bindings(control)
                if len(eager_indices) == 0:
                    assert result == ([], [], [], [], []) or result == [[], [], [], [], []]
                    sparse = expected_sparse
                else:
                    assert len(result) == 5 and result[1] == norm
                    assert result[0]._data.tensor.data_ptr() == control.snr_mem._data.tensor.data_ptr()
                    assert result[2]._data.tensor.data_ptr() == control.corr_mem._data.tensor.data_ptr()
                    sparse = (snapshot(result[3]), snapshot(result[4]))
                    assert sparse == expected_sparse, "Sparse result byte mismatch"
                    scratch = control.threshold_and_clusterers[segnum]
                    forbidden = {v.untyped_storage().data_ptr() for v in (
                        control.snr_mem._data.tensor, control.corr_mem._data.tensor,
                        scratch._triton_block_max, scratch._triton_block_idx, scratch._triton_keep)}
                    assert all(v._data.tensor.untyped_storage().data_ptr() not in forbidden
                               for v in result[3:])
                    self.verify_retained()
                    retained = (result[3:], sparse)
                    self.retained = [self.retained[0], retained] if self.retained else [retained]
                    self.graphs["retained_nonempty"] += 1
                self.verify_retained()
                row = dict(call=len(self.graphs["calls"]), template=list(self.current_template),
                           segment=segnum, template_norm=float(template_norm), norm=float(norm),
                           raw_threshold=float(control.snr_threshold / norm),
                           inputs=[certificate(v) for v in inputs],
                           full=[certificate(v) for v in actual_full],
                           sparse=[certificate(v) for v in sparse],
                           full_bytes_equal=True, sparse_bytes_equal=True,
                           inputs_unchanged=True, binding_unchanged=True,
                           empty=len(eager_indices) == 0)
                if first_use:
                    row["first_use_seconds_with_verification"] = time.perf_counter() - start
                self.graphs["calls"].append(row)
                return result

            self.patch(control, "matched_filter_and_cluster", observed_filter)

        self.patch(matchedfilter.MatchedFilterControl, "__init__", observed_init)

    @staticmethod
    def memory():
        return dict(allocated=torch.cuda.memory_allocated(), reserved=torch.cuda.memory_reserved(),
                    peak_allocated=torch.cuda.max_memory_allocated(),
                    peak_reserved=torch.cuda.max_memory_reserved())

    def checks(self):
        checks = super().checks()
        checks.pop("scalar_ifft_executed_for_every_pair")
        primary_id = self.data["matched_filter_controllers"][0]["ifft_engine_id"]
        primary = self.data["fft_engines"][primary_id]
        checks["python_ifft_calls_1920_oracles_plus_20_warmup_capture"] = (
            primary["nbatch"] == 1 and primary["execute_attempts"] == primary["execute_successes"] == 1940)
        checks["five_real_captures"] = [v["segment"] for v in self.graphs["captures"]] == list(range(5))
        checks["five_capture_contexts"] = self.graphs["capture_contexts"] == list(range(5))
        checks["exactly_1920_actual_replays_and_full_comparisons"] = (
            self.graphs["replays"] == len(self.graphs["calls"]) == 1920)
        checks["templates_and_norms_changed"] = (
            len({v["inputs"][0]["sha256"] for v in self.graphs["calls"]}) == 384
            and len({v["template_norm"] for v in self.graphs["calls"]}) > 1)
        self.verify_retained()
        checks["retained_sparse_outputs_survived"] = (
            self.graphs["retained_nonempty"] > 1 and self.graphs["retention_checks"] >= 1920)
        if self.controller is not None:
            offline_graph.assert_binding(self.controller, 4096, self.graphs["initial_binding"])
            offline_graph.assert_graph_bindings(self.controller)
            self.graphs["final_bindings"] = [dict(segment=k[0], window=k[1], **v)
                for k, v in self.controller._offline_graph_bindings.items()]
            self.graphs["memory_after_calls"] = self.memory()
        return checks


if __name__ == "__main__":
    donor.Qualification = Qualification
    raise SystemExit(donor.main())
