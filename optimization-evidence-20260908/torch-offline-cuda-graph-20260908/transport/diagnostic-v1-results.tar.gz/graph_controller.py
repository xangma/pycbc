"""One locked native gate, E/G science gates, then eight fixed serial timings."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/xangma/pycbc-torch-fft-optimization-20260908/loader-v1/source-candidate')
PYTHON = '/home/xangma/pycbc-torch-split-20260905/venv/bin/python'
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
STATUS = ROOT / 'graph-status.json'
BANK = '/home/xangma/pycbc-torch-reference-protocol-20260907/inputs/bank-compressed.hdf'
BANK_SHA = '26050d48322a1d71092bb0e024e71a89ace56b3e7b1c5e4cf20c7b769213fb7f'
COMMIT = 'ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f'
ORDERS = (('E1', 'G1'), ('G2', 'E2'), ('G3', 'E3'), ('E4', 'G4'))


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def pins():
    for name, expected in read(ROOT / 'manifest.json').items():
        assert sha(ROOT / name) == expected, name
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'])
    for records in (read(ROOT / 'current-source-pins.json'),
                    read(ROOT / 'offline-cuda-graph-selection-v1.json')['source_sha256']):
        for name, expected in records.items():
            assert sha(SOURCE / name) == expected, name
    for path, expected in read(ROOT / 'input-pins.json').items():
        assert sha(path) == expected, path
    for records in read(ROOT / 'reference-pins.json').values():
        for name, expected in records['sha256'].items():
            assert sha(Path(records['remote']) / name) == expected, name
    for record in read(ROOT / 'library-pins.json').values():
        assert sha(record['path']) == record['sha256'], record['path']
    for path, expected in read(ROOT / 'cuda-runtime-pins.json')['sha256'].items():
        assert sha(path) == expected, path
    return dict(manifest_sha256=sha(ROOT / 'manifest.json'),
                source_pins_sha256=sha(ROOT / 'current-source-pins.json'),
                graph_source_pins_sha256=sha(ROOT / 'offline-cuda-graph-selection-v1.json'),
                reference_pins_sha256=sha(ROOT / 'reference-pins.json'),
                runtime_pins_sha256=sha(ROOT / 'cuda-runtime-pins.json'))


def verify_native(path):
    native = read(path)
    assert native['status'] == 'passed' and native['schema_version'] == 1
    assert native['script_sha256'] == sha(ROOT / 'native_graph_contracts.py')
    software = native['software']
    assert software['torch'] == '2.13.0+cu130' and software['cuda'] == '13.0'
    assert software['pycbc_file'] == str(SOURCE / 'pycbc/__init__.py')
    assert software['helper_file'] == str(ROOT / 'offline_graph.py')
    assert software['helper_sha256'] == sha(ROOT / 'offline_graph.py')
    lock = LOCK.stat()
    original_lock = native['runtime_before_thread_configuration']['lock']
    assert original_lock['fd'] >= 3 and original_lock['target'] == str(LOCK)
    assert (original_lock['device'], original_lock['inode']) == (lock.st_dev, lock.st_ino)
    for stage in ('runtime_after_thread_configuration', 'runtime_before_native', 'runtime_final'):
        value = native[stage]
        assert value['affinity'] == [8] and value['torch_intra'] == value['torch_inter'] == 1
        assert value['pools'] and all(pool['num_threads'] == 1 for pool in value['pools'])
        assert value['lock'] == original_lock
    assert native['device'] == dict(index=0, name='NVIDIA GeForce RTX 4090', capability=[8, 9])
    assert native['observed'] == dict(captures=6, replays=30, replay_attempts=30)
    direct = native['direct_kernel']
    names = ['rounding-counterexample', 'threshold-f32-below', 'threshold-exact-one',
             'threshold-f32-above', 'threshold-zero', 'threshold-high', 'threshold-negative',
             'threshold-repeat-rounding', 'strict-threshold-equality', 'zero-no-survivors',
             'all-eligible-local-maxima', 'boundary-and-interior-ties', 'within-block-ties',
             'nan-inf-payload', 'infinite-threshold', 'nan-threshold', 'final-rounding-reuse']
    assert [row['name'] for row in direct['cases']] == names
    assert all(row['exact_bytes'] for row in direct['cases'])
    assert direct['captures'] == 2 and direct['replays'] == 18 and direct['retention_checks'] > 0
    first = direct['cases'][0]
    assert first['old_graph_failed'] and first['indices'] == [35] and first['old_indices'] == []
    assert first['corrected_square_bytes'] == '0000803f' and first['old_square_bytes'] == '0100803f'
    assert direct['cleanup'] == dict(device='cuda:0', synchronized=True, graph_reset_successes=2, quarantined=False)
    assert len(direct['bindings']) == 7 and len({row[0] for row in direct['bindings']}) == 7
    negatives = {'window', 'storage-replacement', 'shape', 'stride', 'dtype', 'device',
                 'lazy-conjugate', 'lazy-negative', 'reverse-ad', 'inference-tensor',
                 'tensor-subclass', 'forward-ad', 'inference-context', '_triton_block_max',
                 '_triton_block_idx', '_triton_keep', 'scratch-block-count', 'graph-raw-threshold',
                 'graph-squared-threshold', 'graph-object', 'cluster-source-binding',
                 'analysis-slice', 'cutoff', 'current-stream'}
    assert [row['stream'] for row in native['controls']] == ['default', 'custom']
    streams = []
    for control in native['controls']:
        assert control['captures'] == 2 and control['replays'] == 6 and control['retention_checks'] > 0
        calls = control['calls']
        assert [(row['template_variant'], row['segment']) for row in calls] == [
            (variant, segment) for variant in range(3) for segment in range(2)]
        assert all(all(row[key] for key in ('full_bytes_equal', 'sparse_bytes_equal',
            'inputs_unchanged', 'producer_queued_before_replay', 'ordered_consumer_bytes_equal')) for row in calls)
        assert [row['template_norm'] for row in calls] == [1., 1., 2., 2., 4., 4.]
        assert any(not row['empty'] for row in calls) and all(row['empty'] for row in calls[-2:])
        assert len({row['inputs'][0]['sha256'] for row in calls}) == 3
        assert len({row['inputs'][1]['sha256'] for row in calls}) == 2
        assert len(control['negative']) == len(negatives)
        assert {row['name'] for row in control['negative']} == negatives
        assert all(row['error'] and row['restored'] and row['replay_attempt_delta'] == row['replay_delta'] == 0
                   for row in control['negative'])
        trial = control['trial']
        assert 'cleanup_error' not in control and trial['enabled'] and trial['closed'] and trial['restored']
        assert not trial['installed'] and trial['window'] == 64 and trial['segments'] == 2
        assert trial['bindings'] == [control['initial_binding']] and len(trial['cleanup']) == 1
        streams.append(control['initial_binding']['stream'])
        cleanup = trial['cleanup'][0]
        assert cleanup['device'] == 0 and cleanup['synchronized'] and cleanup['partial_graphs'] == 0
        assert cleanup['graph_entries'] == cleanup['graph_reset_successes'] == 2
        assert cleanup['bindings'] == control['final_graph_bindings']
        assert [(row['segment'], row['window'], row['blocks']) for row in cleanup['bindings']] == [(0, 64, 56), (1, 64, 51)]
    assert streams[0] == 0 and streams[1] != streams[0]
    return dict(path=str(path), sha256=sha(path), captures=6, replays=30,
                native_cases=17, full_control_calls=12, rejected_before_replay=48)


def verify_descriptors(folder):
    result = read(folder / 'descriptors.json')
    assert result['state'] == 'complete' and result['variant'] == 'cached'
    for field, name in [('helper_sha256', 'run_reuse.py'), ('cache_sha256', 'descriptor_reuse.py'),
                        ('parent_cache_sha256', 'descriptor_reuse_diagnostic.py')]:
        assert result[field] == sha(ROOT / name)
    assert result['mkl_source'] == str(SOURCE / 'pycbc/fft/mkl.py')
    assert result['mkl_source_sha256'] == sha(SOURCE / 'pycbc/fft/mkl.py')
    cache = result['cache']
    assert cache['reuse'] and cache['closed'] and cache['restored']
    assert not any(cache[k] for k in ('poisoned', 'cleanup_errors', 'invariant_errors', 'finalization_errors'))
    assert all(p['inverse_ast_equal'] for p in cache['ast'].values())
    assert 'rows' not in cache and 'hits' not in cache
    assert len(cache['entries']) == cache['creates'] == cache['frees'] == 3
    assert all(e['state'] == 'freed' and e['free_attempts'] == e['free_successes'] == 1
               and e['free_reason'] == 'close' for e in cache['entries'])
    return dict(descriptors=3, freed_once=3, restored=True)


def verify_graphs(folder, arm):
    result = read(folder / 'graphs.json')
    assert result['state'] == 'complete' and 'cleanup_error' not in result
    assert result['helper_sha256'] == sha(ROOT / 'run_graph.py')
    assert result['graph_helper_sha256'] == sha(ROOT / 'offline_graph.py')
    trial = result['trial']
    assert trial['closed'] and trial['restored'] and not trial['installed']
    assert trial['enabled'] == (arm == 'G') and trial['window'] == 4096 and trial['segments'] == 5
    assert len(trial['bindings']) == len(trial['cleanup']) == 1
    binding = trial['bindings'][0]
    assert binding['device'] == 0 and binding['window'] == 4096 and binding['length'] == 2097152
    assert binding['cutoffs'] == [15360, 1048576]
    assert binding['geometry'] == [[458752, 2019328, None]] * 4 + [[475136, 2031616, None]]
    cleanup = trial['cleanup'][0]
    expected = 5 if arm == 'G' else 0
    assert cleanup['device'] == 0 and cleanup['synchronized']
    assert cleanup['graph_entries'] == cleanup['graph_reset_successes'] == expected
    assert cleanup['partial_graphs'] == 0 and len(cleanup['bindings']) == expected
    assert [v['segment'] for v in cleanup['bindings']] == list(range(expected))
    for row in cleanup['bindings']:
        assert row['window'] == 4096
        assert row['blocks'] == (381 if row['segment'] < 4 else 380)
        assert set(row['tensors']) == {'raw', 'squared', 'max', 'idx', 'keep'}
    if expected:
        assert len({v['graph'] for v in cleanup['bindings']}) == expected
        for name in ('raw', 'squared', 'max', 'idx', 'keep'):
            assert len({v['tensors'][name][1] for v in cleanup['bindings']}) == expected
    return dict(graphs=expected, reset_successes=expected, synchronized=True, restored=True)


def verify_run(folder, arm, mode):
    receipt, runtime = read(folder / 'receipt.json'), read(folder / 'runtime.json')
    assert receipt['state'] == runtime['state'] == 'complete' and receipt['returncode'] == 0
    assert receipt['arm'] == arm and receipt['mode'] == mode and receipt['scheme'] == 'torch:cuda:0'
    assert receipt['source'] == runtime['source'] == runtime['imported_source'] == str(SOURCE)
    assert receipt['source_info'] == {'commit': COMMIT, 'status': '', 'tracked_diff': ''}
    assert receipt['source_status_after'] == '' and receipt['input_sha256'] == receipt['input_sha256_after']
    for path, digest in receipt['input_sha256'].items():
        assert sha(path) == digest, path
    assert receipt['trigger_sha256'] == sha(folder / 'triggers.hdf')
    assert receipt['runtime_sha256'] == sha(folder / 'runtime.json')
    checker = module('graph_runtime', 'checked-inspiral.py')
    assert runtime['helper_sha256'] == sha(ROOT / 'checked-inspiral.py')
    assert runtime['processing_scheme'] == 'torch:cuda:0'
    cfg = read(ROOT / ('config-' + arm + '.json'))
    environment = checker.fixed_environment(cfg, SOURCE)
    assert receipt['environment'] == runtime['environment'] == environment
    for stage in ('before_executable', 'at_first_bank', 'after_executable'):
        checker.check(runtime[stage], environment, bank=stage == 'at_first_bank', scheme='torch:cuda:0')
    source_pins = read(ROOT / 'current-source-pins.json')
    for path, digest in runtime['source_modules'].items():
        relative = str(Path(path).relative_to(SOURCE))
        assert sha(path) == digest
        if path.endswith('.so'):
            assert source_pins[relative] == digest
    graphs, descriptors = read(folder / 'graphs.json'), read(folder / 'descriptors.json')
    assert descriptors['command'] == receipt['graph_command']
    assert runtime['command'] == receipt['reuse_command']
    if mode == 'timing':
        assert graphs['command'] == receipt['executable_cli']
        assert not (folder / 'qualification.json').exists()
    else:
        qualifier = ROOT / ('qualify_graph.py' if arm == 'G' else 'qualify-inspiral.py')
        assert graphs['command'] == [str(qualifier), '--receipt', str(folder / 'qualification.json'),
                                     '--', *receipt['executable_cli']]
    return dict(graphs=verify_graphs(folder, arm), descriptors=verify_descriptors(folder))


def qualify(folder, arm):
    import numpy as np
    q = read(folder / 'qualification.json')
    assert q['status'] == 'success' and q['executable_exit_code'] == 0
    assert q['checks'] and all(q['checks'].values())
    key = ('python_ifft_calls_1920_oracles_plus_20_warmup_capture' if arm == 'G'
           else 'scalar_ifft_executed_for_every_pair')
    assert q['checks'][key]
    for name in ('no_generation_fallback', 'bank_0_all_templates_once', 'bank_0_compression_enabled'):
        assert q['checks'][name]
    assert q['source_root'] == str(SOURCE)
    assert q['executable']['sha256'] == sha(SOURCE / 'bin/pycbc_inspiral')
    obs = q['observations']
    assert len(obs['banks']) == 1 and obs['banks'][0]['selected_template_count'] == 384
    assert obs['banks'][0]['file']['sha256'] == BANK_SHA
    assert obs['banks'][0]['expected_filter_calls'] == 1920
    assert obs['segment_geometry'] == read(ROOT / 'offline-cuda-graph-protocol-v1.json')['geometry']
    assert obs['parsed_options']['chisq_bins'] == '16' and obs['parsed_options']['cluster_window'] == 1.0
    controllers = obs['matched_filter_controllers']
    assert len(controllers) == 1 and controllers[0]['segment_count'] == 5
    assert [controllers[0]['filter_bin_start'], controllers[0]['filter_bin_stop']] == [15360, 1048576]
    engines = [row for row in obs['fft_engines'] if row['kind'] == 'IFFT']
    assert len(engines) == 1 and engines[0]['class'] == 'pycbc.fft.torchfft.IFFT'
    assert engines[0]['size'] == 2097152 and engines[0]['nbatch'] == 1
    assert engines[0]['execute_attempts'] == engines[0]['execute_successes'] == (1940 if arm == 'G' else 1920)
    psds = []
    for record in obs['psd_arrays']:
        path = folder / record['relative_path']
        assert path == Path(record['path']) and sha(path) == record['sha256']
        values = np.load(path, allow_pickle=False)
        assert list(values.shape) == record['shape'] and values.dtype.str == record['dtype_str']
        assert values.nbytes == record['nbytes'] and path.stat().st_size == record['bytes']
        assert hashlib.sha256(values.tobytes()).hexdigest() == record['data_sha256']
        assert record['validity']['valid_for_filter']
        psds.append({key: value for key, value in record.items() if key != 'path'})
    science = dict(conditioned_strain=obs['conditioned_strain'], psd_arrays=psds,
                   segment_geometry=obs['segment_geometry'])
    assert science == read(ROOT / 'science-reference.json')['by_scheme']['torch:cuda:0']
    if arm == 'G':
        graph = obs['offline_graph']
        assert len(graph['calls']) == graph['replays'] == 1920 and len(graph['captures']) == 5
        assert graph['capture_contexts'] == list(range(5))
        assert [(row['template'], row['segment']) for row in graph['calls']] == [
            ([0, template], seg) for template in range(384) for seg in range(5)]
        assert all(row['full_bytes_equal'] and row['sparse_bytes_equal'] and row['inputs_unchanged']
                   and row['binding_unchanged'] for row in graph['calls'])
        assert graph['retained_nonempty'] > 1 and graph['retention_checks'] >= 1920
        assert [v['warmups'] for v in graph['captures']] == [3] * 5
        for row in graph['captures']:
            assert row['setup_and_three_warmups_seconds'] > 0 and row['capture_seconds'] > 0
    return dict(path=str(folder / 'qualification.json'), sha256=sha(folder / 'qualification.json'),
                templates=384, segments=5, valid_seconds=1904, checks=q['checks'])


def compare(name, left, right, exact):
    import h5py
    comparator = module('graph_comparator', 'compare-triggers.py')
    result = comparator.compare(comparator.load(left / 'triggers.hdf'),
                                comparator.load(right / 'triggers.hdf'), comparator.DEFAULTS)
    certificates = None
    if exact:
        certificates = {}
        with h5py.File(left / 'triggers.hdf') as a, h5py.File(right / 'triggers.hdf') as b:
            datasets = []
            for handle in (a, b):
                paths = {}
                handle['H1'].visititems(lambda key, value: paths.update({key: value})
                                       if isinstance(value, h5py.Dataset) else None)
                datasets.append(paths)
            assert set(datasets[0]) == set(datasets[1])
            telemetry = {'search/run_time', 'search/filter_rate_per_core',
                         'search/setup_time_fraction', 'search/templates_per_core'}
            assert telemetry <= datasets[0].keys()
            keys = sorted(datasets[0].keys() - telemetry)
            assert len(keys) == 18
            for key in keys:
                av, bv = datasets[0][key][()], datasets[1][key][()]
                assert av.dtype == bv.dtype and av.shape == bv.shape and av.tobytes() == bv.tobytes(), key
                certificates[key] = dict(shape=list(av.shape), dtype=av.dtype.str,
                                          sha256=hashlib.sha256(av.tobytes()).hexdigest())
    path = ROOT / (name + '.json')
    save(path, dict(result=result, tolerances=comparator.DEFAULTS, exact_H1=certificates))
    assert result['status'] == 'pass', (name, result)
    return dict(path=str(path), sha256=sha(path), exact_science_datasets=18 if exact else None)


def main():
    assert not STATUS.exists() and Path(sys.executable).resolve() == Path(PYTHON).resolve()

    def terminated(signum, _frame):
        raise SystemExit(f'Campaign terminated by signal {signum}')

    signal.signal(signal.SIGTERM, terminated)
    os.environ.update(read(ROOT / 'config.json')['environment'])
    os.sched_setaffinity(0, {8})
    status = dict(state='starting', pid=os.getpid(), pgid=os.getpgrp(),
                  start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                  started_epoch=time.time(), workers=[], comparisons={}, timing_orders=ORDERS)
    save(STATUS, status)
    try:
        with LOCK.open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            frozen = pins()
            status.update(state='running', phase='native', pins=frozen)
            save(STATUS, status)

            def run(name, command, environment):
                assert pins() == frozen
                log = ROOT / (name + '.log')
                worker = dict(name=name, command=command, cwd=str(ROOT), log=str(log), started_epoch=time.time())
                with log.open('x') as output:
                    process = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                        stdout=output, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),))
                    worker.update(pid=process.pid, pgid=os.getpgid(process.pid),
                        start_ticks=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')', 1)[1].split()[19])
                    status['workers'].append(worker)
                    save(STATUS, status)
                    try:
                        worker['exit'] = process.wait(timeout=1800)
                    except subprocess.TimeoutExpired:
                        status.update(state='failed', error='Worker timeout; terminating whole process group')
                        save(STATUS, status)
                        os.killpg(os.getpgrp(), signal.SIGTERM)
                        raise
                worker.update(finished_epoch=time.time(), log_sha256=sha(log))
                save(STATUS, status)
                assert worker['exit'] == 0, worker
                assert pins() == frozen
                return worker

            checker = module('native_runtime', 'checked-inspiral.py')
            native_env = checker.clean_environment(os.environ, read(ROOT / 'config-G.json'), SOURCE)
            native_env['PYCBC_BENCHMARK_LOCK_FD'] = str(lock.fileno())
            run('native-contracts', [PYTHON, str(ROOT / 'native_graph_contracts.py'),
                '--output', str(ROOT / 'native-contracts.json')], native_env)
            status['native'] = verify_native(ROOT / 'native-contracts.json')
            status['phase'] = 'qualification'
            save(STATUS, status)
            refs = {name: Path(value['remote']) for name, value in read(ROOT / 'reference-pins.json').items()}
            qualifications = {}

            def run_case(name, arm, mode):
                command = [PYTHON, str(ROOT / 'run-case.py'), '--case', name, '--arm', arm, '--mode', mode]
                worker = run(name, command, dict(os.environ, PYCBC_BENCHMARK_LOCK_FD=str(lock.fileno())))
                folder = ROOT / 'runs' / name
                worker['verification'] = verify_run(folder, arm, mode)
                save(STATUS, status)
                return folder, worker

            for arm in ('E', 'G'):
                name = 'qual-' + arm
                folder, worker = run_case(name, arm, 'qualify')
                qualifications[arm] = worker['qualification'] = qualify(folder, arm)
                for label, other, exact in [('cuda-reference', refs['cuda'], True),
                                            ('standard-reference', refs['standard'], False)]:
                    key = name + '-vs-' + label
                    status['comparisons'][key] = compare(key, other, folder, exact)
                save(STATUS, status)
            key = 'qual-G-vs-E'
            status['comparisons'][key] = compare(key, ROOT / 'runs/qual-E', ROOT / 'runs/qual-G', True)
            save(ROOT / 'qualifications.json', qualifications)
            status.update(phase='timing', qualification_gate_epoch=time.time(),
                          qualification_sha256=sha(ROOT / 'qualifications.json'))
            save(STATUS, status)
            controls = module('graph_controls', 'campaign_controls.py')
            samples = {}
            for pair in ORDERS:
                for name in pair:
                    arm = name[0]
                    folder, worker = run_case(name, arm, 'timing')
                    for label, other, exact in [('own-qualification', ROOT / ('runs/qual-' + arm), True),
                                                ('standard-reference', refs['standard'], False)]:
                        key = name + '-vs-' + label
                        status['comparisons'][key] = compare(key, other, folder, exact)
                    samples[name] = worker['timing'] = controls.timing(folder, 384, COMMIT, BANK_SHA, qualifications[arm])
                    save(ROOT / 'samples.json', samples)
                    save(STATUS, status)
                i = pair[0][1]
                key = 'pair-' + i + '-G-vs-E'
                status['comparisons'][key] = compare(key, ROOT / ('runs/E' + i), ROOT / ('runs/G' + i), True)
                save(STATUS, status)
            eager = [samples['E' + str(i)]['full_wall_seconds'] for i in range(1, 5)]
            graph = [samples['G' + str(i)]['full_wall_seconds'] for i in range(1, 5)]
            differences = [e - g for e, g in zip(eager, graph, strict=True)]
            e, g = statistics.median(eager), statistics.median(graph)
            save(ROOT / 'timing-summary.json', dict(E=eager, G=graph, E_minus_G=differences,
                G_over_E=[g / e for e, g in zip(eager, graph, strict=True)],
                median_E=e, median_G=g, range_E=[min(eager), max(eager)], range_G=[min(graph), max(graph)],
                percent_reduction=100 * (1 - g / e), accepted=all(v > 0 for v in differences) and g < e))
            assert pins() == frozen
            status.update(state='complete', phase='complete')
    except BaseException as error:
        status.update(state='failed', error=repr(error))
        raise
    finally:
        status['finished_epoch'] = time.time()
        save(STATUS, status)


if __name__ == '__main__':
    main()
