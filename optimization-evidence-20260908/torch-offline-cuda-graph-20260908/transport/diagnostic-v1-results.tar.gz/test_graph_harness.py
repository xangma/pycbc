"""CPU orchestration tests; these never substitute for the native CUDA gate."""
import contextlib
import copy
import json
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

import graph_controller as campaign
import offline_graph as graph
import run_graph


class FakeGraph:
    def __init__(self):
        self.resets = 0

    def reset(self):
        self.resets += 1


def trial(control):
    result = graph.GraphTrial.__new__(graph.GraphTrial)
    result.enabled, result.window, result.segments = True, 64, 1
    result.original_init = lambda *args: None
    result.installed_init = lambda *args: None
    result.controller_class = type('FakeController', (), {'__init__': result.installed_init})
    result.original_capture, result.original_replay = object(), object()
    result.module = SimpleNamespace(capture_symmetric_cuda_graph=graph.capture_symmetric_cuda_graph,
                                   replay_symmetric_cuda_graph=graph.replay_symmetric_cuda_graph)
    result.controllers = [control]
    result.signatures = [{'device': 2}]
    result.closed, result.installed, result.restored = False, True, False
    result.cleanup = []
    return result


class CleanupTests(unittest.TestCase):
    def cleanup_case(self, drift=False, sync_failure=False, partial=False):
        native = FakeGraph()
        control = SimpleNamespace(_cuda_graphs={} if partial else {(0, 64): (native, 'raw', 'square')},
            _offline_graph_bindings={}, _offline_partial_graphs=[{'graph': native}] if partial else [])
        manager = trial(control)
        quarantined_before = len(graph._FAILED_CONTROLS)
        with mock.patch.object(graph, 'assert_binding', side_effect=RuntimeError('drift') if drift else None), \
             mock.patch.object(graph, 'assert_graph_bindings'), \
             mock.patch.object(graph.torch.cuda, 'synchronize',
                               side_effect=RuntimeError('sync') if sync_failure else None) as synchronize:
            if drift or sync_failure:
                with self.assertRaises(RuntimeError):
                    manager.close(require_complete=not partial)
            else:
                manager.close(require_complete=not partial)
            synchronize.assert_called_once_with(2)
        self.assertTrue(manager.closed and manager.restored and not manager.installed)
        self.assertIs(manager.controller_class.__init__, manager.original_init)
        self.assertIs(manager.module.capture_symmetric_cuda_graph, manager.original_capture)
        self.assertEqual(native.resets, 0 if sync_failure else 1)
        if sync_failure:
            self.assertIs(graph._FAILED_CONTROLS[-1], control)
            self.assertTrue(control._cuda_graphs or control._offline_partial_graphs)
            del graph._FAILED_CONTROLS[quarantined_before:]
        else:
            self.assertFalse(control._cuda_graphs or control._offline_partial_graphs)
        with self.assertRaises(RuntimeError):
            manager.close()

    def test_complete_cleanup(self):
        self.cleanup_case()

    def test_binding_failure_still_synchronizes_bound_device_and_restores(self):
        self.cleanup_case(drift=True)

    def test_failed_sync_quarantines_without_reset(self):
        self.cleanup_case(sync_failure=True)

    def test_partial_capture_cleanup(self):
        self.cleanup_case(partial=True)

    def test_failed_capture_retains_native_graph_until_cleanup(self):
        native = FakeGraph()
        stream = SimpleNamespace(wait_stream=mock.Mock())
        cluster = SimpleNamespace(prepare_symmetric_cuda_graph=lambda window: True,
            series=SimpleNamespace(device='cuda:2'),
            symmetric_cuda_graph_step=mock.Mock(side_effect=[None, None, None, RuntimeError('capture')]))
        control = SimpleNamespace(threshold_and_clusterers=[cluster], delta_f=1., snr_threshold=5.,
            correlators=[SimpleNamespace(correlate=mock.Mock())], ifft=SimpleNamespace(execute=mock.Mock()))
        with contextlib.ExitStack() as stack:
            for owner, name, value in (
                (graph.torch, 'tensor', mock.Mock(return_value='raw')),
                (graph.torch, 'empty_like', mock.Mock(return_value='squared')),
                (graph.torch, 'mul', mock.Mock()),
                (graph.torch.cuda, 'Stream', lambda: stream),
                (graph.torch.cuda, 'current_stream', lambda: stream),
                (graph.torch.cuda, 'stream', lambda _: contextlib.nullcontext()),
                (graph.torch.cuda, 'CUDAGraph', lambda: native),
                (graph.torch.cuda, 'graph', lambda _: contextlib.nullcontext())):
                stack.enter_context(mock.patch.object(owner, name, value))
            with self.assertRaisesRegex(RuntimeError, 'capture'):
                graph.capture_symmetric_cuda_graph(control, 0, 64)
        self.assertEqual(len(control._offline_partial_graphs), 1)
        self.assertIs(control._offline_partial_graphs[0]['graph'], native)
        manager = trial(control)
        with mock.patch.object(graph, 'assert_binding'), mock.patch.object(graph, 'assert_graph_bindings'), \
             mock.patch.object(graph.torch.cuda, 'synchronize'):
            manager.close(require_complete=False)
        self.assertEqual(native.resets, 1)
        self.assertEqual(manager.cleanup[0]['partial_graphs'], 1)


class WrapperTests(unittest.TestCase):
    def run_case(self, primary):
        with tempfile.TemporaryDirectory() as temp:
            receipt = Path(temp) / 'receipt.json'
            manager = mock.Mock()
            manager.close.side_effect = RuntimeError('cleanup broke')
            manager.report.return_value = {'closed': True}
            arguments = ['run_graph.py', '--graph', 'yes', '--receipt', str(receipt), '--', 'workload.py']
            with mock.patch.object(run_graph, 'GraphTrial', return_value=manager), \
                 mock.patch.object(run_graph.sys, 'argv', arguments), \
                 mock.patch.object(run_graph.runpy, 'run_path', side_effect=primary):
                expected = KeyError if primary else RuntimeError
                with self.assertRaises(expected) as caught:
                    run_graph.main()
            data = json.loads(receipt.read_text())
            self.assertEqual(data['state'], 'failed')
            self.assertIn('cleanup broke', data['cleanup_error'])
            if primary:
                self.assertIs(caught.exception, primary)
                self.assertIn('workload broke', data['error'])
            manager.close.assert_called_once_with(require_complete=primary is None)

    def test_primary_exception_survives_cleanup_failure(self):
        self.run_case(KeyError('workload broke'))

    def test_cleanup_failure_invalidates_success(self):
        self.run_case(None)


class ReceiptTests(unittest.TestCase):
    def test_graph_receipt_rejects_missing_replays_cleanup_and_geometry(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            binding = dict(device=0, window=4096, length=2097152, cutoffs=[15360, 1048576],
                           geometry=[[458752, 2019328, None]] * 4 + [[475136, 2031616, None]])
            cleanup = dict(device=0, synchronized=True, graph_entries=5, graph_reset_successes=5,
                           partial_graphs=0, bindings=[dict(segment=i, window=4096, blocks=381 if i < 4 else 380,
                           graph=i, tensors={name: [i, 1000 + i] for name in ('raw', 'squared', 'max', 'idx', 'keep')})
                           for i in range(5)])
            data = dict(state='complete', helper_sha256=campaign.sha(campaign.ROOT / 'run_graph.py'),
                graph_helper_sha256=campaign.sha(campaign.ROOT / 'offline_graph.py'),
                trial=dict(closed=True, restored=True, installed=False, enabled=True, window=4096,
                           segments=5, bindings=[binding], cleanup=[cleanup]))
            path = folder / 'graphs.json'
            campaign.save(path, data)
            self.assertEqual(campaign.verify_graphs(folder, 'G')['graphs'], 5)
            changes = [lambda d: d.update(state='failed'),
                       lambda d: d['trial'].update(restored=False),
                       lambda d: d['trial']['cleanup'][0].update(synchronized=False),
                       lambda d: d['trial']['cleanup'][0].update(graph_reset_successes=4),
                       lambda d: d['trial']['cleanup'][0].update(partial_graphs=1),
                       lambda d: d['trial']['bindings'][0].update(length=512),
                       lambda d: d['trial']['cleanup'][0]['bindings'][0].update(blocks=1)]
            for change in changes:
                broken = copy.deepcopy(data)
                change(broken)
                campaign.save(path, broken)
                with self.assertRaises(AssertionError):
                    campaign.verify_graphs(folder, 'G')

    def test_science_byte_gate_rejects_change_within_default_tolerance(self):
        import h5py
        import numpy as np
        reference = Path(campaign.read(campaign.ROOT / 'reference-pins.json')['cuda']['local']) / 'triggers.hdf'
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            left, right = root / 'left', root / 'right'
            left.mkdir()
            right.mkdir()
            for folder in (left, right):
                shutil.copyfile(reference, folder / 'triggers.hdf')
                shutil.copyfile(reference.with_name('receipt.json'), folder / 'receipt.json')
            shutil.copyfile(campaign.ROOT / 'compare-triggers.py', root / 'compare-triggers.py')
            with mock.patch.object(campaign, 'ROOT', root):
                self.assertEqual(campaign.compare('same', left, right, True)['exact_science_datasets'], 18)
                with h5py.File(right / 'triggers.hdf', 'r+') as handle:
                    values = handle['H1/snr'][:]
                    self.assertGreater(len(values), 0)
                    values[0] = np.nextafter(values[0], np.array(float('inf'), dtype=values.dtype))
                    handle['H1/snr'][:] = values
                receipt = campaign.read(right / 'receipt.json')
                receipt['trigger_sha256'] = campaign.sha(right / 'triggers.hdf')
                campaign.save(right / 'receipt.json', receipt)
                campaign.compare('tolerated', left, right, False)
                with self.assertRaises(AssertionError):
                    campaign.compare('byte-drift', left, right, True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
