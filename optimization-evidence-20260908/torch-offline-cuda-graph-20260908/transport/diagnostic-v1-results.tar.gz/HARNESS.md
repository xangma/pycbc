# Closed offline CUDA graph experiment

This artifact executes the frozen OFFLINE-CUDA-GRAPH-PROTOCOL-v1.md on the
unchanged ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f source checkout. Both arms
use the accepted descriptor reuse helper. E runs eager filtering; G captures
the existing correlate, inverse FFT, and symmetric threshold kernels, with
float32 conversion before threshold squaring to match eager arithmetic.

This is an experimental harness for one fixed sequential workload. It is not
a production graph API. There are no source, kernel, pycbc/lib, or C extension
changes. Graph bindings are checked at setup/cleanup and before every untimed
qualification call. The timing replay path adds no diagnostic counters or
per-call validation. Both arms retain the same common wrapper imports/setup.

`manage.py launch` starts one detached process group on len. The controller
holds the inherited benchmark lock throughout native contracts, qualifications,
comparisons, and timings. CPU affinity is core 8 and native thread counts are
one. Existing unrelated GPU processes are recorded in remote-preflight.json;
this trial makes no exclusive-host-idleness claim.

The fixed gate order is native CUDA/Triton contracts, E qualification, G
qualification, then E1/G1, G2/E2, G3/E3, E4/G4. No failed gate can proceed to
timing. Native tests require six actual captures, 30 actual replays, 17 direct
kernel fixtures including the old rounding defect, two real controller stream
fixtures, 12 full-output comparisons, and 48 rejections before replay attempts.
Qualification compares full correlation and SNR bytes for every normal G call
against a fresh eager oracle, along with sparse outputs, ownership/retention,
inputs, bindings, work counts, normalized thresholds, PSDs, and conditioned
strain. All 1,920 normal calls must replay, with exactly five graph captures.
The 1,940 Python IFFT calls in G qualification comprise 1,920 eager oracles
plus three warmups and one capture for each graph. Timings use neither oracle
nor qualification wrapper.

Each timed sample measures the complete fresh child chain through interpreter
exit, including imports, CUDA initialization, graph warmup/capture, search,
veto/output, synchronization, graph reset, descriptor cleanup, and receipts.
Before/after pin hashing and controller comparisons are outside this wall time.
Every science output is checked against its own qualified arm by exact bytes
for all 18 H1 science datasets, against the fixed standard reference using the
unchanged default comparator, and against its contemporaneous paired arm by
exact bytes. Both qualifications are tied to the frozen cached CUDA reference.
Acceptance requires all gates, four strictly positive paired E-G differences,
and median G below median E. All samples and failures are retained; no retry,
resampling, exclusion, or post-result rule changes are allowed in this version.

Each worker has a 1,800-second timeout, terminating the owned process group.
`manage.py status` is read-only. `manage.py stop` validates controller identity
before sending SIGTERM to that group. `manage.py close` requires a terminal
controller state, absence of the entire group, and independent nonblocking
lock reacquisition before writing a terminal audit, complete results manifest,
and archive. These operations use the fixed Python executable recorded in
graph_controller.py. Source and input pins are checked again at closure.

Local CPU tests validate harness failure handling and byte-comparison gates;
they are not native CUDA evidence. The review and local check receipts are
frozen with this harness. Native and timing results do not exist at freeze.
