"""Equal graph-helper setup around one eager or graph inspiral executable."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import sys
import time

from offline_graph import GraphTrial


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--graph", choices=("yes", "no"), required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    assert command and not args.receipt.exists()
    manager = GraphTrial(args.graph == "yes")
    result = dict(state="running", command=command, started_epoch=time.time(),
                  helper_sha256=digest(__file__),
                  graph_helper_sha256=digest(Path(__file__).with_name("offline_graph.py")))
    save(args.receipt, result)
    previous, primary = sys.argv, None
    try:
        manager.install()
        sys.argv = command
        try:
            runpy.run_path(command[0], run_name="__main__")
        except SystemExit as error:
            if error.code not in (0, None):
                raise
    except BaseException as error:
        primary = error
        result.update(state="failed", error=repr(error))
        raise
    finally:
        sys.argv = previous
        try:
            manager.close(require_complete=primary is None)
        except BaseException as error:
            result.update(state="failed", cleanup_error=repr(error))
            if primary is None:
                raise
        finally:
            result.update(trial=manager.report(), finished_epoch=time.time())
            if primary is None and "cleanup_error" not in result:
                result["state"] = "complete"
            save(args.receipt, result)


if __name__ == "__main__":
    main()
