#!/usr/bin/env python3
"""Untimed native CUDA gates for the closed offline graph experiment.

Run only through the campaign's pinned environment, inherited lock and core 8.
Missing CUDA/Triton or an unavailable required fixture is a failure, not a skip.
This worker makes no production-source changes and measures no performance.
"""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import time
import traceback
from unittest import mock


torch = np = offline_graph = None
# A failed device synchronization leaves these owners with interpreter teardown.
_FAILED_DIRECT_GATES = []


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def snapshot(value):
    tensor = value if type(value) is torch.Tensor else value._data.tensor
    array = tensor.detach().cpu().numpy().copy()
    return str(array.dtype), tuple(array.shape), array.tobytes()


def certificate(value):
    dtype, shape, data = value
    return dict(dtype=dtype, shape=shape, nbytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def sparse_snapshot(pair):
    return tuple(snapshot(value) for value in pair)


def verify_retained(retained, report):
    for pair, expected in retained:
        require(sparse_snapshot(pair) == expected, "Retained sparse output changed")
        report["retention_checks"] += 1


def retain(pair, retained, report, forbidden):
    expected = sparse_snapshot(pair)
    for value in pair:
        tensor = value._data.tensor
        if tensor.numel():
            require(tensor.untyped_storage().data_ptr() not in forbidden,
                    "Sparse output aliases reusable storage")
    retained.append((pair, expected))
    verify_retained(retained, report)


class Observation:
    """Count actual successful native replay calls and capture contexts."""
    def __init__(self):
        self.replay_attempts = 0
        self.replays = 0
        self.captures = 0
        self.stack = contextlib.ExitStack()

    def __enter__(self):
        original_replay = torch.cuda.CUDAGraph.replay
        original_context = torch.cuda.graph

        def replay(graph):
            self.replay_attempts += 1
            result = original_replay(graph)
            self.replays += 1
            return result

        @contextlib.contextmanager
        def capture(*args, **kwargs):
            with original_context(*args, **kwargs):
                yield
            self.captures += 1

        self.stack.enter_context(mock.patch.object(torch.cuda.CUDAGraph, "replay", replay))
        self.stack.enter_context(mock.patch.object(torch.cuda, "graph", capture))
        return self

    def __exit__(self, *args):
        return self.stack.__exit__(*args)


def runtime():
    # Keep introspection from changing the inherited duplicate-OpenMP policy,
    # as the campaign's checked executable wrapper does.
    duplicate_policy = os.environ.get("KMP_DUPLICATE_LIB_OK")
    try:
        from threadpoolctl import threadpool_info
    finally:
        if duplicate_policy is None:
            os.environ.pop("KMP_DUPLICATE_LIB_OK", None)
        else:
            os.environ["KMP_DUPLICATE_LIB_OK"] = duplicate_policy
    descriptor = int(os.environ["PYCBC_BENCHMARK_LOCK_FD"])
    stat = os.fstat(descriptor)
    return dict(affinity=sorted(os.sched_getaffinity(0)),
                torch_intra=torch.get_num_threads(),
                torch_inter=torch.get_num_interop_threads(),
                pools=threadpool_info(),
                lock=dict(fd=descriptor, device=stat.st_dev, inode=stat.st_ino,
                          target=os.readlink(f"/proc/self/fd/{descriptor}")))


def assert_runtime(value):
    require(value["affinity"] == [8], "Native gate requires CPU affinity [8]")
    require(value["torch_intra"] == value["torch_inter"] == 1,
            "Torch native gate requires intra/inter threads 1")
    require(bool(value["pools"]), "No native thread pools recorded")
    require(all(pool["num_threads"] == 1 for pool in value["pools"]),
            "Native thread pool is not limited to 1")


def kernel_cases():
    """Fixed payloads exercise rounded thresholds and unchanged eager policies."""
    zero = np.zeros(80, dtype=np.complex64)
    counterexample = zero.copy()
    counterexample[35] = complex(1.0, 0.0003452669770922512)
    yield "rounding-counterexample", counterexample, 1.00000003
    for name, threshold in (
        ("threshold-f32-below", float(np.nextafter(np.float32(1), np.float32(0)))),
        ("threshold-exact-one", 1.0),
        ("threshold-f32-above", float(np.nextafter(np.float32(1), np.float32(2)))),
        ("threshold-zero", 0.0),
        ("threshold-high", 1e6),
        ("threshold-negative", -1.00000003),
        ("threshold-repeat-rounding", 1.00000003),
    ):
        yield name, counterexample.copy(), threshold
    unit = zero.copy()
    unit[35] = 1
    yield "strict-threshold-equality", unit, 1.0
    yield "zero-no-survivors", zero.copy(), 0.0
    alternating = zero.copy()
    alternating[[1, 17, 33, 49, 65]] = 2
    yield "all-eligible-local-maxima", alternating, 0.0
    plateau = zero.copy()
    plateau[[1, 9, 25, 33, 41, 65, 73]] = 2
    yield "boundary-and-interior-ties", plateau, 1.0
    within = zero.copy()
    within[[33, 34, 35, 36]] = 2
    yield "within-block-ties", within, 1.0
    special = zero.copy()
    special[[3, 19, 35, 51, 67]] = [complex(np.nan, 0), complex(np.inf, 0),
                                   complex(0, np.inf), complex(np.nan, np.nan), 3]
    yield "nan-inf-payload", special, 1.0
    yield "infinite-threshold", special.copy(), float("inf")
    yield "nan-threshold", special.copy(), float("nan")
    yield "final-rounding-reuse", counterexample.copy(), 1.00000003


def direct_kernel_gate(observed, report):
    from pycbc.events.threshold_torch import TorchThresholdCluster
    series = torch.zeros(80, device="cuda", dtype=torch.complex64)
    cluster = TorchThresholdCluster(series)
    window = 8
    require(cluster.prepare_symmetric_cuda_graph(window), "Cannot prepare Triton scratch")
    raw = torch.tensor(1.00000003, device="cuda", dtype=torch.float32)
    squared = torch.empty_like(raw)
    old_squared = torch.tensor(1.00000003 ** 2, device="cuda", dtype=torch.float32)
    graphs = []
    retained = []
    before = (observed.captures, observed.replays)
    report.update(cases=[], retention_checks=0, cleanup={})
    tensors = (series, raw, squared, old_squared, cluster._triton_block_max,
               cluster._triton_block_idx, cluster._triton_keep)
    identities = [(id(v), v.data_ptr(), v.untyped_storage().data_ptr()) for v in tensors]
    forbidden = {v.untyped_storage().data_ptr() for v in tensors}
    device = series.device
    capture_stream = None
    primary = None
    try:
        caller = torch.cuda.current_stream()
        capture_stream = torch.cuda.Stream()
        capture_stream.wait_stream(caller)
        with torch.cuda.stream(capture_stream):
            for corrected in (False, True):
                for _ in range(3):
                    if corrected:
                        torch.mul(raw, raw, out=squared)
                    cluster.symmetric_cuda_graph_step(window, squared if corrected else old_squared)
                graph = torch.cuda.CUDAGraph()
                graphs.append(graph)  # Retain even a failed/partial capture until synchronization.
                with torch.cuda.graph(graph):
                    if corrected:
                        torch.mul(raw, raw, out=squared)
                    cluster.symmetric_cuda_graph_step(window, squared if corrected else old_squared)
        caller.wait_stream(capture_stream)
        old_graph, corrected_graph = graphs
        for name, payload, threshold in kernel_cases():
            verify_retained(retained, report)
            series.copy_(torch.from_numpy(payload).to(device))
            eager = cluster.threshold_and_cluster(threshold, window)
            expected = sparse_snapshot(eager)
            eager_power = snapshot(cluster._triton_block_max)
            eager_indices = eager[1]._data.tensor.detach().cpu().tolist()
            retain(eager, retained, report, forbidden)
            raw.fill_(threshold)
            previous = observed.replays
            corrected_graph.replay()
            require(observed.replays == previous + 1, "Corrected graph did not actually replay")
            actual = cluster.symmetric_cuda_graph_result()
            require(sparse_snapshot(actual) == expected, f"Corrected graph differs: {name}")
            require(snapshot(cluster._triton_block_max) == eager_power,
                    f"Block reduction differs: {name}")
            retain(actual, retained, report, forbidden)
            row = dict(name=name, threshold_hex=float(threshold).hex(),
                       input=certificate(snapshot(series)),
                       sparse=[certificate(v) for v in expected],
                       block_max=certificate(eager_power),
                       indices=eager_indices, exact_bytes=True,
                       rounded_square=certificate(snapshot(squared)))
            if name == "rounding-counterexample":
                old_squared.fill_(threshold * threshold)
                previous = observed.replays
                old_graph.replay()
                require(observed.replays == previous + 1, "Old graph did not actually replay")
                old = cluster.symmetric_cuda_graph_result()
                old_indices = old[1]._data.tensor.detach().cpu().tolist()
                require(eager_indices == [35] and old_indices == [],
                        "Native CUDA did not reproduce the old rounding defect")
                require(sparse_snapshot(old) != expected, "Old graph unexpectedly matches")
                corrected_bits = snapshot(squared)[2].hex()
                old_bits = snapshot(old_squared)[2].hex()
                require(corrected_bits == np.float32(1).tobytes().hex()
                        and old_bits == np.nextafter(np.float32(1), np.float32(2)).tobytes().hex(),
                        "Native threshold scalar rounding differs from the fixed counterexample")
                row.update(old_indices=old_indices, old_graph_failed=True,
                           corrected_square_bytes=corrected_bits, old_square_bytes=old_bits,
                           peak_sample_bytes=payload[35].tobytes().hex(),
                           peak_power_bytes=eager_power[2][4 * 4:5 * 4].hex(),
                           old_square=certificate(snapshot(old_squared)),
                           old_sparse=[certificate(v) for v in sparse_snapshot(old)])
            if name in ("zero-no-survivors", "strict-threshold-equality", "threshold-high"):
                require(eager_indices == [], f"Expected empty eager fixture: {name}")
            if name == "all-eligible-local-maxima":
                require(eager_indices == [1, 17, 33, 49, 65], "Local-maximum fixture mismatch")
            require([(id(v), v.data_ptr(), v.untyped_storage().data_ptr()) for v in tensors]
                    == identities, "Direct graph tensor bindings changed")
            report["cases"].append(row)
        verify_retained(retained, report)
        report.update(captures=observed.captures - before[0],
                      replays=observed.replays - before[1], bindings=identities)
        require(report["captures"] == 2 and report["replays"] == len(report["cases"]) + 1,
                "Unexpected direct native graph counts")
    except BaseException as error:
        primary = error
        raise
    finally:
        cleanup = report["cleanup"]
        cleanup.update(device=str(device), synchronized=False, graph_reset_successes=0,
                       quarantined=False)
        try:
            torch.cuda.synchronize(device)
            cleanup["synchronized"] = True
            for graph in graphs:
                graph.reset()
                cleanup["graph_reset_successes"] += 1
        except BaseException as error:
            cleanup["error"] = repr(error)
            if not cleanup["synchronized"]:
                _FAILED_DIRECT_GATES.append(dict(graphs=graphs, tensors=tensors,
                                                 cluster=cluster, stream=capture_stream))
                cleanup["quarantined"] = True
            if primary is None:
                raise


@contextlib.contextmanager
def changed_attribute(owner, attribute, replacement):
    original = getattr(owner, attribute)
    setattr(owner, attribute, replacement)
    try:
        yield
    finally:
        setattr(owner, attribute, original)


@contextlib.contextmanager
def changed_entry(entries, key, replacement):
    original = entries[key]
    entries[key] = replacement
    try:
        yield
    finally:
        entries[key] = original


def negative_gate(control, window, signature, observed, report):
    """All mutations must fail the qualification preflight before native replay."""
    def guarded_call(requested_window=window):
        offline_graph.assert_binding(control, requested_window, signature)
        offline_graph.assert_graph_bindings(control)
        return control.full_matched_filter_and_cluster_symm(0, 1.0, requested_window)

    def rejected(name, mutation, requested_window=window):
        before = (observed.replay_attempts, observed.replays)
        with mutation:
            try:
                guarded_call(requested_window)
            except RuntimeError as error:
                message = str(error)
            else:
                raise RuntimeError(f"Invalid fixture was accepted: {name}")
        require((observed.replay_attempts, observed.replays) == before,
                f"Invalid fixture attempted native replay: {name}")
        offline_graph.assert_binding(control, window, signature)
        offline_graph.assert_graph_bindings(control)
        report.append(dict(name=name, error=message, replay_attempt_delta=0,
                           replay_delta=0, restored=True))

    rejected("window", contextlib.nullcontext(), window + 1)
    correlator = control.correlators[0]
    source = correlator.x
    variants = [
        ("storage-replacement", source.clone()),
        ("shape", source[:-1]),
        ("stride", torch.empty(source.numel() * 2, device=source.device,
                               dtype=source.dtype)[::2]),
        ("dtype", source.to(torch.complex128)),
        ("device", source.cpu()),
        ("lazy-conjugate", source.conj()),
        ("lazy-negative", torch._neg_view(source)),
        ("reverse-ad", source.detach().requires_grad_(True)),
    ]
    with torch.inference_mode():
        variants.append(("inference-tensor", source.clone()))

    class TensorSubclass(torch.Tensor):
        pass

    variants.append(("tensor-subclass", source.as_subclass(TensorSubclass)))
    for name, tensor in variants:
        rejected(name, changed_attribute(correlator, "x", tensor))
    with torch.autograd.forward_ad.dual_level():
        dual = torch.autograd.forward_ad.make_dual(source, torch.zeros_like(source))
        rejected("forward-ad", changed_attribute(correlator, "x", dual))
    rejected("inference-context", torch.inference_mode())
    cluster = control.threshold_and_clusterers[0]
    for attribute in ("_triton_block_max", "_triton_block_idx", "_triton_keep"):
        rejected(attribute, changed_attribute(cluster, attribute, getattr(cluster, attribute).clone()))
    rejected("scratch-block-count", changed_attribute(cluster, "_triton_scratch_nb",
                                                       cluster._triton_scratch_nb + 1))
    entry = control._cuda_graphs[(0, window)]
    for name, position in (("graph-raw-threshold", 1), ("graph-squared-threshold", 2)):
        changed = list(entry)
        changed[position] = entry[position].clone()
        rejected(name, changed_entry(control._cuda_graphs, (0, window), tuple(changed)))
    # Exact graph type and identity are both checked without replaying a proxy.
    rejected("graph-object", changed_entry(control._cuda_graphs, (0, window),
                                           (object(), entry[1], entry[2])))
    rejected("cluster-source-binding", changed_attribute(cluster, "_source", cluster._source.clone()))
    rejected("analysis-slice", changed_attribute(control.segments[0], "analyze",
                                                 slice(257, 3800)))
    rejected("cutoff", changed_attribute(control, "kmin", control.kmin + 1))
    other_stream = torch.cuda.Stream()
    rejected("current-stream", torch.cuda.stream(other_stream))


def control_gate(label, observed, report):
    from pycbc.filter.matchedfilter import MatchedFilterControl
    from pycbc.types import FrequencySeries, zeros
    n, window = 4096, 64
    rng = np.random.default_rng(20260908)
    trial = offline_graph.GraphTrial(True, window=window, segments=2)
    report.update(stream=label, calls=[], negative=[], retention_checks=0)
    before = (observed.captures, observed.replays)
    retained = []
    primary = None
    trial.install()
    try:
        segments = []
        for analysis in (slice(256, 3800), slice(384, 3600)):
            data = (rng.standard_normal(n // 2 + 1)
                    + 1j * rng.standard_normal(n // 2 + 1)).astype(np.complex64)
            segment = FrequencySeries(data, delta_f=1.0)
            segment.analyze = analysis
            segments.append(segment)
        template = zeros(n, dtype=np.complex64)
        control = MatchedFilterControl(16.0, 1400.0, 4.00000012, n, 1.0,
                                       np.complex64, segments, template, True,
                                       cluster_function="symmetric")
        signature = offline_graph.controller_signature(control, window)
        report["initial_binding"] = signature
        offline_graph.assert_graph_bindings(control)
        templates = [(rng.standard_normal(n) + 1j * rng.standard_normal(n)).astype(np.complex64)
                     for _ in range(2)] + [np.zeros(n, dtype=np.complex64)]
        for variant, (payload, template_norm) in enumerate(zip(templates, (1.0, 2.0, 4.0), strict=True)):
            verify_retained(retained, report)
            # Producer is queued on the bound current stream, including the custom case.
            control.htilde._data.tensor.copy_(torch.from_numpy(payload).to("cuda"))
            for segment_index in range(2):
                inputs = (snapshot(control.htilde), snapshot(control.segments[segment_index]))
                with mock.patch.dict(os.environ, {"PYCBC_TORCH_CUDA_GRAPH": "0"}):
                    with changed_attribute(control, "_cuda_graph_enabled", False) if hasattr(
                            control, "_cuda_graph_enabled") else mock.patch.object(
                                control, "_cuda_graph_enabled", False, create=True):
                        eager = control.full_matched_filter_and_cluster_symm(
                            segment_index, template_norm, window)
                expected_full = (snapshot(control.corr_mem), snapshot(control.snr_mem))
                empty = len(eager[3]) == 0
                expected_sparse = () if empty else sparse_snapshot(eager[3:])
                if not empty:
                    retain(eager[3:], retained, report, {
                        control.snr_mem._data.tensor.untyped_storage().data_ptr(),
                        control.corr_mem._data.tensor.untyped_storage().data_ptr()})
                offline_graph.assert_binding(control, window, signature)
                offline_graph.assert_graph_bindings(control)
                # Requeue a producer after host-side oracle snapshots. No host
                # synchronization is inserted between this copy and replay.
                control.htilde._data.tensor.zero_()
                control.htilde._data.tensor.copy_(torch.from_numpy(payload).to("cuda"))
                previous = observed.replays
                actual = control.full_matched_filter_and_cluster_symm(
                    segment_index, template_norm, window)
                require(observed.replays == previous + 1, "Full controller did not replay graph")
                # Consumers are enqueued on that same bound stream before the
                # following host comparisons synchronize their results.
                consumed_full = (control.corr_mem._data.tensor.clone(),
                                 control.snr_mem._data.tensor.clone())
                require(tuple(snapshot(value) for value in consumed_full) == expected_full,
                        "Ordered graph consumer differs from eager oracle")
                require((snapshot(control.corr_mem), snapshot(control.snr_mem)) == expected_full,
                        "Full correlation/SNR bytes changed")
                require((snapshot(control.htilde), snapshot(control.segments[segment_index])) == inputs,
                        "Graph changed input bytes")
                if empty:
                    require(all(type(value) is list and not value for value in actual),
                            "Empty result contract changed")
                else:
                    require(actual[1] == eager[1], "Normalization changed")
                    require(sparse_snapshot(actual[3:]) == expected_sparse, "Sparse bytes changed")
                    require(actual[0]._data.tensor.data_ptr() == control.snr_mem._data.tensor.data_ptr()
                            and actual[2]._data.tensor.data_ptr() == control.corr_mem._data.tensor.data_ptr(),
                            "Full output alias contract changed")
                    cluster = control.threshold_and_clusterers[segment_index]
                    retain(actual[3:], retained, report, {
                        value.untyped_storage().data_ptr() for value in (
                            control.snr_mem._data.tensor, control.corr_mem._data.tensor,
                            cluster._triton_block_max, cluster._triton_block_idx, cluster._triton_keep)})
                verify_retained(retained, report)
                offline_graph.assert_binding(control, window, signature)
                offline_graph.assert_graph_bindings(control)
                report["calls"].append(dict(template_variant=variant, template_norm=template_norm,
                    segment=segment_index, empty=empty, norm=None if empty else actual[1],
                    inputs=[certificate(value) for value in inputs],
                    full=[certificate(value) for value in expected_full],
                    sparse=[certificate(value) for value in expected_sparse],
                    full_bytes_equal=True, sparse_bytes_equal=True, inputs_unchanged=True,
                    producer_queued_before_replay=True, ordered_consumer_bytes_equal=True))
        require(any(not row["empty"] for row in report["calls"]), "No nonempty real-control fixture")
        require(all(row["empty"] for row in report["calls"] if row["template_variant"] == 2),
                "Zero template should produce no survivors")
        require(len({row["inputs"][0]["sha256"] for row in report["calls"]}) == 3,
                "Templates did not change")
        require(len({row["inputs"][1]["sha256"] for row in report["calls"]}) == 2,
                "Segments did not change")
        negative_gate(control, window, signature, observed, report["negative"])
        verify_retained(retained, report)
        report.update(captures=observed.captures - before[0], replays=observed.replays - before[1],
                      final_graph_bindings=[dict(segment=key[0], window=key[1], **value)
                                            for key, value in control._offline_graph_bindings.items()])
        require(report["captures"] == 2 and report["replays"] == 6,
                "Unexpected real-control native graph counts")
    except BaseException as error:
        primary = error
        raise
    finally:
        try:
            trial.close(require_complete=primary is None)
        except BaseException as error:
            report["cleanup_error"] = repr(error)
            if primary is None:
                raise
        finally:
            report["trial"] = trial.report()


def main():
    global torch, np, offline_graph
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    # Exclusive reservation prevents overwriting any earlier gate evidence.
    with args.output.open("x"):
        pass
    report = dict(schema_version=1, status="running", host=socket.gethostname(),
                  pid=os.getpid(), pgid=os.getpgid(0), cwd=os.getcwd(),
                  argv=sys.argv, started_unix=time.time(),
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  controls=[])
    exit_code = 1
    try:
        import torch
        import numpy as np
        report["runtime_before_thread_configuration"] = runtime()
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        report["runtime_after_thread_configuration"] = runtime()
        assert_runtime(report["runtime_after_thread_configuration"])
        import offline_graph
        import pycbc
        from pycbc.events.threshold_torch import _TRITON_AVAILABLE
        from pycbc.scheme import TorchScheme
        require(torch.cuda.is_available() and _TRITON_AVAILABLE, "Native CUDA and Triton are required")
        report["software"] = dict(torch=torch.__version__, cuda=torch.version.cuda,
                                   pycbc_file=pycbc.__file__, helper_file=offline_graph.__file__,
                                   helper_sha256=hashlib.sha256(Path(offline_graph.__file__).read_bytes()).hexdigest())
        with mock.patch.dict(os.environ, {"PYCBC_TORCH_CUDA_GRAPH": "1"}):
            with TorchScheme(device="cuda:0", num_threads=1):
                require(torch.cuda.current_stream() == torch.cuda.default_stream(),
                        "Fresh worker did not start on default CUDA stream")
                report["device"] = dict(index=torch.cuda.current_device(),
                                         name=torch.cuda.get_device_name(),
                                         capability=torch.cuda.get_device_capability())
                report["runtime_before_native"] = runtime()
                assert_runtime(report["runtime_before_native"])
                with Observation() as observed:
                    report["direct_kernel"] = {}
                    direct_kernel_gate(observed, report["direct_kernel"])
                    for label in ("default", "custom"):
                        row = {}
                        report["controls"].append(row)
                        caller = torch.cuda.current_stream()
                        selected = caller if label == "default" else torch.cuda.Stream()
                        selected.wait_stream(caller)
                        with torch.cuda.stream(selected):
                            control_gate(label, observed, row)
                        caller.wait_stream(selected)
                    report["observed"] = dict(captures=observed.captures, replays=observed.replays,
                                              replay_attempts=observed.replay_attempts)
                    require(observed.replay_attempts == observed.replays,
                            "A native replay attempt did not complete")
                torch.cuda.synchronize(0)
        report["runtime_final"] = runtime()
        assert_runtime(report["runtime_final"])
        require(report["runtime_final"]["lock"] == report["runtime_before_thread_configuration"]["lock"],
                "Inherited benchmark lock identity changed")
        report["status"] = "passed"
        exit_code = 0
    except BaseException as error:
        report.update(status="failed", error=repr(error), traceback=traceback.format_exc())
        try:
            if torch is not None:
                report["runtime_on_failure"] = runtime()
        except BaseException as runtime_error:
            report["runtime_receipt_error"] = repr(runtime_error)
    finally:
        report["finished_unix"] = time.time()
        temporary = args.output.with_name(args.output.name + f".{os.getpid()}.tmp")
        with temporary.open("x") as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write("\n")
        temporary.replace(args.output)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
