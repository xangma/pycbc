"""One fresh eager or graph child; whole-child wall includes every wrapper."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/xangma/pycbc-torch-fft-optimization-20260908/loader-v1/source-candidate')
BANK = Path('/home/xangma/pycbc-torch-reference-protocol-20260907/inputs/bank-compressed.hdf')
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def source_record():
    return dict(commit=subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip(),
                status=subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'], text=True),
                tracked_diff=subprocess.check_output(['git', '-C', str(SOURCE), 'diff', 'HEAD', '--'], text=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', required=True)
    parser.add_argument('--arm', choices=('E', 'G'), required=True)
    parser.add_argument('--mode', choices=('qualify', 'timing'), required=True)
    args = parser.parse_args()
    assert Path(args.case).name == args.case
    config_path = ROOT / ('config-' + args.arm + '.json')
    cfg = json.loads(config_path.read_text())
    lock_fd = int(os.environ['PYCBC_BENCHMARK_LOCK_FD'])
    actual, expected = os.fstat(lock_fd), LOCK.stat()
    assert lock_fd >= 3 and stat.S_ISREG(actual.st_mode)
    assert (actual.st_dev, actual.st_ino) == (expected.st_dev, expected.st_ino)
    fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    out = ROOT / 'runs' / args.case
    out.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location('checked_inspiral', ROOT / 'checked-inspiral.py')
    runtime = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime)
    fixed_env = runtime.fixed_environment(cfg, SOURCE)
    env = runtime.clean_environment(os.environ, cfg, SOURCE)
    cli = [str(SOURCE / 'bin/pycbc_inspiral'), *cfg['common_args'],
           '--bank-file', str(BANK), '--processing-scheme', 'torch:cuda:0',
           '--segment-length', '512', '--segment-start-pad', '112', '--segment-end-pad', '16',
           '--output', str(out / 'triggers.hdf')]
    workload = cli
    if args.mode == 'qualify':
        qualifier = ROOT / ('qualify_graph.py' if args.arm == 'G' else 'qualify-inspiral.py')
        workload = [str(qualifier), '--receipt', str(out / 'qualification.json'), '--', *cli]
    graph_command = [str(ROOT / 'run_graph.py'), '--graph', 'yes' if args.arm == 'G' else 'no',
                    '--receipt', str(out / 'graphs.json'), '--', *workload]
    reuse_command = [str(ROOT / 'run_reuse.py'), '--reuse', 'yes',
                    '--receipt', str(out / 'descriptors.json'), '--', *graph_command]
    command = ['/usr/bin/time', '-v', '-o', str(out / 'time.txt'),
               'taskset', '-c', str(cfg['core']), sys.executable,
               str(ROOT / 'checked-inspiral.py'), '--receipt', str(out / 'runtime.json'),
               '--config', str(config_path), '--source', str(SOURCE),
               '--scheme', 'torch:cuda:0', '--lock-fd', str(lock_fd), '--', *reuse_command]
    before_source = source_record()
    assert before_source['status'] == before_source['tracked_diff'] == ''
    inputs = [ROOT / name for name in json.loads((ROOT / 'manifest.json').read_text())]
    inputs += [ROOT / 'manifest.json', BANK, SOURCE / 'bin/pycbc_inspiral', *map(Path, cfg['input_files'])]
    record = dict(case=args.case, arm=args.arm, mode=args.mode, scheme='torch:cuda:0', reuse='yes',
                  segment_length=512, start_pad=112, end_pad=16, source=str(SOURCE),
                  source_info=before_source, command=command, executable_cli=cli,
                  graph_command=graph_command, reuse_command=reuse_command,
                  environment=fixed_env, hostname=os.uname().nodename, cwd=str(ROOT),
                  parent_pid=os.getpid(), inherited_lock=dict(path=str(LOCK), fd=lock_fd),
                  input_sha256={str(path): digest(path) for path in inputs},
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), state='running')

    def save():
        path = out / 'receipt.json'
        temp = path.with_suffix('.tmp')
        temp.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
        temp.replace(path)

    save()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (out / 'stdout.log').open('x') as stdout, (out / 'stderr.log').open('x') as stderr:
        start = time.perf_counter()
        child = subprocess.Popen(command, cwd=ROOT, env=env, pass_fds=(lock_fd,),
                                 stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL)
        record['child_pid'] = child.pid
        save()
        code = child.wait()
        elapsed = time.perf_counter() - start
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    record.update(state='complete' if code == 0 else 'failed', returncode=code,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  elapsed_wall_seconds=elapsed, child_user_cpu_seconds=after.ru_utime - before.ru_utime,
                  child_system_cpu_seconds=after.ru_stime - before.ru_stime, peak_child_rss_kib=after.ru_maxrss,
                  input_sha256_after={str(path): digest(path) for path in inputs},
                  source_status_after=source_record()['status'])
    if record['input_sha256_after'] != record['input_sha256'] or source_record() != before_source:
        record['state'], code = 'invalid-input-mutation', 1
    for name, key in [('runtime.json', 'runtime_sha256'), ('triggers.hdf', 'trigger_sha256')]:
        if (out / name).exists():
            record[key] = digest(out / name)
        else:
            record['state'], code = 'missing-required-output', 1
    save()
    print(json.dumps(record))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
