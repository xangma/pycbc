"""Artifact-only offline graph trial on an unchanged, pinned source checkout.

The capture sequence is the source implementation with only eager threshold
rounding restored. This is not a general graph API: the runner and untimed
qualification require fixed storage, one window and sequential consumers.
"""
import os
import threading
from math import sqrt

import torch

# A failed device synchronization leaves ownership with interpreter teardown.
_FAILED_CONTROLS = []


def capture_symmetric_cuda_graph(control, segnum, window, template_norm=1.0):
    """Capture existing kernels with float32 conversion before squaring."""
    clusterer = control.threshold_and_clusterers[segnum]
    if not hasattr(
        clusterer, "prepare_symmetric_cuda_graph"
    ) or not clusterer.prepare_symmetric_cuda_graph(window):
        return False

    norm = (4.0 * control.delta_f) / sqrt(template_norm)
    threshold = float(control.snr_threshold / norm)
    graph_threshold = torch.tensor(
        threshold, device=clusterer.series.device, dtype=torch.float32
    )
    graph_threshold_squared = torch.empty_like(graph_threshold)
    correlator = control.correlators[segnum]
    inverse_fft = control.ifft

    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    if not hasattr(control, "_offline_partial_graphs"):
        control._offline_partial_graphs = []
    partial = dict(graph=None, raw=graph_threshold, squared=graph_threshold_squared,
                   stream=stream)
    control._offline_partial_graphs.append(partial)
    with torch.cuda.stream(stream):
        for _ in range(3):
            correlator.correlate()
            inverse_fft.execute()
            torch.mul(graph_threshold, graph_threshold, out=graph_threshold_squared)
            clusterer.symmetric_cuda_graph_step(window, graph_threshold_squared)
        graph = torch.cuda.CUDAGraph()
        partial["graph"] = graph
        with torch.cuda.graph(graph):
            correlator.correlate()
            inverse_fft.execute()
            torch.mul(graph_threshold, graph_threshold, out=graph_threshold_squared)
            clusterer.symmetric_cuda_graph_step(window, graph_threshold_squared)
    torch.cuda.current_stream().wait_stream(stream)

    if not hasattr(control, "_cuda_graphs"):
        control._cuda_graphs = {}
    control._cuda_graphs[(segnum, window)] = (
        graph, graph_threshold, graph_threshold_squared
    )
    if not hasattr(control, "_offline_graph_bindings"):
        control._offline_graph_bindings = {}
    control._offline_graph_bindings[(segnum, window)] = graph_signature(control, segnum, window)
    control._offline_partial_graphs.remove(partial)
    control._cuda_graph_enabled = True
    return True


def replay_symmetric_cuda_graph(control, segnum, window, template_norm, threshold):
    """Fill raw float32 threshold, then replay its captured square and kernels."""
    graph_key = (segnum, window)
    if not hasattr(control, "_cuda_graphs"):
        control._cuda_graphs = {}
    if graph_key not in control._cuda_graphs:
        if not capture_symmetric_cuda_graph(control, segnum, window, template_norm):
            raise RuntimeError("The closed graph trial cannot fall back to eager")

    graph, graph_threshold, _ = control._cuda_graphs[graph_key]
    graph_threshold.fill_(float(threshold))
    graph.replay()
    return control.threshold_and_clusterers[segnum].symmetric_cuda_graph_result()


def tensor_signature(tensor):
    """Reject unsupported semantics before returning fixed binding metadata."""
    if not (
        type(tensor) is torch.Tensor
        and tensor.layout == torch.strided
        and tensor.device.type == "cuda"
        and tensor.dtype == torch.complex64
        and tensor.ndim == 1 and tensor.numel() > 0
        and tensor.is_contiguous()
        and not tensor.requires_grad
        and not torch.is_inference(tensor)
        and not tensor.is_conj() and not tensor.is_neg()
        and torch.autograd.forward_ad.unpack_dual(tensor).tangent is None
        and not torch.is_inference_mode_enabled()
    ):
        raise RuntimeError("Ineligible tensor in closed offline graph trial")
    return (id(tensor), tensor.data_ptr(), tuple(tensor.shape), tuple(tensor.stride()),
            tensor.storage_offset(), str(tensor.dtype), str(tensor.device),
            tensor.untyped_storage().data_ptr(), tensor.untyped_storage().nbytes())


def controller_signature(control, window):
    """Untimed qualification/setup guard; never called by the replay hot path."""
    from pycbc.events.threshold_torch import TorchThresholdCluster, _TRITON_AVAILABLE
    from pycbc.fft.torchfft import IFFT
    from pycbc.filter.matchedfilter_torch import TorchCorrelator
    from pycbc.filter.matchedfilter import MatchedFilterControl

    if (type(control) is not MatchedFilterControl
            or type(window) is not int or window <= 0 or not _TRITON_AVAILABLE
            or control.cluster_function != "symmetric"
            or type(control.ifft) is not IFFT or control.ifft.nbatch != 1
            or len(control.correlators) != len(control.segments)
            or len(control.threshold_and_clusterers) != len(control.segments)):
        raise RuntimeError("Ineligible controller in closed offline graph trial")
    tensors = {name: getattr(control, name)._data.tensor
               for name in ("htilde", "corr_mem", "snr_mem")}
    tensors.update(ifft_input=control.ifft.invec._data.tensor,
                   ifft_output=control.ifft.outvec._data.tensor)
    for role, bound in (("ifft_input", "corr_mem"), ("ifft_output", "snr_mem")):
        if (tensors[role].data_ptr() != tensors[bound].data_ptr()
                or tensors[role].shape != tensors[bound].shape):
            raise RuntimeError("FFT is not bound to original full buffers")
    corr, snr = tensors["corr_mem"], tensors["snr_mem"]
    if (corr.numel() != control.tlen or snr.numel() != control.tlen
            or max(corr.data_ptr(), snr.data_ptr())
            < min(corr.data_ptr() + corr.numel() * corr.element_size(),
                  snr.data_ptr() + snr.numel() * snr.element_size())):
        raise RuntimeError("Invalid/overlapping correlation and SNR storage")
    geometry = []
    for index, (segment, correlator, clusterer) in enumerate(zip(
        control.segments, control.correlators, control.threshold_and_clusterers,
        strict=True,
    )):
        if type(correlator) is not TorchCorrelator or type(clusterer) is not TorchThresholdCluster:
            raise RuntimeError("Unexpected correlator or clusterer")
        for name in ("x", "y", "z"):
            tensors[f"{index}:correlator:{name}"] = getattr(correlator, name)
        tensors[f"{index}:segment"] = segment._data.tensor
        tensors[f"{index}:cluster"] = clusterer.series
        tensors[f"{index}:cluster_source"] = clusterer._source
        for role, original in (("x", tensors["htilde"]), ("y", segment._data.tensor),
                               ("z", tensors["corr_mem"])):
            value = getattr(correlator, role)
            if (not 0 <= control.kmin < control.kmax <= original.numel()
                    or value.data_ptr() != original.data_ptr() + control.kmin * original.element_size()
                    or value.numel() != control.kmax - control.kmin):
                raise RuntimeError("Correlator cutoff slice alias changed")
        analysis = segment.analyze
        if (analysis.step not in (None, 1)
                or not 0 <= analysis.start < analysis.stop <= control.tlen
                or clusterer.series is not clusterer._source
                or clusterer.series.data_ptr() != snr.data_ptr() + analysis.start * snr.element_size()
                or clusterer.series.numel() != analysis.stop - analysis.start):
            raise RuntimeError("Clusterer analysis slice alias changed")
        geometry.append((segment.analyze.start, segment.analyze.stop, segment.analyze.step))
    signatures = {name: tensor_signature(value) for name, value in tensors.items()}
    devices = {tensor.device for tensor in tensors.values()}
    if len(devices) != 1 or torch.cuda.current_device() != tensors["snr_mem"].device.index:
        raise RuntimeError("Unexpected current CUDA device")
    return dict(tensors=signatures, geometry=geometry,
                objects=(id(control), id(control.ifft),
                         tuple(map(id, control.correlators)),
                         tuple(map(id, control.threshold_and_clusterers))),
                thread=threading.get_ident(),
                stream=int(torch.cuda.current_stream().cuda_stream),
                device=torch.cuda.current_device(), window=window,
                cutoffs=(control.kmin, control.kmax),
                length=control.tlen, delta_f=control.delta_f, delta_t=control.delta_t)


def assert_binding(control, window, expected):
    if controller_signature(control, window) != expected:
        raise RuntimeError("Offline graph binding/window/stream drift before replay")


def graph_signature(control, segnum, window):
    """Capture/boundary metadata for persistent threshold and reduction scratch."""
    graph, raw, squared = control._cuda_graphs[(segnum, window)]
    if type(graph) is not torch.cuda.CUDAGraph:
        raise RuntimeError("Expected a real CUDA graph")
    cluster = control.threshold_and_clusterers[segnum]
    blocks = (cluster.series.numel() + window - 1) // window
    if cluster._triton_scratch_nb != blocks:
        raise RuntimeError("Graph scratch block count changed")
    values = (("raw", raw, torch.float32, ()),
              ("squared", squared, torch.float32, ()),
              ("max", cluster._triton_block_max, torch.float32, (blocks,)),
              ("idx", cluster._triton_block_idx, torch.int64, (blocks,)),
              ("keep", cluster._triton_keep, torch.bool, (blocks,)))
    result = dict(graph=id(graph), blocks=blocks, tensors={})
    for name, tensor, dtype, shape in values:
        if not (type(tensor) is torch.Tensor and tensor.layout == torch.strided
                and tensor.device == cluster.series.device and tensor.dtype == dtype
                and tuple(tensor.shape) == shape and tensor.is_contiguous()
                and not tensor.requires_grad and not torch.is_inference(tensor)
                and not tensor.is_conj() and not tensor.is_neg()
                and torch.autograd.forward_ad.unpack_dual(tensor).tangent is None):
            raise RuntimeError("Invalid graph threshold/scratch tensor")
        result["tensors"][name] = (id(tensor), tensor.data_ptr(), shape,
                                   tuple(tensor.stride()), tensor.storage_offset(),
                                   str(dtype), str(tensor.device),
                                   tensor.untyped_storage().data_ptr(),
                                   tensor.untyped_storage().nbytes())
    return result


def assert_graph_bindings(control):
    entries = getattr(control, "_cuda_graphs", {})
    bindings = getattr(control, "_offline_graph_bindings", {})
    if set(entries) != set(bindings):
        raise RuntimeError("Graph entry/binding keys changed")
    for (segnum, window), expected in bindings.items():
        if graph_signature(control, segnum, window) != expected:
            raise RuntimeError("Graph threshold/scratch binding drift before replay")


class GraphTrial:
    """Equal setup/cleanup on both arms, corrected graph enabled only on G."""
    def __init__(self, enabled, window=4096, segments=5):
        from pycbc.filter import matchedfilter, matchedfilter_torch
        self.enabled, self.window, self.segments = enabled, window, segments
        self.module = matchedfilter_torch
        self.controller_class = matchedfilter.MatchedFilterControl
        self.original_init = self.controller_class.__init__
        self.original_capture = self.module.capture_symmetric_cuda_graph
        self.original_replay = self.module.replay_symmetric_cuda_graph
        self.controllers = []
        self.signatures = []
        self.closed = False
        self.installed = False
        self.cleanup = []
        self.restored = False

    def install(self):
        if self.installed or self.closed:
            raise RuntimeError("GraphTrial cannot be reused")
        # Runtime configuration supplies this value before the checked runner.
        if os.environ.get("PYCBC_TORCH_CUDA_GRAPH") != ("1" if self.enabled else "0"):
            raise RuntimeError("Graph environment does not match trial arm")
        original_init = self.original_init

        def initialize(control, *args, **kwargs):
            original_init(control, *args, **kwargs)
            if self.controllers or len(control.segments) != self.segments:
                raise RuntimeError("Expected one fixed offline controller")
            signature = controller_signature(control, self.window)
            self.controllers.append(control)
            self.signatures.append(signature)

        self.installed_init = initialize
        self.controller_class.__init__ = initialize
        if self.enabled:
            self.module.capture_symmetric_cuda_graph = capture_symmetric_cuda_graph
            self.module.replay_symmetric_cuda_graph = replay_symmetric_cuda_graph
        self.installed = True

    def close(self, *, require_complete=True):
        if self.closed:
            raise RuntimeError("GraphTrial already closed")
        errors = []
        try:
            if self.installed:
                expected_capture = capture_symmetric_cuda_graph if self.enabled else self.original_capture
                expected_replay = replay_symmetric_cuda_graph if self.enabled else self.original_replay
                if (self.controller_class.__init__ is not self.installed_init
                        or self.module.capture_symmetric_cuda_graph is not expected_capture
                        or self.module.replay_symmetric_cuda_graph is not expected_replay):
                    errors.append(RuntimeError("Graph trial hook identity changed"))
            if require_complete and len(self.controllers) != 1:
                errors.append(RuntimeError("Missing graph trial controller"))
            for control, signature in zip(self.controllers, self.signatures, strict=True):
                entries = getattr(control, "_cuda_graphs", {})
                expected = {(seg, self.window) for seg in range(self.segments)} if self.enabled else set()
                count = len(entries)
                synchronized = False
                resets = 0
                partials = getattr(control, "_offline_partial_graphs", [])
                try:
                    assert_binding(control, self.window, signature)
                    assert_graph_bindings(control)
                    if require_complete and set(entries) != expected:
                        raise RuntimeError("Missing/unexpected graph captures")
                    if require_complete and partials:
                        raise RuntimeError("Unfinished partial graph capture")
                except BaseException as error:
                    errors.append(error)
                try:
                    torch.cuda.synchronize(signature["device"])
                    synchronized = True
                except BaseException as error:
                    errors.append(error)
                partial_count = len(partials)
                graphs = [value[0] for value in entries.values()] + [
                    value["graph"] for value in partials if value["graph"] is not None]
                if synchronized:
                    for graph in graphs:
                        try:
                            graph.reset()
                            resets += 1
                        except BaseException as error:
                            errors.append(error)
                    entries.clear()
                    partials.clear()
                else:
                    _FAILED_CONTROLS.append(control)
                control._cuda_graph_enabled = False
                self.cleanup.append(dict(graph_entries=count, partial_graphs=partial_count,
                                         graph_reset_successes=resets, synchronized=synchronized,
                                         device=signature["device"],
                                         bindings=[dict(segment=key[0], window=key[1], **value)
                                                   for key, value in getattr(
                                                       control, "_offline_graph_bindings", {}).items()]))
        finally:
            self.controller_class.__init__ = self.original_init
            self.module.capture_symmetric_cuda_graph = self.original_capture
            self.module.replay_symmetric_cuda_graph = self.original_replay
            self.restored = (self.controller_class.__init__ is self.original_init
                             and self.module.capture_symmetric_cuda_graph is self.original_capture
                             and self.module.replay_symmetric_cuda_graph is self.original_replay)
            self.controllers.clear()
            self.installed = False
            self.closed = True
        if errors:
            raise RuntimeError(f"Graph trial cleanup failed: {errors!r}") from errors[0]

    def report(self):
        return dict(enabled=self.enabled, window=self.window, segments=self.segments,
                    bindings=self.signatures, cleanup=self.cleanup,
                    closed=self.closed, installed=self.installed, restored=self.restored)
