"""Read installed header ABI without building or executing a native program."""
import ctypes
import hashlib
import json
import platform
from pathlib import Path
import subprocess

source = r'''
#include <mkl_dfti.h>
_Static_assert(sizeof(MKL_LONG) == 8, "MKL_LONG width");
_Static_assert(sizeof(long) == sizeof(MKL_LONG), "ctypes c_long width");
_Static_assert(sizeof(enum DFTI_CONFIG_PARAM) == 4, "parameter enum width");
_Static_assert(sizeof(enum DFTI_CONFIG_VALUE) == 4, "value enum width");
_Static_assert(DFTI_WORKSPACE == 17 && DFTI_ALLOW == 51 && DFTI_AVOID == 52, "policy enums");
_Static_assert(_Generic(DftiCommitDescriptor((DFTI_DESCRIPTOR_HANDLE)0), long: 1, default: 0), "commit status");
_Static_assert(_Generic(DftiSetValue((DFTI_DESCRIPTOR_HANDLE)0, DFTI_WORKSPACE, DFTI_AVOID), long: 1, default: 0), "set status");
_Static_assert(_Generic(DftiGetValue((DFTI_DESCRIPTOR_HANDLE)0, DFTI_WORKSPACE, (enum DFTI_CONFIG_VALUE*)0), long: 1, default: 0), "get status");
'''
command = ['cc', '-std=c11', '-Wall', '-Werror', '-I/usr/include/mkl', '-x', 'c', '-fsyntax-only', '-']
result = subprocess.run(command, input=source, text=True, capture_output=True, timeout=30)
files = []
for name in ('mkl_dfti.h', 'mkl_types.h'):
    path = Path('/usr/include/mkl') / name
    files.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'text': path.read_text()})
record = {'host': platform.node(), 'machine': platform.machine(), 'command': command,
          'source': source, 'exit': result.returncode, 'stdout': result.stdout,
          'stderr': result.stderr, 'headers': files,
          'packages': subprocess.check_output(['dpkg-query', '-W', 'libmkl-dev', 'libmkl-rt']).decode(),
          'ctypes_bytes': {'c_long': ctypes.sizeof(ctypes.c_long), 'c_int': ctypes.sizeof(ctypes.c_int)},
          'interpretation': 'LP64 MKL_LONG status uses c_long; enums use four-byte c_int representation. '
          'DftiGetValue output depends on the property; WORKSPACE is DFTI_CONFIG_VALUE. '
          'Static checking of variadic calls does not establish runtime output write width; native contracts check surrounding canaries.',
          'documentation': ['https://www.intel.com/content/www/us/en/docs/onemkl/developer-reference-c/2025-1/dftigetvalue.html',
                            'https://www.intel.com/content/www/us/en/docs/onemkl/developer-reference-c/2024-1/dfti-workspace.html']}
print(json.dumps(record, indent=2))
assert result.returncode == 0 and record['ctypes_bytes'] == {'c_long': 8, 'c_int': 4}
