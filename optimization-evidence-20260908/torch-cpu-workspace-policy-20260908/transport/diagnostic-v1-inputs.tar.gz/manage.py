"""Owner-only launch, read-only status, and independent terminal sealing."""
import argparse
import fcntl
import json
import os
import signal
from pathlib import Path
import subprocess
import tarfile
import time

import workspace_controller as campaign

ROOT = Path(__file__).resolve().parent


def exclusive_json(path, record):
    with path.open('x') as handle:
        json.dump(record, handle, indent=2, allow_nan=False)
        handle.write('\n')


def group_members(pgid):
    members = []
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            stat = path.read_text().rsplit(')', 1)[1].split()
        except FileNotFoundError:
            continue
        if int(stat[2]) == pgid:
            members.append({'pid': int(path.parent.name), 'state': stat[0], 'start_ticks': stat[19]})
    return members


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('launch', 'status', 'stop', 'close'))
    args = parser.parse_args()
    if args.action == 'launch':
        assert not any((ROOT / name).exists() for name in ('launch.json', 'workspace-status.json', 'controller.log'))
        with campaign.LOCK.open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            pins = campaign.pins()
        # The controller independently reacquires before any native/science work.
        # A competing owner makes that controller fail closed.
        command = [campaign.PYTHON, '-B', str(ROOT / 'workspace_controller.py')]
        with (ROOT / 'controller.log').open('x') as output:
            child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        stat = Path(f'/proc/{child.pid}/stat').read_text().rsplit(')', 1)[1].split()
        record = {'pid': child.pid, 'pgid': os.getpgid(child.pid), 'start_ticks': stat[19],
                  'epoch': time.time(), 'command': command, 'cwd': str(ROOT),
                  'log': str(ROOT / 'controller.log'), 'pins': pins}
        assert record['pid'] == record['pgid']
        exclusive_json(ROOT / 'launch.json', record)
        print(json.dumps(record))
        return
    launch = campaign.read(ROOT / 'launch.json')
    status = campaign.read(campaign.STATUS) if campaign.STATUS.exists() else {}
    members = group_members(launch['pgid'])
    if args.action == 'status':
        result = {'state': status.get('state'), 'error': status.get('error'), 'members': members,
                  'workers': [{k: w[k] for k in ('name', 'pid', 'exit', 'started_epoch', 'finished_epoch') if k in w}
                              for w in status.get('workers', [])],
                  'comparisons': list(status.get('comparisons', {}))}
        if status.get('state') == 'failed':
            paths = [ROOT / 'controller.log'] + [Path(w['log']) for w in status.get('workers', [])]
            paths += sorted(ROOT.glob('runs/*/stderr.log'))
            result['log_tails'] = {str(p.relative_to(ROOT)): p.read_text()[-6000:] for p in paths if p.exists()}
        print(json.dumps(result))
        return
    if args.action == 'stop':
        assert status['pid'] == launch['pid'] and status['pgid'] == launch['pgid']
        assert status['start_ticks'] == launch['start_ticks']
        assert any(row['pid'] == launch['pid'] and row['start_ticks'] == launch['start_ticks'] for row in members)
        exclusive_json(ROOT / 'stop-request.json', dict(epoch=time.time(), controller=launch, members=members))
        os.killpg(launch['pgid'], signal.SIGTERM)
        print(json.dumps(dict(state='stop-requested', pgid=launch['pgid'])))
        return
    assert status['state'] in ('complete', 'failed', 'rejected'), status.get('state')
    assert not members, members
    assert status['pid'] == launch['pid'] and status['pgid'] == launch['pgid']
    assert status['start_ticks'] == launch['start_ticks']
    with campaign.LOCK.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not group_members(launch['pgid'])
        pins = campaign.pins()
        assert pins == launch['pins']
        audit = {'state': 'complete', 'campaign_state': status['state'],
                 'auditor_pid': os.getpid(), 'epoch': time.time(), 'controller': launch,
                 'whole_process_group_absent': True, 'lock_reacquired_nonblocking': True,
                 'status_sha256': campaign.sha(campaign.STATUS), 'final_pins': pins}
        exclusive_json(ROOT / 'terminal-audit.json', audit)
        files = sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
        assert all(not p.is_symlink() for p in files)
        manifest = {str(p.relative_to(ROOT)): campaign.sha(p) for p in files}
        exclusive_json(ROOT / 'results-manifest.json', manifest)
        files.append(ROOT / 'results-manifest.json')
        archive = ROOT.parent / (ROOT.name + '-results.tar')
        with tarfile.open(archive, 'x') as target:
            for path in files:
                target.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
        print(json.dumps({'state': 'sealed', 'campaign_state': status['state'],
            'archive': str(archive), 'bytes': archive.stat().st_size, 'members': len(files),
            'archive_sha256': campaign.sha(archive), 'manifest_sha256': campaign.sha(ROOT / 'results-manifest.json')}))


if __name__ == '__main__':
    main()
