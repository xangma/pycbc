"""Closed CPU diagnostic: set MKL auxiliary-workspace policy before commit.

The production constructor, Tensor allocations, guards, execute and finalizer
remain unchanged. This request does not prove that MKL allocates no scratch.
"""
from contextlib import contextmanager
import ctypes

import torch


SIZE = 2**21
MODES = ('original', 'avoid')


def _bind(function, *arguments):
    """Use a private ABI wrapper without changing the CDLL symbol signature."""
    address = ctypes.cast(function, ctypes.c_void_p).value
    if not address:
        raise ValueError('null native function address')
    # Installed Linux MKL headers define MKL_LONG as long, verified at 8 bytes.
    return ctypes.CFUNCTYPE(ctypes.c_long, *arguments)(address)


def workspace_value(mkl, descriptor, events=None, label='boundary_get'):
    """Read only the enum-valued DFTI_WORKSPACE property."""
    get_value = _bind(mkl.lib.DftiGetValue, ctypes.c_void_p, ctypes.c_int,
                      ctypes.POINTER(ctypes.c_int))
    value = ctypes.c_int(-1)
    event = {'operation': label, 'descriptor': descriptor.value}
    if events is not None:
        events.append(event)
    status = get_value(descriptor, mkl.DFTI_WORKSPACE, ctypes.byref(value))
    event.update(status=status, value=value.value)
    mkl.check_status(status)
    return value.value


class _Commit:
    def __init__(self, mkl, mode, receipt):
        self.mkl = mkl
        self.mode = mode
        self.calls = 0
        self.receipt = receipt
        self._set = _bind(mkl.lib.DftiSetValue, ctypes.c_void_p,
                          ctypes.c_int, ctypes.c_int)
        self._commit = _bind(mkl.lib.DftiCommitDescriptor, ctypes.c_void_p)

    def __call__(self, descriptor):
        assert self.calls == 0, 'only one descriptor per construction scope'
        self.calls += 1
        mkl = self.mkl
        events = self.receipt['events']
        self.receipt.update(commit_intercepts=self.calls, descriptor=descriptor.value)
        before = workspace_value(mkl, descriptor, events, 'initial_get')
        assert before == mkl.DFTI_ALLOW, ('default workspace', before)
        expected = mkl.DFTI_ALLOW
        if self.mode == 'avoid':
            expected = mkl.DFTI_AVOID
            event = {'operation': 'workspace_set', 'descriptor': descriptor.value,
                     'parameter': mkl.DFTI_WORKSPACE, 'value': expected}
            events.append(event)
            status = self._set(descriptor, mkl.DFTI_WORKSPACE, expected)
            event['status'] = status
            mkl.check_status(status)
        before_commit = workspace_value(mkl, descriptor, events, 'precommit_get')
        assert before_commit == expected, ('precommit workspace', before_commit)
        event = {'operation': 'commit', 'descriptor': descriptor.value}
        events.append(event)
        status = self._commit(descriptor)
        event['status'] = status
        mkl.check_status(status)
        after_commit = workspace_value(mkl, descriptor, events, 'postcommit_get')
        assert after_commit == expected, ('postcommit workspace', after_commit)
        return status


class _Library:
    def __init__(self, mkl, mode, receipt):
        self.original = mkl.lib
        self.DftiCommitDescriptor = _Commit(mkl, mode, receipt)

    def __getattr__(self, name):
        return getattr(self.original, name)


class _Module:
    def __init__(self, mkl, mode, receipt):
        self.original = mkl
        self.lib = _Library(mkl, mode, receipt)

    def __getattr__(self, name):
        return getattr(self.original, name)


def make_plan(original, mkl, size, source, target, nthreads=None, *, promote=False,
              mode, receipt):
    assert size == SIZE and promote
    assert (torch.get_num_threads() if nthreads is None else int(nthreads)) == 1
    assert torch.get_num_threads() == torch.get_num_interop_threads() == 1
    assert ctypes.sizeof(ctypes.c_long) == 8 and ctypes.sizeof(ctypes.c_int) == 4
    assert (mkl.DFTI_WORKSPACE, mkl.DFTI_ALLOW, mkl.DFTI_AVOID) == (17, 51, 52)
    for tensor in (source, target):
        assert tensor.is_cpu and tensor.dtype == torch.complex64
        assert tensor.shape == (SIZE,) and tensor.is_contiguous()
    proxy = _Module(mkl, mode, receipt)
    plan = original(proxy, size, source, target, nthreads, promote=promote)
    try:
        assert plan._promote and plan._inplace
        assert plan._native_source is plan._native_target
        assert proxy.lib.DftiCommitDescriptor.calls == 1
        plan._workspace_policy_receipt = receipt
        return plan
    except BaseException:
        # The original constructor owns failures within itself. After it has
        # returned, explicitly invoke its idempotent native finalizer here.
        plan._finalizer()
        raise


@contextmanager
def construction_mode(torchfft, mode):
    """Install one constructor factory for a serial, fixed-size diagnostic."""
    if mode not in MODES:
        raise ValueError(mode)
    original = torchfft._MKLCPUDirectIFFTPlan
    original_init = original.__init__
    original_methods = original.execute, original.can_execute
    original_empty = torch.empty
    calls = []
    receipt = {'mode': mode, 'events': [], 'commit_intercepts': 0}

    def factory(*args, **kwargs):
        assert not calls, 'only one plan may be constructed in this scope'
        calls.append(True)
        return make_plan(original, *args, **kwargs, mode=mode, receipt=receipt)

    torchfft._MKLCPUDirectIFFTPlan = factory
    try:
        yield receipt
        assert len(calls) == 1
    except BaseException as error:
        receipt['error'] = repr(error)
        raise
    finally:
        torchfft._MKLCPUDirectIFFTPlan = original
        assert original.__init__ is original_init and torch.empty is original_empty
        assert (original.execute, original.can_execute) == original_methods
