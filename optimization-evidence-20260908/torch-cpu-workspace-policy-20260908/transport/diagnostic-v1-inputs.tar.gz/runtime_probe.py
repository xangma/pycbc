"""Read-only import/thread/library preflight; no descriptor or FFT execution."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import sys

SOURCE = Path('/home/xangma/pycbc-torch-fft-optimization-20260908/loader-v1/source-candidate')
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
            'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[key] = '1'
os.environ['MKL_DYNAMIC'] = 'FALSE'
os.environ['MKL_THREADING_LAYER'] = 'GNU'
os.sched_setaffinity(0, {8})
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, '/home/xangma/pycbc-torch-cpu-page-backing-20260908/diagnostic-v2')
import torch
import numpy
import threadpoolctl
import pycbc
from pycbc.fft import mkl, fftw
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
assert Path(pycbc.__file__).resolve().parent.parent == SOURCE


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def library(function):
    class Info(ctypes.Structure):
        _fields_ = [('fname', ctypes.c_char_p), ('base', ctypes.c_void_p),
                    ('sname', ctypes.c_char_p), ('saddr', ctypes.c_void_p)]
    query = ctypes.CDLL(None).dladdr
    query.argtypes = [ctypes.c_void_p, ctypes.POINTER(Info)]
    query.restype = ctypes.c_int
    info = Info()
    assert query(ctypes.cast(function, ctypes.c_void_p), ctypes.byref(info))
    return str(Path(os.fsdecode(info.fname)).resolve(strict=True))


pools = threadpoolctl.threadpool_info()
assert pools and all(p['num_threads'] == 1 for p in pools)
paths = {str(Path(x).resolve(strict=True)) for x in (
    sys.executable, torch.__file__, torch._C.__file__, numpy.__file__,
    *[p['filepath'] for p in pools])}
symbols = {name: library(getattr(mkl.lib, name)) for name in (
    'DftiSetValue', 'DftiGetValue', 'DftiCommitDescriptor', 'DftiComputeBackward')}
paths.update(symbols.values())
paths.update((library(fftw.float_lib.fftwf_execute_dft), library(fftw.double_lib.fftw_execute_dft)))
record = {'host': platform.node(), 'source': str(SOURCE),
          'affinity': sorted(os.sched_getaffinity(0)), 'threads': [torch.get_num_threads(), torch.get_num_interop_threads()],
          'pools': pools, 'symbols': symbols,
          'smt_siblings': Path('/sys/devices/system/cpu/cpu8/topology/thread_siblings_list').read_text().strip(),
          'sha256': {p: sha(p) for p in sorted(paths)},
          'threadpoolctl_sha256': sha(threadpoolctl.__file__),
          'source_sha256': {str(p.relative_to(SOURCE)): sha(p) for p in sorted((SOURCE / 'pycbc').rglob('*')) if p.suffix in ('.py', '.so')},
          'versions': {'python': sys.version, 'torch': torch.__version__, 'numpy': numpy.__version__},
          'no_descriptor_or_fft_execution': True}
print(json.dumps(record, indent=2))
