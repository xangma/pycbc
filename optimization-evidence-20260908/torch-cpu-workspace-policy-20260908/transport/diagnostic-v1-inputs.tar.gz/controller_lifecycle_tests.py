"""Mock child failures verify controller cleanup without creating any child."""
from contextlib import ExitStack
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest.mock import patch

import workspace_controller as c


def check(case):
    events = []
    saves = []

    class Process:
        pid = 999999

        def __init__(self, *args, **kwargs):
            events.append('spawn')
            self.waits = 0

        def terminate(self):
            events.append('terminate')

        def kill(self):
            events.append('kill')

        def wait(self, timeout):
            events.append(['wait', timeout])
            self.waits += 1
            if case == 'signal' and self.waits == 1:
                raise SystemExit('simulated SIGTERM handler')
            if case == 'timeout' and self.waits == 1 or case == 'kill' and self.waits <= 2:
                raise subprocess.TimeoutExpired('synthetic', timeout)
            return -15

    class ProcStat:
        def __init__(self, value):
            self.value = value

        def read_text(self):
            if case == 'proc-stat' and self.value != '/proc/self/stat':
                raise OSError('simulated proc stat failure')
            return '123 (fixture) ' + ' '.join(['R'] + ['0']*18 + ['999'])

    def path(value):
        return ProcStat(value) if str(value).startswith('/proc/') else Path(value)

    def getpgid(pid):
        if case == 'pgid':
            raise OSError('simulated getpgid failure')
        return 888888

    real_save = c.save

    def save(target, value):
        saves.append(value.get('phase'))
        if case == 'status-save' and len(saves) == 3:
            raise OSError('simulated first child status save failure')
        real_save(target, value)

    with tempfile.TemporaryDirectory(prefix='workspace-controller-test-') as directory, ExitStack() as stack:
        root = Path(directory)
        lock = root/'lock'
        lock.touch()
        for name, value in {'ROOT': root, 'STATUS': root/'status.json', 'LOCK': lock,
                            'PYTHON': sys.executable, 'Path': path, 'pins': lambda: {}, 'save': save}.items():
            stack.enter_context(patch.object(c, name, value))
        stack.enter_context(patch.object(c.os, 'sched_setaffinity', lambda *a: None, create=True))
        stack.enter_context(patch.object(c.os, 'getpgid', getpgid))
        stack.enter_context(patch.object(c.signal, 'signal', lambda *a: None))
        stack.enter_context(patch.object(c.subprocess, 'Popen', Process))
        try:
            c.main()
        except (OSError, SystemExit, subprocess.TimeoutExpired):
            pass
        else:
            raise AssertionError('failure was suppressed')
        status = json.loads((root/'status.json').read_text())
        assert status['state'] == 'failed' and len(status['workers']) == 1
        assert status['workers'][0]['pid'] == Process.pid
        assert status['workers'][0]['exit'] == -15
        assert events.count('spawn') == events.count('terminate') == 1
        assert events[-1] == ['wait', 5]
        assert ('kill' in events) == (case == 'kill')
        return {'case': case, 'events': events, 'terminal_state': status['state'],
                'child_recorded_and_reaped': True, 'no_second_child': True}


if __name__ == '__main__':
    rows = [check(case) for case in ('pgid', 'proc-stat', 'status-save', 'timeout', 'signal', 'kill')]
    output = Path(sys.argv[1])
    assert not output.exists()
    output.write_text(json.dumps({'state': 'complete', 'mocked_children_only': True,
        'checks': rows, 'controller_sha256': c.sha(c.__file__), 'tests_sha256': c.sha(__file__)}, indent=2)+'\n')
    print(len(rows), 'controller cleanup failures handled; no real children created')
