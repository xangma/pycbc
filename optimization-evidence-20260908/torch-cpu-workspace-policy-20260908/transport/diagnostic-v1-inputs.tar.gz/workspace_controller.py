"""Owner-locked contracts and precision gate, then exactly three workers."""
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/xangma/pycbc-torch-fft-optimization-20260908/loader-v1/source-candidate')
PYTHON = '/home/xangma/pycbc-torch-split-20260905/venv/bin/python'
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
STATUS = ROOT / 'workspace-status.json'
COMMIT = 'ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f'
ARMS = ('unproxied', 'original', 'avoid')
CASES = [(s, p, v) for s in (7, 91, 812, 20260906)
         for p in ('dense', 'banded', 'impulse') for v in (1e-12, 1., 1e12)]


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def save(path, record):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    temp.replace(path)


def pins():
    for name, expected in read(ROOT / 'manifest.json').items():
        assert sha(ROOT / name) == expected, name
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD']).decode().strip() == COMMIT
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'])
    runtime = read(ROOT / 'runtime-pins.json')
    actual = {str(p.relative_to(SOURCE)): sha(p) for p in sorted((SOURCE / 'pycbc').rglob('*')) if p.suffix in ('.py', '.so')}
    assert actual == runtime['source_sha256']
    for name, expected in read(ROOT / 'source-pins.json').items():
        assert sha(SOURCE / name) == expected, name
    for library in read(ROOT / 'library-pins.json').values():
        assert sha(library['path']) == library['sha256']
    for path, expected in runtime['sha256'].items():
        assert sha(path) == expected, path
    for header in read(ROOT / 'abi-reference.json')['headers']:
        assert sha(header['path']) == header['sha256']
    return {name: sha(ROOT / name) for name in ('manifest.json', 'runtime-pins.json',
            'source-pins.json', 'library-pins.json', 'abi-reference.json',
            'schedule.json', 'CPU-DFTI-WORKSPACE-PROTOCOL-v2.md')}


def validate_result(result, mode, rotation):
    assert result['state'] == 'complete' and result['all_432_precision_cases_passed']
    assert result['mode'] == mode and result['rotation'] == rotation
    schedule = read(ROOT / 'schedule.json')
    assert result['schedule'] == schedule
    assert result['construction_order'] == schedule['construction'][rotation] + ['unproxied']
    for key, filename in (('helper_sha256', 'workspace_worker.py'),
        ('policy_helper_sha256', 'workspace_policy.py'), ('protocol_sha256', 'CPU-DFTI-WORKSPACE-PROTOCOL-v2.md'),
        ('qualification_helper_sha256', 'qualify_runtime.py'), ('schedule_sha256', 'schedule.json'),
        ('abi_reference_sha256', 'abi-reference.json')):
        assert result[key] == sha(ROOT / filename)
    reference = read(ROOT / 'runtime-reference.json')
    for key in ('versions', 'environment', 'libraries'):
        assert result[key] == reference[key]
    assert result['torch_threads'] == [1, 1] and result['cpu_affinity'] == [8]
    assert result['source_state']['head'] == COMMIT and not result['source_state']['source_status']
    source_hashes = dict(result['source_state']['python_sha256'], **result['source_state']['native_sha256'])
    assert source_hashes == read(ROOT / 'runtime-pins.json')['source_sha256']
    assert set(result['qualification']) == {'before_engine', 'before_native', 'after_engine', 'after_native'}
    for rows in result['qualification'].values():
        assert [(r['seed'], r['pattern'], r['scale'], r['arm']) for r in rows] == [(*case, arm) for case in CASES for arm in ARMS]
        for row in rows:
            assert all(row[key] for key in ('passed', 'bitwise_unproxied_native', 'bitwise_unproxied_final',
                       'bitwise_matching_precision_mkl', 'input_preserved', 'versions_passed'))
            assert row['native_nbytes'] == 2**21*16 and row['final_nbytes'] == 2**21*8
            assert set(row['candidate']) == set(row['reference']) == {'l2', 'max_abs'}
            assert all(math.isfinite(row['candidate'][k]) and 0 <= row['candidate'][k] <= row['reference'][k] for k in row['candidate'])
        for offset in range(0, len(rows), 3):
            for key in ('native_sha256', 'final_sha256'):
                assert len({r[key] for r in rows[offset:offset+3]}) == 1
    for arm in ARMS:
        setup = result['setup'][arm]
        assert setup['public_storage_resizable'] == [False, False]
        workspace = setup['workspace']
        assert workspace['size'] == [2**21] and workspace['stride'] == [1]
        assert workspace['dtype'] == 'torch.complex128' and workspace['device'] == 'cpu'
        assert workspace['nbytes'] == workspace['storage_nbytes'] == 2**21*16
        assert workspace['storage_offset'] == 0 and workspace['resizable']
        expected = 52 if arm == 'avoid' else 51
        for boundary in (setup['first_boundary'], result['final_boundary'][arm]):
            assert boundary['workspace_value'] == boundary['getter']['value'] == expected
            assert boundary['getter']['status'] == 0
            assert boundary['runtime_identity'] == result['runtime_identity'][arm]
        if arm != 'unproxied':
            receipt = setup['construction_receipt']
            assert receipt['mode'] == arm and receipt['commit_intercepts'] == 1 and 'error' not in receipt
            operations = ['initial_get'] + (['workspace_set'] if arm == 'avoid' else []) + ['precommit_get', 'commit', 'postcommit_get']
            assert [e['operation'] for e in receipt['events']] == operations
            for event in receipt['events']:
                assert event['status'] == 0 and event['descriptor'] == receipt['descriptor']
                if 'value' in event:
                    assert event['value'] == (51 if event['operation'] == 'initial_get' else expected)
        cleanup = result['cleanup'][arm]
        assert cleanup['finalizer_inactive'] and cleanup['released'] == {'plan': True, 'native': True}
    expected_blocks = [(path, block, schedule['labels'][label], order)
        for path in ('engine', 'native') for block, order in enumerate(schedule[path][rotation]) for label in order] if mode == 'timing' else []
    assert [(b['path'], b['block'], b['arm'], b['order']) for b in result['blocks']] == expected_blocks
    samples = {path: {arm: [] for arm in ARMS[1:]} for path in ('engine', 'native')}
    for block in result['blocks']:
        arm = block['arm']
        assert block['warmups'] == 3 and block['input_versions_and_exact_outputs_passed']
        timing = block['timing']
        raw = timing['samples_seconds']
        assert len(raw) == 15 and all(math.isfinite(v) and v > 0 for v in raw)
        assert timing['median_seconds'] == statistics.median(raw)
        assert timing['range_seconds'] == [min(raw), max(raw)]
        for label in ('before', 'after'):
            boundary = block[label]
            assert boundary['workspace_value'] == boundary['getter']['value'] == (52 if arm == 'avoid' else 51)
            assert boundary['getter']['status'] == 0
            assert boundary['runtime_identity'] == result['runtime_identity'][arm]
        v = block['before']['versions']
        assert block['after']['versions'] == [v[0], v[1]+18, v[2]+36]
        samples[block['path']][arm].extend(raw)
    if mode == 'timing':
        assert all(len(values) == 60 for arms in samples.values() for values in arms.values())
        return {path: {arm: statistics.median(values) for arm, values in arms.items()} for path, arms in samples.items()}


def main():
    assert not STATUS.exists() and Path(sys.executable).resolve() == Path(PYTHON).resolve()
    os.sched_setaffinity(0, {8})
    env = {key: os.environ[key] for key in ('HOME', 'USER', 'LOGNAME', 'PATH', 'LANG') if key in os.environ}
    env.update({key: '1' for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
        'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS')})
    env.update(MKL_DYNAMIC='FALSE', MKL_THREADING_LAYER='GNU', PYTHONHASHSEED='0',
               PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    status = {'state': 'starting', 'pid': os.getpid(), 'pgid': os.getpgrp(),
              'start_ticks': Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
              'started_epoch': time.time(), 'workers': [], 'environment': env}
    save(STATUS, status)

    def terminated(signum, frame):
        raise SystemExit(f'Campaign terminated by signal {signum}')

    signal.signal(signal.SIGTERM, terminated)
    try:
        with LOCK.open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            frozen = pins()
            stat = os.fstat(lock.fileno())
            status.update(state='running', phase='native-contracts', pins=frozen,
                          lock={'path': str(LOCK), 'fd': lock.fileno(), 'device': stat.st_dev, 'inode': stat.st_ino})
            save(STATUS, status)

            def run(name, helper, arguments):
                assert pins() == frozen
                command = [PYTHON, '-B', str(ROOT / 'worker_receipt.py'), '--source', str(SOURCE),
                           '--receipt', str(ROOT / (name+'-receipt.json')), '--helper', str(ROOT / helper),
                           '--', '--source', str(SOURCE), '--output', str(ROOT / (name+'.json')), *arguments]
                log = ROOT / (name+'.log')
                worker = {'name': name, 'command': command, 'cwd': str(SOURCE), 'log': str(log), 'started_epoch': time.time()}
                with log.open('x') as output:
                    process = subprocess.Popen(command, cwd=SOURCE,
                        env=dict(env, PYCBC_BENCHMARK_LOCK_FD=str(lock.fileno())), stdin=subprocess.DEVNULL,
                        stdout=output, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),))
                    try:
                        worker.update(pid=process.pid, pgid=os.getpgid(process.pid),
                            start_ticks=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')', 1)[1].split()[19])
                        status['workers'].append(worker)
                        save(STATUS, status)
                        worker['exit'] = process.wait(timeout=600)
                    except BaseException:
                        # These helpers create no children. Stop and reap the exact
                        # retained child before releasing our inherited lock FD.
                        process.terminate()
                        try:
                            worker['exit'] = process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            worker['exit'] = process.wait(timeout=5)
                        raise
                    finally:
                        worker.setdefault('pid', process.pid)
                        if worker not in status['workers']:
                            status['workers'].append(worker)
                        worker.update(finished_epoch=time.time(), log_sha256=sha(log))
                        save(STATUS, status)
                assert worker['exit'] == 0, worker
                assert pins() == frozen
                receipt = read(ROOT / (name+'-receipt.json'))
                result = read(ROOT / (name+'.json'))
                assert receipt['state'] == 'complete'
                assert receipt['pid'] == result['pid'] == worker['pid']
                assert receipt['pgid'] == worker['pgid'] == status['pgid']
                assert receipt['start_ticks'] == worker['start_ticks']
                assert receipt['helper_sha256'] == sha(ROOT / helper)
                assert receipt['wrapper_sha256'] == sha(ROOT / 'worker_receipt.py')
                runtime = read(ROOT / 'runtime-pins.json')
                assert receipt['threadpoolctl_sha256'] == runtime['threadpoolctl_sha256']
                for point in ('before', 'after'):
                    snap = receipt[point]
                    assert snap['torch_intraop_threads'] == snap['torch_interop_threads'] == 1 and snap['cpu_affinity'] == [8]
                    assert sorted(snap['native_pools'], key=lambda p: p['filepath']) == sorted(runtime['pools'], key=lambda p: p['filepath'])
                    assert snap['runtime_pins_sha256'] == frozen['runtime-pins.json']
                    assert snap['lock'] == dict(status['lock'], competing_open_blocked=True)
                worker.update(result_sha256=sha(ROOT / (name+'.json')), receipt_sha256=sha(ROOT / (name+'-receipt.json')))
                save(STATUS, status)
                return result

            contracts = run('native-contracts', 'workspace_contracts.py', ['--native'])
            assert contracts['state'] == 'complete' and contracts['native']
            assert len(contracts['checks']) == 15 and len(contracts['failures']) == 14
            assert contracts['helper_sha256'] == sha(ROOT / 'workspace_policy.py')
            medians = []
            for name, mode, rotation in [('qualification', 'qualify', 0)] + [(f'timing-{i+1}', 'timing', i) for i in range(3)]:
                status['phase'] = name
                save(STATUS, status)
                result = run(name, 'workspace_worker.py', ['--mode', mode, '--rotation', str(rotation)])
                if result['state'] == 'rejected':
                    status.update(state='rejected', error=result['error'])
                    return
                values = validate_result(result, mode, rotation)
                if values:
                    medians.append(values)
                if mode == 'qualify':
                    status['qualification_gate_epoch'] = time.time()
                    save(STATUS, status)
            assert len(medians) == 3 and pins() == frozen
            accepted = all(row[path]['avoid'] < row[path]['original'] for row in medians for path in ('engine', 'native'))
            save(ROOT / 'timing-summary.json', {'worker_medians': medians, 'accepted': accepted,
                'decision': 'advance' if accepted else 'stop: mixed or non-improving medians; no selective rerun'})
            status.update(state='complete', phase='complete', accepted=accepted)
    except BaseException as error:
        status.update(state='failed', error=repr(error))
        raise
    finally:
        status['finished_epoch'] = time.time()
        save(STATUS, status)


if __name__ == '__main__':
    main()
