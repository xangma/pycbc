"""Synthetic receipts test fail-closed result validation; no native execution."""
import copy
import json
from pathlib import Path
import sys

import workspace_controller as c


def fixture(mode='timing', rotation=0):
    schedule = c.read(c.ROOT / 'schedule.json')
    runtime = c.read(c.ROOT / 'runtime-pins.json')
    result = dict(state='complete', all_432_precision_cases_passed=True, mode=mode, rotation=rotation,
                  schedule=schedule, construction_order=schedule['construction'][rotation]+['unproxied'],
                  torch_threads=[1, 1], cpu_affinity=[8], setup={}, final_boundary={},
                  runtime_identity={}, cleanup={}, qualification={}, blocks=[])
    result.update(c.read(c.ROOT / 'runtime-reference.json'))
    result['source_state'] = {'head': c.COMMIT, 'source_status': '',
        'python_sha256': {p: s for p, s in runtime['source_sha256'].items() if p.endswith('.py')},
        'native_sha256': {p: s for p, s in runtime['source_sha256'].items() if p.endswith('.so')}}
    for key, name in (('helper_sha256', 'workspace_worker.py'), ('policy_helper_sha256', 'workspace_policy.py'),
        ('protocol_sha256', 'CPU-DFTI-WORKSPACE-PROTOCOL-v2.md'), ('qualification_helper_sha256', 'qualify_runtime.py'),
        ('schedule_sha256', 'schedule.json'), ('abi_reference_sha256', 'abi-reference.json')):
        result[key] = c.sha(c.ROOT / name)
    for phase in ('before_engine', 'before_native', 'after_engine', 'after_native'):
        result['qualification'][phase] = [dict(seed=s, pattern=p, scale=v, arm=arm,
            reference={'l2': 2., 'max_abs': 1.}, candidate={'l2': 1., 'max_abs': .5},
            native_nbytes=2**21*16, final_nbytes=2**21*8, native_sha256='a'*64, final_sha256='b'*64,
            passed=True, bitwise_unproxied_native=True, bitwise_unproxied_final=True,
            bitwise_matching_precision_mkl=True, input_preserved=True, versions_passed=True)
            for s, p, v in c.CASES for arm in c.ARMS]
    for index, arm in enumerate(c.ARMS):
        value = 52 if arm == 'avoid' else 51
        identity = {'descriptor': index+1}
        result['runtime_identity'][arm] = identity
        boundary = {'workspace_value': value, 'getter': {'value': value, 'status': 0},
                    'runtime_identity': identity, 'versions': [0, 0, 0]}
        setup = {'public_storage_resizable': [False, False], 'workspace': {'size': [2**21], 'stride': [1],
            'dtype': 'torch.complex128', 'device': 'cpu', 'nbytes': 2**21*16, 'storage_nbytes': 2**21*16,
            'storage_offset': 0, 'resizable': True}, 'first_boundary': copy.deepcopy(boundary)}
        if arm != 'unproxied':
            operations = ['initial_get'] + (['workspace_set'] if arm == 'avoid' else []) + ['precommit_get', 'commit', 'postcommit_get']
            events = [{'operation': op, 'descriptor': index+1, 'status': 0,
                **({'value': 51 if op == 'initial_get' else value} if op != 'commit' else {})} for op in operations]
            setup['construction_receipt'] = {'mode': arm, 'commit_intercepts': 1, 'descriptor': index+1, 'events': events}
        result['setup'][arm] = setup
        result['final_boundary'][arm] = boundary
        result['cleanup'][arm] = {'finalizer_inactive': True, 'released': {'plan': True, 'native': True}}
    if mode == 'timing':
        for path in ('engine', 'native'):
            for block, order in enumerate(schedule[path][rotation]):
                for label in order:
                    arm = schedule['labels'][label]
                    before = copy.deepcopy(result['final_boundary'][arm])
                    after = copy.deepcopy(before)
                    after['versions'] = [0, 18, 36]
                    value = .02 if arm == 'avoid' else .03
                    result['blocks'].append(dict(path=path, block=block, arm=arm, order=order, warmups=3,
                        input_versions_and_exact_outputs_passed=True, before=before, after=after,
                        timing={'samples_seconds': [value]*15, 'median_seconds': value, 'range_seconds': [value, value]}))
    return result


def main():
    successes, failures = [], []
    for mode, rotation in [('qualify', 0)] + [('timing', i) for i in range(3)]:
        c.validate_result(fixture(mode, rotation), mode, rotation)
        successes.append([mode, rotation])
    mutations = [
        ('rejected exit-zero worker', lambda r: r.update(state='rejected')),
        ('failed worker', lambda r: r.update(state='failed')),
        ('missing case', lambda r: r['qualification']['before_engine'].pop()),
        ('case order', lambda r: r['qualification']['before_native'].reverse()),
        ('false native parity', lambda r: r['qualification']['before_engine'][2].update(bitwise_unproxied_native=False)),
        ('hash mismatch', lambda r: r['qualification']['before_engine'][2].update(native_sha256='c'*64)),
        ('error regression', lambda r: r['qualification']['after_engine'][2]['candidate'].update(l2=10.)),
        ('nonfinite error', lambda r: r['qualification']['after_native'][2]['candidate'].update(l2=float('nan'))),
        ('stale helper', lambda r: r.update(helper_sha256='bad')),
        ('stale source', lambda r: r['source_state']['python_sha256'].update({'pycbc/fft/torchfft.py': 'bad'})),
        ('policy readback', lambda r: r['setup']['avoid']['construction_receipt']['events'][-1].update(value=51)),
        ('policy failed status', lambda r: r['setup']['avoid']['construction_receipt']['events'][-1].update(status=123)),
        ('resized workspace', lambda r: r['setup']['avoid']['workspace'].update(storage_nbytes=1)),
        ('retained owner', lambda r: r['cleanup']['avoid']['released'].update(plan=False)),
        ('unbalanced order', lambda r: r['blocks'][0].update(order='BA')),
        ('missing sample', lambda r: r['blocks'][0]['timing']['samples_seconds'].pop()),
        ('nonfinite timing', lambda r: r['blocks'][0]['timing']['samples_seconds'].__setitem__(0, float('nan'))),
        ('modified version', lambda r: r['blocks'][0]['after']['versions'].__setitem__(0, 1)),
        ('extra block', lambda r: r['blocks'].append(copy.deepcopy(r['blocks'][0]))),
    ]
    for label, mutate in mutations:
        result = fixture()
        mutate(result)
        try:
            c.validate_result(result, 'timing', 0)
        except AssertionError:
            failures.append(label)
        else:
            raise AssertionError('accepted invalid fixture: ' + label)
    output = Path(sys.argv[1])
    assert not output.exists()
    output.write_text(json.dumps({'state': 'complete', 'synthetic_only': True,
        'valid_schedules': successes, 'rejected_mutations': failures,
        'controller_sha256': c.sha(c.__file__), 'tests_sha256': c.sha(__file__)}, indent=2)+'\n')
    print(len(successes), 'valid schedules;', len(failures), 'rejected invalid receipts')


if __name__ == '__main__':
    main()
