"""Test the original plan with fake ABI calls or the pinned native MKL library."""
import argparse
import ctypes as c
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import types
from unittest.mock import patch
import weakref

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--native', action='store_true')
args = parser.parse_args()
sys.path.insert(0, str(args.source.resolve(strict=True)))
import torch
from pycbc.fft import torchfft
import workspace_policy as p

torch.set_num_threads(1)
if torch.get_num_interop_threads() != 1:
    torch.set_num_interop_threads(1)
assert not args.output.exists()
original_class = torchfft._MKLCPUDirectIFFTPlan
original_init = original_class.__init__
original_empty = torch.empty
original_methods = original_class.execute, original_class.can_execute
record = {'state': 'running', 'native': args.native, 'pid': os.getpid(),
          'checks': [], 'failures': [], 'constructions': [],
          'helper_sha256': hashlib.sha256(Path(p.__file__).read_bytes()).hexdigest(),
          'contracts_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'source_sha256': hashlib.sha256(Path(torchfft.__file__).read_bytes()).hexdigest()}
assert record['source_sha256'] == '0b9109bbf99a4eb591a4c006b1220ec36c8587e56352352277eb1478cf876c0c'


class Call:
    def __init__(self, function, label, owner):
        self.function, self.label, self.owner = function, label, owner

    def __setattr__(self, key, value):
        if key in ('argtypes', 'restype'):
            setattr(self.function, key, value)
        object.__setattr__(self, key, value)

    def __call__(self, *a):
        self.owner.log.append(self.label)
        status = self.function(*a)
        return self.owner.error if self.owner.fail == self.label else status


class MKL:
    def __init__(self, fail=None):
        self.log, self.fail, self.gets, self.value = [], fail, 0, 51
        self.error = 2**32 + 123 if fail == 'wide_status' else 123
        if args.native:
            from pycbc.fft import mkl
            base = mkl
        else:
            def create(descriptor, domain, size):
                descriptor._obj.value = 123456
                return 0

            def free(descriptor):
                descriptor._obj.value = None
                return 0

            base = types.SimpleNamespace(
                DFTI_COMPLEX=32, DFTI_PLACEMENT=11, DFTI_INPLACE=43,
                DFTI_NOT_INPLACE=44, DFTI_THREAD_LIMIT=27,
                DFTI_WORKSPACE=17, DFTI_ALLOW=51, DFTI_AVOID=52,
                mkl_descriptor={'double': create},
                lib=types.SimpleNamespace(DftiFreeDescriptor=free,
                    DftiComputeBackward=c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_void_p)(lambda d, x: 0)))
        self.base = base
        native_set = p._bind(base.lib.DftiSetValue, c.c_void_p, c.c_int, c.c_int) if args.native else None
        native_get = p._bind(base.lib.DftiGetValue, c.c_void_p, c.c_int, c.POINTER(c.c_int)) if args.native else None
        native_commit = p._bind(base.lib.DftiCommitDescriptor, c.c_void_p) if args.native else None

        def set_value(d, key, value):
            label = {11: 'placement', 27: 'thread_limit', 17: 'workspace_set'}[key]
            self.log.append(label)
            if label == self.fail:
                return self.error
            if key == 17:
                self.value = value
            return native_set(d, key, value) if args.native else 0

        def get_value(d, key, output):
            self.gets += 1
            label = {1: 'initial_get', 2: 'precommit_get', 3: 'postcommit_get'}.get(self.gets, 'boundary_get')
            self.log.append(label)
            if label == self.fail or self.fail == 'wide_status':
                return self.error
            status = native_get(d, key, output) if args.native else 0
            if not args.native:
                output[0] = self.value
            if self.fail == 'wrong_' + label:
                output[0] = 999
            return status

        def commit(d):
            self.log.append('commit')
            if self.fail == 'commit':
                return self.error
            return native_commit(d) if args.native else 0

        self.lib = types.SimpleNamespace(
            DftiFreeDescriptor=Call(base.lib.DftiFreeDescriptor, 'free', self),
            DftiSetValue=c.CFUNCTYPE(c.c_long, c.c_void_p, c.c_int, c.c_int)(set_value),
            DftiGetValue=c.CFUNCTYPE(c.c_long, c.c_void_p, c.c_int, c.POINTER(c.c_int))(get_value),
            DftiCommitDescriptor=c.CFUNCTYPE(c.c_long, c.c_void_p)(commit),
            DftiComputeBackward=base.lib.DftiComputeBackward)
        self.mkl_descriptor = {'double': Call(base.mkl_descriptor['double'], 'create', self)}

    def __getattr__(self, key):
        return getattr(self.base, key)

    @staticmethod
    def check_status(status):
        if status:
            raise RuntimeError('controlled native status ' + str(status))


def restored():
    assert torchfft._MKLCPUDirectIFFTPlan is original_class
    assert original_class.__init__ is original_init and torch.empty is original_empty
    assert (original_class.execute, original_class.can_execute) == original_methods


def construct(mode='avoid', mkl=None, receipt_holder=None):
    mkl = mkl or MKL()
    source = torch.zeros(p.SIZE, dtype=torch.complex64)
    target = torch.full_like(source, 3+4j)
    source[0] = 1+2j
    with p.construction_mode(torchfft, mode) as receipt:
        if receipt_holder is not None:
            receipt_holder.append(receipt)
        plan = torchfft._MKLCPUDirectIFFTPlan(mkl, p.SIZE, source, target, 1, promote=True)
    restored()
    assert type(plan) is original_class and plan.can_execute(source, target)
    assert plan._native_source is plan._native_target
    assert all(t.untyped_storage().resizable() for t in (source, target, plan._native_source))
    assert plan._execute.argtypes == (c.c_void_p, c.c_void_p)
    assert not torchfft._tensors_overlap(source, plan._native_source)
    assert not torchfft._tensors_overlap(target, plan._native_source)
    return plan, source, target, mkl


def bits(t):
    return t.detach().view(torch.uint8)


def dispose(plan):
    plan._finalizer()
    plan._finalizer()
    assert not plan._finalizer.alive


def failure_case(label):
    mkl = MKL(label)
    receipts, native_refs = [], []

    def track_empty(*a, **kw):
        if label == 'allocation':
            raise RuntimeError('controlled allocation')
        tensor = original_empty(*a, **kw)
        native_refs.append(weakref.ref(tensor))
        return tensor

    with patch.object(torch, 'empty', track_empty):
        try:
            if label == 'finalizer':
                with patch.object(torchfft.weakref, 'finalize', side_effect=RuntimeError('controlled finalizer')):
                    construct(mkl=mkl, receipt_holder=receipts)
            else:
                construct(mkl=mkl, receipt_holder=receipts)
        except (RuntimeError, AssertionError) as error:
            message = str(error)
            expected = 'controlled ' + label if label in ('allocation', 'finalizer') else 'controlled native status ' + str(mkl.error)
            if label.startswith('wrong_'):
                assert 'workspace' in message and '999' in message
            else:
                assert message == expected, (label, message)
        else:
            raise AssertionError('failure did not propagate: ' + label)
    restored()
    gc.collect()
    assert all(ref() is None for ref in native_refs)
    assert mkl.log.count('free') == int(label != 'allocation')
    assert len(receipts) == 1 and 'error' in receipts[0]
    operations = mkl.log[:-1] if label != 'allocation' else mkl.log
    expected_order = ['create', 'placement', 'thread_limit', 'initial_get', 'workspace_set', 'precommit_get', 'commit', 'postcommit_get']
    failing = label.removeprefix('wrong_')
    if label == 'wide_status':
        failing = 'initial_get'
    stop = 0 if label == 'allocation' else len(expected_order) if label == 'finalizer' else expected_order.index(failing)+1
    assert operations == expected_order[:stop], (label, operations)
    record['failures'].append({'label': label, 'message': message, 'calls': mkl.log,
                               'receipt': receipts[0], 'storage_released': True})


def run():
    for mode in p.MODES:
        plan, source, target, mkl = construct(mode)
        expected = 51 if mode == 'original' else 52
        events = plan._workspace_policy_receipt['events']
        assert [e['operation'] for e in events] == ['initial_get'] + (['workspace_set'] if mode == 'avoid' else []) + ['precommit_get', 'commit', 'postcommit_get']
        assert [e['value'] for e in events if e['operation'].endswith('_get')] == [51, expected, expected]
        assert all(e['status'] == 0 and e['descriptor'] == plan._descriptor.value for e in events)
        record['constructions'].append(plan._workspace_policy_receipt)
        before, native = source.clone(), plan._native_source
        versions = [t._version for t in (source, target, native)]
        plan.execute(source, target)
        assert torch.equal(bits(source), bits(before))
        assert [t._version for t in (source, target, native)] == [versions[0], versions[1]+1, versions[2]+2]
        assert torch.all(target == 1+2j).item() if args.native else torch.equal(target, source)
        library_ref, owner_ref = weakref.ref(plan._library), weakref.ref(plan)
        surviving_view = native[1:3]
        dispose(plan)
        assert mkl.log.count('free') == 1 and library_ref() is not None
        del plan, native
        gc.collect()
        assert owner_ref() is None and library_ref() is None
        surviving_view.fill_(7+8j)
        assert torch.all(surviving_view == 7+8j).item()
        del surviving_view
        record['checks'].append(mode + ': call order, exact bytes/versions, storage/ABI, single free and lifetime')

    for name, mutate in (
        ('source size', lambda s,t: s.resize_(p.SIZE+1)),
        ('target size', lambda s,t: t.resize_(p.SIZE+1)),
        ('source storage', lambda s,t: s.set_(s.clone())),
        ('target storage', lambda s,t: t.set_(t.clone())),
        ('source shape', lambda s,t: s.resize_(2, p.SIZE//2)),
        ('target shape', lambda s,t: t.resize_(2, p.SIZE//2)),
        ('source stride', lambda s,t: s.as_strided_((p.SIZE//2,), (2,))),
        ('target stride', lambda s,t: t.as_strided_((p.SIZE//2,), (2,))),
        ('overlap', lambda s,t: s.set_(t)),
        ('source autograd', lambda s,t: s.requires_grad_(True)),
        ('target autograd', lambda s,t: t.requires_grad_(True)),
    ):
        plan, source, target, mkl = construct()
        mutate(source, target)
        assert not plan.can_execute(source, target)
        dispose(plan)
        assert mkl.log.count('free') == 1
        record['checks'].append(name + ': rejected without native dispatch')
    plan, source, target, mkl = construct()
    for replacement in (source.clone(), source.conj(), source._neg_view(), source.to(torch.complex128), torch.empty(p.SIZE, dtype=torch.complex64, device='meta')):
        assert not plan.can_execute(replacement, target)
        assert not plan.can_execute(source, replacement)
    with torch.inference_mode():
        inference = torch.empty_like(source)
    assert not plan.can_execute(inference, target) and not plan.can_execute(source, inference)
    torch.set_num_threads(2)
    assert not plan.can_execute(source, target)
    torch.set_num_threads(1)
    pid = plan._pid
    plan._pid = pid+1
    assert not plan.can_execute(source, target)
    plan._pid = pid
    with patch.object(torchfft.os, 'getpid', return_value=pid+1):
        torchfft._free_mkl_descriptor(mkl.lib.DftiFreeDescriptor, plan._descriptor.value, pid)
    assert mkl.log.count('free') == 0
    saved_target = target.clone()
    versions = [t._version for t in (source, target, plan._native_source)]
    plan._execute = lambda *a: 123
    try:
        plan.execute(source, target)
    except RuntimeError as error:
        assert str(error) == 'controlled native status 123'
    else:
        raise AssertionError('status failure suppressed')
    assert torch.equal(bits(target), bits(saved_target))
    assert [t._version for t in (source, target, plan._native_source)] == [versions[0], versions[1], versions[2]+2]
    owner_ref, native_ref = weakref.ref(plan), weakref.ref(plan._native_source)
    del plan
    gc.collect()
    assert owner_ref() is None and native_ref() is None and mkl.log.count('free') == 1
    record['checks'].append('object/dtype/device/conjugate/negative/inference/thread/PID guards and execute failure/GC')
    for label in ('allocation', 'create', 'placement', 'thread_limit', 'initial_get', 'workspace_set', 'precommit_get', 'commit', 'postcommit_get', 'finalizer', 'wide_status', 'wrong_initial_get', 'wrong_precommit_get', 'wrong_postcommit_get'):
        failure_case(label)
    if args.native:
        native_compatibility()
    restored()


def native_compatibility():
    from pycbc.fft import mkl
    s = torch.zeros(16, dtype=torch.complex64)
    t = torch.empty_like(s)
    s[0] = 1+2j
    unrelated = original_class(mkl, 16, s, t, 1, promote=True)
    symbols = ('DftiSetValue', 'DftiGetValue', 'DftiCommitDescriptor', 'DftiComputeBackward')
    signatures = {key: (getattr(mkl.lib, key).argtypes, getattr(mkl.lib, key).restype) for key in symbols}
    unrelated.execute(s, t)
    expected = bits(t).clone()
    for mode in p.MODES:
        a, b = torch.empty(p.SIZE, dtype=torch.complex64), torch.empty(p.SIZE, dtype=torch.complex64)
        with p.construction_mode(torchfft, mode):
            plan = torchfft._MKLCPUDirectIFFTPlan(mkl, p.SIZE, a, b, 1, promote=True)
        assert signatures == {key: (getattr(mkl.lib, key).argtypes, getattr(mkl.lib, key).restype) for key in symbols}
        class Canary(c.Structure):
            _fields_ = [('left', c.c_uint64), ('value', c.c_int), ('right', c.c_uint32), ('tail', c.c_uint64)]
        canary = Canary(0x123456789ABCDEF, -1, 0xAABBCCDD, 0xFEDCBA987654321)
        get = p._bind(mkl.lib.DftiGetValue, c.c_void_p, c.c_int, c.POINTER(c.c_int))
        mkl.check_status(get(plan._descriptor, 17, c.cast(c.byref(canary, Canary.value.offset), c.POINTER(c.c_int))))
        assert (canary.left, canary.right, canary.tail) == (0x123456789ABCDEF, 0xAABBCCDD, 0xFEDCBA987654321)
        assert canary.value == (51 if mode == 'original' else 52)
        dispose(plan)
        unrelated.execute(s, t)
        assert torch.equal(bits(t), expected)
    dispose(unrelated)
    record['checks'].append('native getter four-byte canary, shared signatures and pre-existing out-of-place plan preserved')


try:
    if args.native:
        assert sys.platform == 'linux' and sorted(os.sched_getaffinity(0)) == [8]
    run()
    record['state'] = 'complete'
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    args.output.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({'state': record['state'], 'checks': len(record['checks']), 'failures': len(record['failures']), 'error': record.get('error')}), flush=True)
