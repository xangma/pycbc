"""Fixed workspace-policy qualification, then one of three balanced workers."""
import argparse
from datetime import datetime, timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import sys
import time
import weakref

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--rotation', required=True, type=int, choices=range(3))
parser.add_argument('--mode', required=True, choices=('qualify', 'timing'))
args = parser.parse_args()
source = args.source.resolve(strict=True)
sys.path.insert(0, str(source))
import qualify_runtime as q
from pycbc.fft import mkl
import workspace_policy as p

ROOT = Path(__file__).resolve().parent
assert source == Path(q.pycbc.__file__).resolve().parent.parent
assert not args.output.exists() and not args.output.with_suffix('.tmp').exists()
assert sorted(os.sched_getaffinity(0)) == [8]
q.torch.set_num_threads(1)
if q.torch.get_num_interop_threads() != 1:
    q.torch.set_num_interop_threads(1)
q.fftw.set_measure_level(0)
assert q.sha(q.__file__) == 'e77603961c1f066647065e2e5c86dd2a4676fc891192bab508dc00d926888297'
ARMS = ('unproxied', *p.MODES)
CASES = [(s, pat, scale) for s in q.SEEDS for pat in q.PATTERNS for scale in q.SCALES]
SCHEDULE = json.loads((ROOT / 'schedule.json').read_text())
ORIGINAL = q.torchfft._MKLCPUDirectIFFTPlan
IDENTITIES = (ORIGINAL.__init__, ORIGINAL.execute, ORIGINAL.can_execute, q.torch.empty)


class Rejected(RuntimeError):
    pass


def summary(samples):
    return {'samples_seconds': samples, 'median_seconds': statistics.median(samples),
            'range_seconds': [min(samples), max(samples)]}


def byte_hash(value):
    return hashlib.sha256(value).hexdigest()


def native_bytes(route):
    return route.owner._native_target.detach().view(q.torch.uint8).clone().numpy().tobytes()


def native_call(route):
    """Time only the unchanged two-argument native call; all other work outside."""
    owner = route.owner
    owner._native_source.copy_(route.source)
    start = time.perf_counter_ns()
    status = owner._execute(owner._descriptor, owner._native_source.data_ptr())
    finish = time.perf_counter_ns()
    owner._increment_version(owner._native_target)
    owner._check_status(status)
    route.target.copy_(owner._native_target)
    return (finish-start)/1e9


def runtime_check(route, identity):
    route.check()
    assert q.runtime_identity(route) == identity
    assert q.torchfft._MKLCPUDirectIFFTPlan is ORIGINAL
    assert (ORIGINAL.__init__, ORIGINAL.execute, ORIGINAL.can_execute, q.torch.empty) == IDENTITIES
    assert q.torch.get_num_threads() == q.torch.get_num_interop_threads() == 1
    assert sorted(os.sched_getaffinity(0)) == [8]
    # The unchanged qualification helper exports public NumPy views.
    assert not route.source.untyped_storage().resizable()
    assert not route.target.untyped_storage().resizable()
    assert route.owner._native_target.untyped_storage().resizable()


def boundary(route, mode, identity):
    runtime_check(route, identity)
    events = []
    value = p.workspace_value(mkl, route.owner._descriptor, events)
    assert value == (52 if mode == 'avoid' else 51)
    if mode != 'unproxied':
        receipt = route.owner._workspace_policy_receipt
        assert receipt['descriptor'] == route.owner._descriptor.value
        assert receipt['commit_intercepts'] == 1 and 'error' not in receipt
        assert len(receipt['events']) == (5 if mode == 'avoid' else 4)
    return {'workspace_value': value, 'getter': events[0],
            'runtime_identity': identity,
            'versions': [t._version for t in (route.source, route.target, route.owner._native_target)]}


def qualify(routes, identities, record, phase, path):
    with q.fftw._FFTW_PLANNING_LOCK:
        q.fftw.float_lib.fftwf_forget_wisdom()
        q.fftw.double_lib.fftw_forget_wisdom()
    reference = q.Route('legacy_fftw_single', p.SIZE)
    parity = q.Route('legacy_mkl_double', p.SIZE)
    rows = []
    record['qualification'][phase+'_'+path] = rows
    try:
        for seed, pattern, scale in CASES:
            values = q.values_for(p.SIZE, seed, pattern, scale)
            truth = q.np.fft.ifft(values.astype(q.np.complex128)) * p.SIZE
            baseline = reference.checked_execute(values)
            parity_output = parity.checked_execute(values).astype(q.np.complex64)
            ref_error = q.errors(baseline, truth)
            original_native = original_final = None
            for mode in ARMS:
                route = routes[mode]
                runtime_check(route, identities[mode])
                route.assign(values)
                versions = [t._version for t in (route.source, route.target, route.owner._native_target)]
                if path == 'engine' or mode == 'unproxied':
                    route.engine.execute()
                else:
                    native_call(route)
                runtime_check(route, identities[mode])
                assert [t._version for t in (route.source, route.target, route.owner._native_target)] == [versions[0], versions[1]+1, versions[2]+2]
                assert route.source_buffer.tobytes() == values.tobytes()
                actual = route.target_buffer.copy()
                native, final = native_bytes(route), actual.tobytes()
                if mode == 'unproxied':
                    original_native, original_final = native, final
                error = q.errors(actual, truth)
                row = {'seed': seed, 'pattern': pattern, 'scale': scale, 'arm': mode,
                       'reference': ref_error, 'candidate': error,
                       'native_sha256': byte_hash(native), 'final_sha256': byte_hash(final),
                       'native_nbytes': len(native), 'final_nbytes': len(final),
                       'bitwise_unproxied_native': native == original_native,
                       'bitwise_unproxied_final': final == original_final,
                       'bitwise_matching_precision_mkl': final == parity_output.tobytes(),
                       'input_preserved': True, 'versions_passed': True}
                row['passed'] = bool(all(error[k] <= ref_error[k] for k in error)
                                     and row['bitwise_unproxied_native'] and row['bitwise_unproxied_final']
                                     and row['bitwise_matching_precision_mkl'])
                rows.append(row)
                if not row['passed']:
                    raise Rejected('exact-byte/error gate failed: ' + repr(row))
            print(phase, path, seed, pattern, scale, 'all arms qualified', flush=True)
        assert [(r['seed'], r['pattern'], r['scale'], r['arm']) for r in rows] == [(*case, mode) for case in CASES for mode in ARMS]
    finally:
        reference.close()
        parity.close()


record = {'schema': 'cpu-workspace-policy-v1', 'state': 'running', 'mode': args.mode,
          'rotation': args.rotation, 'pid': os.getpid(), 'pgid': os.getpgrp(),
          'start_ticks': Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
          'cwd': os.getcwd(), 'command': sys.argv, 'host': platform.node(),
          'started_utc': datetime.now(timezone.utc).isoformat(),
          'source_state': q.state(source), 'helper_sha256': q.sha(__file__),
          'policy_helper_sha256': q.sha(p.__file__),
          'protocol_sha256': q.sha(ROOT / 'CPU-DFTI-WORKSPACE-PROTOCOL-v2.md'),
          'qualification_helper_sha256': q.sha(q.__file__),
          'schedule': SCHEDULE, 'schedule_sha256': q.sha(ROOT / 'schedule.json'),
          'abi_reference_sha256': q.sha(ROOT / 'abi-reference.json'),
          'libraries': {'mkl': q.library_identity(mkl.lib.DftiComputeBackward),
                        'fftw_float': q.library_identity(q.fftw.float_lib.fftwf_execute_dft),
                        'fftw_double': q.library_identity(q.fftw.double_lib.fftw_execute_dft)},
          'versions': {'python': sys.version, 'numpy': q.np.__version__, 'torch': q.torch.__version__},
          'cpu_affinity': sorted(os.sched_getaffinity(0)),
          'torch_threads': [q.torch.get_num_threads(), q.torch.get_num_interop_threads()],
          'smt_siblings': Path('/sys/devices/system/cpu/cpu8/topology/thread_siblings_list').read_text().strip(),
          'environment': {key: os.environ.get(key) for key in (
              'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS',
              'MKL_DYNAMIC', 'MKL_THREADING_LAYER', 'PYTHONHASHSEED', 'PYTHONPATH',
              'LD_PRELOAD', 'LD_LIBRARY_PATH')},
          'native_timer': 'DftiComputeBackward with descriptor and in-place pointer only. Promotion, version increment, status check and demotion outside timer.',
          'setup': {}, 'runtime_identity': {}, 'qualification': {}, 'blocks': [], 'cleanup': {}}


def run():
    routes, refs = {}, {}
    try:
        assert record['source_state']['head'] == 'ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f'
        assert not record['source_state']['source_status']
        assert record['source_state']['torchfft_sha256'] == '0b9109bbf99a4eb591a4c006b1220ec36c8587e56352352277eb1478cf876c0c'
        assert record['torch_threads'] == [1, 1]
        reference = json.loads((ROOT / 'runtime-reference.json').read_text())
        for key in ('versions', 'environment', 'libraries'):
            assert record[key] == reference[key], key
        construction_order = SCHEDULE['construction'][args.rotation]
        record['construction_order'] = construction_order + ['unproxied']
        for mode in record['construction_order']:
            start = time.perf_counter_ns()
            if mode == 'unproxied':
                routes[mode] = q.Route('accepted_mkl_promoted', p.SIZE)
            else:
                with p.construction_mode(q.torchfft, mode) as receipt:
                    record['setup'][mode] = {'construction_receipt': receipt}
                    routes[mode] = q.Route('accepted_mkl_promoted', p.SIZE)
            elapsed = (time.perf_counter_ns()-start)/1e9
            route = routes[mode]
            record['runtime_identity'][mode] = q.runtime_identity(route)
            refs[mode] = {'plan': weakref.ref(route.owner), 'native': weakref.ref(route.owner._native_source)}
            tensor = route.owner._native_source
            record['setup'].setdefault(mode, {}).update({
                'full_route_constructor_including_commit_seconds': elapsed,
                'public_storage_resizable': [route.source.untyped_storage().resizable(), route.target.untyped_storage().resizable()],
                'workspace': {'pointer': tensor.data_ptr(), 'size': list(tensor.size()),
                              'stride': list(tensor.stride()), 'dtype': str(tensor.dtype),
                              'device': str(tensor.device), 'nbytes': tensor.numel()*tensor.element_size(),
                              'storage_nbytes': tensor.untyped_storage().nbytes(),
                              'storage_offset': tensor.storage_offset(), 'alignment_mod64': tensor.data_ptr()%64,
                              'resizable': tensor.untyped_storage().resizable()}})
            del route, tensor
        pointers = [v[k] for v in record['runtime_identity'].values() for k in ('private_source_pointer', 'public_source_pointer', 'public_target_pointer')]
        assert len(set(pointers)) == len(pointers)
        values = q.values_for(p.SIZE, 7, 'dense', 1.0)
        for mode in record['construction_order']:
            routes[mode].assign(values)
            start = time.perf_counter_ns()
            routes[mode].engine.execute()
            record['setup'][mode]['first_engine_execution_seconds'] = (time.perf_counter_ns()-start)/1e9
            record['setup'][mode]['first_boundary'] = boundary(routes[mode], mode, record['runtime_identity'][mode])
        for path in ('engine', 'native'):
            qualify(routes, record['runtime_identity'], record, 'before', path)
        if args.mode == 'timing':
            routes['unproxied'].assign(values)
            routes['unproxied'].engine.execute()
            expected = (native_bytes(routes['unproxied']), routes['unproxied'].target_buffer.tobytes())
            gc.collect()
            gc.disable()
            for path in ('engine', 'native'):
                for block, order in enumerate(SCHEDULE[path][args.rotation]):
                    for label in order:
                        mode = SCHEDULE['labels'][label]
                        route = routes[mode]
                        route.assign(values)
                        row = {'path': path, 'block': block, 'arm': mode, 'order': order, 'warmups': 3}
                        record['blocks'].append(row)
                        row['before'] = boundary(route, mode, record['runtime_identity'][mode])
                        for _ in range(3):
                            route.engine.execute() if path == 'engine' else native_call(route)
                        samples = []
                        for _ in range(15):
                            if path == 'engine':
                                start = time.perf_counter_ns()
                                route.engine.execute()
                                elapsed = (time.perf_counter_ns()-start)/1e9
                            else:
                                elapsed = native_call(route)
                            samples.append(elapsed)
                        row['timing'] = summary(samples)
                        row['after'] = boundary(route, mode, record['runtime_identity'][mode])
                        v = row['before']['versions']
                        assert row['after']['versions'] == [v[0], v[1]+18, v[2]+36]
                        assert route.source_buffer.tobytes() == values.tobytes()
                        if (native_bytes(route), route.target_buffer.tobytes()) != expected:
                            raise Rejected('timed block output changed')
                        row['input_versions_and_exact_outputs_passed'] = True
                        print(path, block, mode, 'block complete', flush=True)
                        del route
            gc.enable()
        for path in ('native', 'engine'):
            qualify(routes, record['runtime_identity'], record, 'after', path)
        record['final_boundary'] = {mode: boundary(routes[mode], mode, record['runtime_identity'][mode]) for mode in ARMS}
        assert q.state(source) == record['source_state']
        record['all_432_precision_cases_passed'] = True
        record['state'] = 'complete'
    finally:
        gc.enable()
        for mode, route in routes.items():
            start = time.perf_counter_ns()
            route.owner._finalizer()
            route.owner._finalizer()
            record['cleanup'][mode] = {'descriptor_finalize_seconds': (time.perf_counter_ns()-start)/1e9,
                                       'finalizer_inactive': not route.owner._finalizer.alive}
            route.execute = route.close = None
            route.engine = route.owner = None
        if routes:
            del route
        start = time.perf_counter_ns()
        routes.clear()
        gc.collect()
        record['cleanup_collection_seconds'] = (time.perf_counter_ns()-start)/1e9
        for mode, objects in refs.items():
            record['cleanup'][mode]['released'] = {key: ref() is None for key, ref in objects.items()}
        if sys.exc_info()[0] is None:
            assert all(all(row['released'].values()) for row in record['cleanup'].values())
        else:
            record['cleanup_on_exception'] = 'descriptor freed; traceback may retain Python owners until handler exits'


try:
    run()
except Rejected as error:
    record.update(state='rejected', error=str(error))
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    temporary = args.output.with_suffix('.tmp')
    temporary.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    temporary.replace(args.output)
    print(record['state'], record.get('error', ''), flush=True)
