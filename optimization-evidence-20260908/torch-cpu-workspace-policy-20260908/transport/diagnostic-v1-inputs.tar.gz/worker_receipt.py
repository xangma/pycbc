"""Record and enforce observed one-thread pools around an unchanged FFT helper."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--receipt', required=True, type=Path)
parser.add_argument('--helper', required=True, type=Path)
parser.add_argument('arguments', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert not args.receipt.exists()
source = args.source.resolve(strict=True)
sys.path.insert(0, str(source))
import pycbc
import torch
from pycbc.fft import fftw, mkl
import threadpoolctl

assert Path(pycbc.__file__).resolve().parent.parent == source
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
import qualify_runtime as q

ROOT = Path(__file__).resolve().parent
LOCK = '/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock'
LOCK_FD = int(os.environ['PYCBC_BENCHMARK_LOCK_FD'])
def lock_snapshot():
    assert os.readlink(f'/proc/self/fd/{LOCK_FD}') == LOCK
    inherited, named = os.fstat(LOCK_FD), os.stat(LOCK)
    assert (inherited.st_dev, inherited.st_ino) == (named.st_dev, named.st_ino)
    with open(LOCK) as probe:
        try:
            fcntl.flock(probe, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            raise AssertionError('campaign lock was not held')
    return {'fd': LOCK_FD, 'path': LOCK, 'device': named.st_dev,
            'inode': named.st_ino, 'competing_open_blocked': True}


def snapshot():
    pools = threadpoolctl.threadpool_info()
    assert pools, 'native thread pool discovery returned no libraries'
    assert all(pool['num_threads'] == 1 for pool in pools), pools
    assert torch.get_num_threads() == torch.get_num_interop_threads() == 1
    assert sorted(os.sched_getaffinity(0)) == [8]
    libraries = {'mkl': q.library_identity(mkl.lib.DftiComputeBackward),
                 'fftw_float': q.library_identity(fftw.float_lib.fftwf_execute_dft),
                 'fftw_double': q.library_identity(fftw.double_lib.fftw_execute_dft)}
    assert libraries == json.loads((ROOT / 'library-pins.json').read_text())
    runtime = json.loads((ROOT / 'runtime-pins.json').read_text())
    assert sorted(pools, key=lambda row: row['filepath']) == sorted(runtime['pools'], key=lambda row: row['filepath'])
    assert sha(threadpoolctl.__file__) == runtime['threadpoolctl_sha256']
    for name, path in runtime['symbols'].items():
        assert q.library_identity(getattr(mkl.lib, name)) == {'path': path, 'sha256': runtime['sha256'][path]}
    return {'torch_intraop_threads': torch.get_num_threads(),
            'torch_interop_threads': torch.get_num_interop_threads(),
            'native_pools': pools, 'cpu_affinity': sorted(os.sched_getaffinity(0)),
            'libraries': libraries, 'lock': lock_snapshot(),
            'runtime_pins_sha256': sha(ROOT / 'runtime-pins.json')}


record = {'state': 'running', 'pid': os.getpid(), 'pgid': os.getpgid(0),
          'interpreter': sys.executable, 'command': sys.argv,
          'cwd': os.getcwd(), 'started_epoch': time.time(),
          'start_ticks': Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
          'lock': lock_snapshot(),
          'wrapper_sha256': sha(__file__), 'helper_sha256': sha(args.helper),
          'fft_libraries': {'fftw': fftw.float_lib._name, 'mkl': mkl.lib._name},
          'threadpoolctl_sha256': sha(threadpoolctl.__file__)}
try:
    record['before'] = snapshot()
    arguments = args.arguments[1:] if args.arguments[:1] == ['--'] else args.arguments
    sys.argv = [str(args.helper), *arguments]
    runpy.run_path(str(args.helper), run_name='__main__')
    record['after'] = snapshot()
    record['state'] = 'complete'
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    record['finished_epoch'] = time.time()
    args.receipt.write_text(json.dumps(record, indent=2) + '\n')
