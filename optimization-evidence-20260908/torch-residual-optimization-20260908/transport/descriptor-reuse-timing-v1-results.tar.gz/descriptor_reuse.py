"""Qualified bounded cache without per-call diagnostic recording or timers.

Inherits unchanged AST cloning, ownership, frees and installation/finalization
from the pinned diagnostic implementation. Native identity checks run at
construction, install and finalization boundaries, not on every FFT call.
"""
import functools

import numpy as np

from descriptor_reuse_diagnostic import ALLOWED, DescriptorReuse as DiagnosticReuse
from descriptor_reuse_diagnostic import sha  # noqa: F401 -- public helper for runners


class DescriptorReuse(DiagnosticReuse):
    def __init__(self, mkl):
        super().__init__(mkl, reuse=True)

    def key(self, direction, invec, outvec, prec, itype, otype):
        state = self.mkl._scheme.mgr.state
        threads = getattr(state, 'num_threads', None)
        device = tuple((name, str(getattr(state, name, None))) for name in
                       ('device', 'device_num', 'device_spec', 'torch_device'))
        config = (direction, len(invec), len(outvec), np.dtype(invec.dtype).str,
                  np.dtype(outvec.dtype).str, prec, itype, otype)
        inplace = invec.ptr == outvec.ptr
        placement = self.mkl.DFTI_INPLACE if inplace else self.mkl.DFTI_NOT_INPLACE
        allowed = (config in ALLOWED and not inplace and threads == 1
                   and isinstance(state, self.mkl._scheme.CPUScheme))
        key = config + (max(len(invec), len(outvec)), placement, type(state),
                        device, threads, self.pid, self.thread)
        return key, allowed

    def observe(self, descriptor, status):
        if status or descriptor.value in (None, 0, 1):
            self.poisoned = True
            raise RuntimeError('Diagnostic fail-closed descriptor creation: '
                               f'status={status}, handle={descriptor.value}')
        if self.active['entry'] is not None:
            raise RuntimeError('Duplicate descriptor ownership observation')
        entry = {'descriptor': descriptor, 'value': descriptor.value,
                 'state': 'creating', 'key': self.active['key'], 'free_attempts': 0,
                 'free_successes': 0}
        self.entries.append(entry)
        self.active['entry'] = entry

    def acquire(self, size, idtype, odtype, inplace):
        active = self.active
        key = active['key']
        if (size, np.dtype(idtype).str, np.dtype(odtype).str, bool(inplace)) != (
                key[8], key[3], key[4], False):
            raise RuntimeError('Original creator arguments differ from full key')
        if key in self.cache:
            entry = self.cache[key]
            if entry['state'] != 'available':
                raise RuntimeError('Descriptor is busy or released')
            active['entry'] = entry
        else:
            descriptor = self.creator(size, idtype, odtype, inplace)
            entry = active['entry']
            if entry is None or entry['descriptor'] is not descriptor:
                raise RuntimeError('Creator returned unobserved descriptor')
            if len(self.cache) >= 3:
                raise RuntimeError('Bounded descriptor capacity exceeded')
            self.cache[key] = entry
        entry['state'] = 'busy'
        return entry['descriptor']

    def release(self, descriptor, status):
        entry = self.active['entry']
        if entry is None or descriptor is not entry['descriptor'] or entry['state'] != 'busy':
            raise RuntimeError('Unowned descriptor release')
        if status:
            try:
                self.free(entry, 'native_error')
            except BaseException:
                pass  # Original check_status owns the primary native error.
        else:
            entry['state'] = 'available'

    def wrap(self, direction, function):
        @functools.wraps(self.original[direction])
        def wrapped(invec, outvec, prec, itype, otype):
            self.owner()
            if self.closed or self.poisoned or self.active is not None:
                raise RuntimeError('Closed, poisoned or reentrant descriptor cache')
            key, allowed = self.key(direction, invec, outvec, prec, itype, otype)
            if key not in self.cache and len(self.cache) >= 3:
                allowed = False
            self.active = {'key': key, 'entry': None}
            try:
                target = function if allowed else self.original[direction]
                return target(invec, outvec, prec, itype, otype)
            except BaseException:
                entry = self.active['entry']
                if entry is not None and entry['state'] not in ('freed', 'uncertain'):
                    try:
                        self.free(entry, 'python_exception')
                    except BaseException:
                        pass  # Preserve the primary exception; cleanup is recorded.
                raise
            finally:
                self.active = None
        return wrapped

    def report(self):
        result = super().report()
        assert not result.pop('rows')
        del result['hits']  # No successful-call telemetry in this implementation.
        result['creates'] = len(self.entries)
        result['diagnostics'] = 'boundary invariants and owned-descriptor lifecycle only'
        return result
