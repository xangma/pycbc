"""Exercise actual provenance, qualification counters and runner fault receipts."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

from descriptor_reuse import DescriptorReuse, sha
import test_descriptor_reuse_diagnostic as fake
import run_reuse
import reuse_controller as controller

ROOT = Path(__file__).resolve().parent
HELPER_SHA = sha(ROOT / 'threadpoolctl.py')


class ProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.old = controller.LOADER.resolve()
        self.new = Path('/home/xangma/pycbc-torch-residual-optimization-20260908/descriptor-reuse-timing-v1').resolve()
        self.root_patch = patch.object(controller, 'ROOT', self.new)
        self.root_patch.start()
        self.addCleanup(self.root_patch.stop)
        self.loader_patch = patch.object(controller, 'LOADER', self.old)
        self.loader_patch.start()
        self.addCleanup(self.loader_patch.stop)
        self.environment = {'OMP_NUM_THREADS': '1'}
        self.receipts, self.roles = {}, {}
        common = {'intra_op': 1, 'inter_op': 1, 'affinity': [8],
                  'smt_siblings': {'8': '8,72'}, 'environment': self.environment,
                  'threadpools': [{'num_threads': 1}]}
        self.paths = [(folder.resolve(), self.old, family) for family, folder in controller.REFERENCES.items()]
        self.paths += [(self.new / 'runs' / case, self.new, ('standard' if 'standard' in case else 'cuda')) for case in controller.CASES]
        for folder, provenance, family in self.paths:
            self.roles[folder] = (family + '-candidate', controller.SOURCE,
                                  'cpu:1' if family == 'standard' else 'torch:cuda:0', 'candidate')
            self.receipts[folder] = dict(copy.deepcopy(common),
                scheme='CPUScheme' if family == 'standard' else 'TorchScheme',
                device='' if family == 'standard' else 'cuda:0',
                intra_op=None if family == 'standard' else 1,
                inter_op=None if family == 'standard' else 1,
                threadpoolctl={'path': str(provenance / 'threadpoolctl.py'),
                               'version': '3.6.0', 'sha256': HELPER_SHA})
        self.calls = []

        def campaign():
            value = types.SimpleNamespace()
            def verified_run(folder, role):
                spec = importlib.util.spec_from_file_location('checker_test', ROOT / 'checked-inspiral.py')
                checker = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(checker)
                checker.__file__ = str(value.ROOT / 'checked-inspiral.py')
                def digest(path):
                    self.assertEqual(Path(path), value.ROOT / 'threadpoolctl.py')
                    return HELPER_SHA
                checker.digest = digest
                checker.check(self.receipts[folder], self.environment, bank=True, scheme=role[2])
                self.calls.append((folder, value.ROOT))
                return value.ROOT
            value.verified_run = verified_run
            return value
        self.current, self.archived = campaign(), campaign()
        self.verify = controller.bind_provenance_verifiers(self.current, self.archived)

    def test_all_twenty_two_paths_use_correct_helpers(self):
        for folder, provenance, _ in self.paths:
            self.assertEqual(self.current.verified_run(folder, self.roles[folder]), provenance)
        self.assertEqual(len(self.calls), 22)

    def test_swapped_paths_and_old_contract_failures_rejected(self):
        for folder, provenance, _ in self.paths:
            original = copy.deepcopy(self.receipts[folder])
            mutations = [('path', str((self.new if provenance == self.old else self.old) / 'threadpoolctl.py')),
                         ('sha256', '0' * 64), ('version', 'wrong')]
            for field, value in mutations:
                self.receipts[folder] = copy.deepcopy(original)
                self.receipts[folder]['threadpoolctl'][field] = value
                with self.assertRaisesRegex(ValueError, 'another helper'):
                    self.verify(folder, self.roles[folder])
            for field, value in [('inter_op', 64), ('environment', {}), ('affinity', [9])]:
                self.receipts[folder] = dict(copy.deepcopy(original), **{field: value})
                with self.assertRaises(ValueError):
                    self.verify(folder, self.roles[folder])
            self.receipts[folder] = original

    def test_unknown_nested_and_other_root_fail_before_access(self):
        role = next(iter(self.roles.values()))
        for folder in (self.new / 'runs/cuda-cached-2', self.old / 'runs/cuda-cached',
                       controller.REFERENCES['cuda'] / 'nested', self.new / 'runs/qual-standard-candidate'):
            with self.assertRaisesRegex(ValueError, 'Unexpected run location'):
                self.verify(folder, role)
        self.assertEqual(self.calls, [])


class CounterTests(unittest.TestCase):
    def test_actual_reports_and_corruptions(self):
        for cached in (True, False):
            m = fake.module()
            cache = DescriptorReuse(m)
            if cached:
                cache.install()
                for _ in range(2):
                    for config in range(3):
                        fake.execute(m, fake.vectors(config), config)
                cache.finish()
            else:
                for config in range(3):
                    fake.execute(m, fake.vectors(config), config)
                run_reuse.baseline_finish(cache, None)
            valid = cache.report()
            self.assertEqual(controller.verify_cache(valid, cached)['owned_descriptors'], 3 if cached else 0)
            mutations = [lambda r: r.update(frees=99), lambda r: r.update(restored=False),
                         lambda r: r.update(cleanup_errors=['failed']),
                         lambda r: r.update(rows=[]), lambda r: r.update(hits=0),
                         lambda r: r.update(poisoned=True), lambda r: r.update(creates=99)]
            if cached:
                mutations += [lambda r: r['entries'][0].update(free_attempts=2),
                              lambda r: r['entries'][0].update(state='uncertain')]
            for mutate in mutations:
                invalid = copy.deepcopy(valid)
                mutate(invalid)
                with self.assertRaises(AssertionError):
                    controller.verify_cache(invalid, cached)


class RunnerTests(unittest.TestCase):
    def exercise(self, workload_error=None, free_error=None, install_error=None, empty=False, cached=True, mutate_original=False):
        m = fake.module()
        package = types.ModuleType('pycbc')
        fft = types.ModuleType('pycbc.fft')
        fft.mkl = m
        package.fft = fft
        caches = []
        def factory(module):
            cache = DescriptorReuse(module)
            caches.append(cache)
            if install_error is not None:
                def install():
                    raise install_error
                cache.install = install
            return cache
        def run_path(path, run_name):
            self.assertEqual((path, run_name), ('qualified-workload.py', '__main__'))
            if not empty:
                for config in range(3):
                    fake.execute(m, fake.vectors(config), config)
            if mutate_original:
                m.fft = lambda *args: None
            if free_error:
                m.lib.faults['free'] = free_error
            if workload_error is not None:
                raise workload_error
        with tempfile.TemporaryDirectory() as folder:
            receipt = Path(folder) / 'receipt.json'
            argv = ['run_reuse.py', '--receipt', str(receipt), '--reuse', 'yes' if cached else 'no', '--', 'qualified-workload.py']
            caught = None
            with patch.dict(sys.modules, {'pycbc': package, 'pycbc.fft': fft}), \
                    patch.object(run_reuse, 'DescriptorReuse', factory), \
                    patch.object(run_reuse.runpy, 'run_path', run_path), patch.object(sys, 'argv', argv):
                try:
                    run_reuse.main()
                except BaseException as error:
                    caught = error
                self.assertIs(sys.argv, argv)
            report = json.loads(receipt.read_text())
        if not mutate_original or cached:
            self.assertIs(m.fft, caches[0].original['fft'])
        self.assertTrue(report['cache']['closed'])
        self.assertTrue(report['cache']['restored'])
        return caught, report

    def test_success_and_zero_exit_complete_after_release(self):
        for error in (None, SystemExit(0), SystemExit(None)):
            caught, report = self.exercise(workload_error=error)
            self.assertIsNone(caught)
            self.assertEqual(report['state'], 'complete')
            self.assertEqual(report['cache']['frees'], 3)

    def test_primary_exception_survives_secondary_free_error(self):
        for primary in (ValueError('workload'), SystemExit(7), KeyboardInterrupt()):
            caught, report = self.exercise(workload_error=primary, free_error=RuntimeError('free'))
            self.assertIs(caught, primary)
            self.assertEqual(report['state'], 'failed')
            self.assertEqual(report['error'], repr(primary))
            self.assertTrue(report['cache']['cleanup_errors'])
            self.assertTrue(report['cache']['finalization_errors'])
            self.assertEqual(report['cache']['entries'][0]['free_attempts'], 1)

    def test_cleanup_only_error_and_empty_workload_fail(self):
        primary = RuntimeError('free')
        caught, report = self.exercise(free_error=primary)
        self.assertIs(caught, primary)
        self.assertEqual(report['state'], 'failed')
        self.assertTrue(report['cache']['poisoned'])
        caught, report = self.exercise(empty=True)
        self.assertIsInstance(caught, AssertionError)
        self.assertEqual(report['state'], 'failed')

    def test_install_error_preserved_and_recorded(self):
        primary = ValueError('install')
        caught, report = self.exercise(install_error=primary)
        self.assertIs(caught, primary)
        self.assertEqual(report['state'], 'failed')
        self.assertEqual(report['error'], repr(primary))
        self.assertTrue(report['cache']['finalization_errors'])

    def test_original_baseline_success_error_and_boundary_identity(self):
        for error in (None, SystemExit(0), ValueError('workload')):
            caught, report = self.exercise(workload_error=error, cached=False)
            self.assertEqual(report['state'], 'failed' if isinstance(error, ValueError) else 'complete')
            self.assertEqual(report['cache']['creates'], 0)
            self.assertEqual(report['cache']['frees'], 0)
            self.assertEqual(report['variant'], 'original')
            if isinstance(error, ValueError):
                self.assertIs(caught, error)
        primary = RuntimeError('primary')
        caught, report = self.exercise(workload_error=primary, cached=False, mutate_original=True)
        self.assertIs(caught, primary)
        self.assertTrue(report['cache']['finalization_errors'])
        caught, report = self.exercise(cached=False, mutate_original=True)
        self.assertIsInstance(caught, AssertionError)
        self.assertEqual(report['state'], 'failed')



if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    (ROOT / 'local-harness-tests.json').write_text(json.dumps({
        'state': 'pass' if result.wasSuccessful() else 'failed', 'tests_run': result.testsRun,
        'pins': {name: sha(ROOT / name) for name in ('test_harness.py', 'test_descriptor_reuse_diagnostic.py',
            'descriptor_reuse_diagnostic.py',
            'descriptor_reuse.py', 'run_reuse.py', 'reuse_controller.py', 'checked-inspiral.py')},
        'failures': len(result.failures), 'errors': len(result.errors)}, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
