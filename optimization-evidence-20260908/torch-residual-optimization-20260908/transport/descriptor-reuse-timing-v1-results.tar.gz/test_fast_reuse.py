"""Compare fast helper with the executed v1 bodies and native-call recorder."""
import ctypes
import gc
import unittest
from unittest.mock import patch
import weakref

import numpy as np

from descriptor_reuse import DescriptorReuse
from descriptor_reuse_diagnostic import DescriptorReuse as DiagnosticReuse
import test_descriptor_reuse_diagnostic as donor


class FastContracts(unittest.TestCase):
    def test_inherited_lifecycle_contracts_with_fast_class(self):
        names = (
            'finish_records_both_errors_restores_python_and_preserves_close_error',
            'failure_cleanup_and_primary_exception_identity',
            'native_status_free_precedes_original_status_check',
            'original_unchecked_returns_are_not_silently_fixed',
            'creation_fail_closed_status_null_sentinel_and_preallocation_exception',
            'free_failure_poison_no_retry_preserve_primary_restore',
            'nonzero_compute_and_failed_free_preserves_native_error',
            'reentry_owner_thread_recycled_identifier_and_fork',
        )
        for name in names:
            with self.subTest(contract=name), patch.object(donor, 'DescriptorReuse', DescriptorReuse):
                getattr(donor.Contracts(), 'test_' + name)()

    def test_exact_native_and_signature_sequence_v1_fast_and_original(self):
        for config in range(3):
            pair = donor.vectors(config)
            modules = [donor.module() for _ in range(3)]
            caches = [DiagnosticReuse(modules[0]), DescriptorReuse(modules[1])]
            for cache in caches:
                cache.install()
            for allocation in range(4):
                if allocation:
                    pair = donor.vectors(config)
                results = []
                for m in modules:
                    m.lib.events.clear()
                    before = pair[0].data.copy()
                    donor.execute(m, pair, config)
                    np.testing.assert_array_equal(before, pair[0].data)
                    results.append(pair[1].data.copy())
                self.assertEqual(modules[0].lib.events, modules[1].lib.events)
                for values in results[1:]:
                    np.testing.assert_array_equal(values, results[0])
                if allocation == 0:
                    self.assertEqual(modules[1].lib.events,
                        [e for e in modules[2].lib.events if e[1] != 'DftiFreeDescriptor'])
                else:
                    self.assertEqual(len(modules[1].lib.events), 2)
                self.assertFalse(caches[1].rows)
                for cache in caches:
                    cache.assert_native()
            for cache in caches:
                cache.finish()
                self.assertEqual(cache.report()['creates'], 1)
                self.assertEqual(cache.report()['frees'], 1)
            self.assertEqual(modules[0].lib.events, modules[1].lib.events)

    def test_full_key_matches_v1_all_components_and_no_stale_hit(self):
        changes = [lambda m, p: None,
            lambda m, p: setattr(p[0], 'n', 16383),
            lambda m, p: setattr(p[1], 'n', 8192),
            lambda m, p: setattr(p[0], 'dtype', np.dtype('f8')),
            lambda m, p: setattr(p[1], 'dtype', np.dtype('c16')),
            lambda m, p: setattr(p[1], 'ptr', p[0].ptr),
            lambda m, p: setattr(m._scheme.mgr.state, 'num_threads', 2),
            lambda m, p: setattr(m._scheme.mgr, 'state', donor.OtherCPU()),
        ]
        for field in ('device', 'device_num', 'device_spec', 'torch_device'):
            changes.append(lambda m, p, field=field: setattr(m._scheme.mgr.state, field, 'different'))
        for change in changes:
            m = donor.module()
            slow, fast = DiagnosticReuse(m), DescriptorReuse(m)
            fast.install()
            donor.execute(m, donor.vectors())
            old_key = next(iter(fast.cache))
            pair = donor.vectors()
            change(m, pair)
            for tokens in (('single', 'real', 'complex'), ('double', 'real', 'complex'),
                           ('single', 'complex', 'complex'), ('single', 'real', 'real')):
                a, _, allowed = slow.key('fft', *pair, *tokens)
                self.assertEqual(fast.key('fft', *pair, *tokens), (a, allowed))
            m.lib.events.clear()
            donor.execute(m, pair)
            if fast.key('fft', *pair, 'single', 'real', 'complex')[0] != old_key:
                self.assertEqual(len(donor.calls(m.lib, 'DftiCreateDescriptor_s_1d')) +
                                 len(donor.calls(m.lib, 'DftiCreateDescriptor_d_1d')), 1)
            fast.finish()

    def test_three_entries_capacity_and_unsupported_exact_original(self):
        m, original = donor.module(), donor.module()
        c = DescriptorReuse(m)
        c.install()
        for _ in range(2):
            for config in range(3):
                donor.execute(m, donor.vectors(config), config)
        self.assertEqual(len(c.entries), 3)
        inplace = donor.Vec(8, 'c8')
        for pair, other_scheme in [(donor.vectors(), True),
                ((inplace, inplace), False),
                ((donor.Vec(8, 'c8'), donor.Vec(8, 'c8')), False)]:
            if other_scheme:
                m._scheme.mgr.state = donor.OtherCPU()
                original._scheme.mgr.state = donor.OtherCPU()
            m.lib.events.clear()
            original.lib.events.clear()
            original.lib.next_handle = m.lib.next_handle
            donor.execute(m, pair)
            donor.execute(original, pair)
            self.assertEqual(m.lib.events, original.lib.events)
        c.finish()
        self.assertEqual(c.report()['creates'], 3)
        self.assertEqual(c.report()['frees'], 3)

    def test_no_arrays_retained_no_hot_diagnostics_or_timers(self):
        m = donor.module()
        c = DescriptorReuse(m)
        c.install()
        pair = donor.vectors()
        refs = [weakref.ref(v) for v in pair]
        with (patch.object(c, 'assert_native', side_effect=AssertionError('hot invariant sweep')),
              patch.object(c, 'signatures', side_effect=AssertionError('hot signatures'))):
            donor.execute(m, pair)
            del pair
            gc.collect()
            self.assertTrue(all(ref() is None for ref in refs))
            donor.execute(m, donor.vectors())
        self.assertEqual(len(c.entries), 1)
        self.assertFalse(c.rows)
        self.assertNotIn('hits', c.report())
        c.finish()
        with self.assertRaisesRegex(RuntimeError, 'Closed'):
            c.wrappers['fft'](*donor.vectors(), 'single', 'real', 'complex')

    def test_boundary_invariant_error_preserves_workload_primary(self):
        m = donor.module()
        c = DescriptorReuse(m)
        c.install()
        primary = RuntimeError('workload primary')
        def fail(*args):
            m.lib.DftiComputeForward = donor.Native(m.lib, 'DftiComputeForward', 990)
            raise primary
        m.lib.faults['compute'] = fail
        with self.assertRaises(RuntimeError) as caught:
            donor.execute(m, donor.vectors())
        self.assertIs(caught.exception, primary)
        self.assertEqual(c.invariant_errors, [])  # Intentionally no hot sweep.
        c.finish(primary_error=primary)
        self.assertTrue(c.poisoned)
        self.assertEqual(c.finalization_errors[0]['operation'], 'restore')
        self.assertTrue(c.closed)
        self.assertFalse(c.installed)
        self.assertIs(m.fft, c.original['fft'])

    def test_class_plan_interleaving_v1_fast_same_transitions(self):
        pair = donor.vectors()
        results = []
        for cls in (DiagnosticReuse, DescriptorReuse):
            m = donor.module()
            c = cls(m)
            c.install()
            plan = m.FFT(*pair)
            for _ in range(3):
                donor.execute(m, donor.vectors())
                plan.execute()
                c.assert_native()
            m.lib.DftiFreeDescriptor(ctypes.byref(plan.desc))
            c.finish()
            results.append(m.lib.events)
        # Different fresh input pointers are expected; compare all other args.
        def normalize(events):
            return [(e[:2] + (e[2][:1],)) if e[:2] in
                    [('call', 'DftiComputeForward'), ('call', 'DftiComputeBackward')]
                    else e for e in events]
        self.assertEqual(normalize(results[0]), normalize(results[1]))


if __name__ == '__main__':
    unittest.main(verbosity=2)
