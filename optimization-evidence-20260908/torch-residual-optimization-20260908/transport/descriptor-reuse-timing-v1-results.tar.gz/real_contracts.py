"""Fresh real-MKL new-buffer/exact-output contracts, with live class/Torch plans."""
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import time


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--lock-fd', type=int, required=True)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    assert not args.receipt.exists()
    lock = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
    actual, expected = os.fstat(args.lock_fd), lock.stat()
    assert args.lock_fd >= 3 and (actual.st_dev, actual.st_ino) == (expected.st_dev, expected.st_ino)
    fcntl.flock(args.lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    sys.path.insert(0, str(source))
    import numpy as np
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    import pycbc
    from pycbc import scheme
    from pycbc.fft import fftw, mkl, torchfft
    from pycbc.types import Array, zeros
    from descriptor_reuse import DescriptorReuse, sha
    from descriptor_reuse_diagnostic import DescriptorReuse as DiagnosticReuse
    import threadpoolctl

    assert Path(pycbc.__file__).resolve().parent.parent == source
    assert sorted(os.sched_getaffinity(0)) == [8]
    root = Path(__file__).resolve().parent
    library_pins = json.loads((root / 'library-pins.json').read_text())
    for record in library_pins.values():
        assert sha(record['path']) == record['sha256']

    def library_identity(function):
        class DlInfo(ctypes.Structure):
            _fields_ = [('fname', ctypes.c_char_p), ('base', ctypes.c_void_p),
                        ('sname', ctypes.c_char_p), ('saddr', ctypes.c_void_p)]
        query = ctypes.CDLL(None).dladdr
        query.argtypes = [ctypes.c_void_p, ctypes.POINTER(DlInfo)]
        query.restype = ctypes.c_int
        info = DlInfo()
        assert query(ctypes.cast(function, ctypes.c_void_p), ctypes.byref(info))
        path = Path(os.fsdecode(info.fname)).resolve(strict=True)
        return {'path': str(path), 'sha256': sha(path)}

    libraries = {'mkl': library_identity(mkl.lib.DftiComputeBackward),
                 'fftw_float': library_identity(fftw.float_lib.fftwf_execute_dft),
                 'fftw_double': library_identity(fftw.double_lib.fftw_execute_dft)}
    assert libraries == library_pins

    def snapshot():
        pools = threadpoolctl.threadpool_info()
        assert pools and all(p['num_threads'] == 1 for p in pools)
        assert torch.get_num_threads() == torch.get_num_interop_threads() == 1
        assert sorted(os.sched_getaffinity(0)) == [8]
        return {'intra_op': torch.get_num_threads(), 'inter_op': torch.get_num_interop_threads(),
                'native_pools': pools, 'affinity': sorted(os.sched_getaffinity(0))}

    def bits(array):
        return hashlib.sha256(memoryview(array).cast('B')).hexdigest()

    record = {'state': 'running', 'pid': os.getpid(), 'pgid': os.getpgrp(),
              'start_ticks': Path('/proc/self/stat').read_text().split()[21],
              'inherited_lock': {'fd': args.lock_fd, 'device': actual.st_dev, 'inode': actual.st_ino},
              'command': sys.argv, 'cwd': os.getcwd(), 'interpreter': sys.executable,
              'helper_sha256': sha(__file__), 'cache_sha256': sha(root / 'descriptor_reuse.py'),
              'parent_cache_sha256': sha(root / 'descriptor_reuse_diagnostic.py'),
              'source': str(source), 'source_sha256': sha(mkl.__file__),
              'libraries': libraries,
              'versions': {'python': sys.version, 'numpy': np.__version__, 'torch': torch.__version__},
              'started_epoch': time.time(), 'cases': [], 'cache_observations': [], 'before': snapshot()}
    cache = plan = class_plan = primary = None
    try:
        with scheme.CPUScheme(1):
            torch_source = torch.zeros(2**21, dtype=torch.complex64)
            torch_target = torch.full_like(torch_source, 19+23j)
            torch_source[0] = 1+2j
            plan = torchfft._MKLCPUDirectIFFTPlan(mkl, 2**21, torch_source, torch_target,
                                               nthreads=1, promote=True)
            assert plan._promote and plan._inplace and len(plan._execute.argtypes) == 2
            assert ctypes.cast(plan._execute, ctypes.c_void_p).value == ctypes.cast(
                mkl.lib.DftiComputeBackward, ctypes.c_void_p).value
            record['torch_plan'] = {'class': type(plan).__qualname__, 'size': plan._size,
                                    'promote': plan._promote, 'inplace': plan._inplace,
                                    'execution_argument_count': len(plan._execute.argtypes)}
            class_source = Array(np.arange(16, dtype=np.complex64))
            class_target = zeros(16, dtype=np.complex64)
            class_plan = mkl.FFT(class_source, class_target)
            class_plan.execute()
            class_expected = class_target.numpy().copy()
            cache = DescriptorReuse(mkl)
            cache.install()
            owners = []  # Keep multiple live allocations per key to prove distinct pointers.
            for direction, n in (('fft', 16384), ('fft', 16777216), ('ifft', 16777216)):
                for allocation in range(3):
                    rng = np.random.default_rng(812 + allocation)
                    if direction == 'fft':
                        invec = Array(rng.standard_normal(n, dtype=np.float32))
                        outvec, reference = zeros(n // 2 + 1, dtype=np.complex64), zeros(n // 2 + 1, dtype=np.complex64)
                    else:
                        values = rng.standard_normal(n // 2 + 1, dtype=np.float32).astype(np.complex64)
                        values.imag = rng.standard_normal(n // 2 + 1, dtype=np.float32)
                        values[0] = values[0].real
                        values[-1] = values[-1].real
                        invec = Array(values)
                        outvec, reference = zeros(n, dtype=np.float32), zeros(n, dtype=np.float32)
                        del values
                    outvec[:] = 7
                    tokens = ('single', str(invec.kind), str(outvec.kind))
                    input_sha = bits(invec.numpy())
                    cache.assert_native()
                    cache.original[direction](invec, reference, *tokens)
                    assert bits(invec.numpy()) == input_sha
                    key, allowed = cache.key(direction, invec, outvec, *tokens)
                    assert allowed
                    prior = cache.cache.get(key)
                    getattr(mkl, direction)(invec, outvec, *tokens)
                    entry = cache.cache[key]
                    assert (entry is prior) is (allocation > 0)
                    _, public, _ = DiagnosticReuse.key(cache, direction, invec, outvec, *tokens)
                    record['cache_observations'].append({'key': public, 'hit': prior is entry,
                        'descriptor': entry['value'], 'input_pointer': int(invec.ptr),
                        'output_pointer': int(outvec.ptr)})
                    assert bits(invec.numpy()) == input_sha
                    assert np.array_equal(outvec.numpy().view(np.uint8), reference.numpy().view(np.uint8))
                    assert bits(outvec.numpy()) == bits(reference.numpy())
                    owners.append((invec, outvec))
                    class_plan.execute()
                    assert np.array_equal(class_target.numpy().view(np.uint8), class_expected.view(np.uint8))
                    torch_target.fill_(19+23j)
                    plan.execute(torch_source, torch_target)
                    assert torch.all(torch_target == 1+2j).item()
                    assert torch_source[0].item() == 1+2j
                    assert torch.count_nonzero(torch_source).item() == 1
                    assert plan._finalizer.alive
                    cache.assert_native()
                    record['cases'].append({'direction': direction, 'size': n, 'allocation': allocation,
                        'input_length': len(invec), 'output_length': len(outvec),
                        'input_dtype': invec.dtype.str, 'output_dtype': outvec.dtype.str,
                        'input_pointer': int(invec.ptr), 'output_pointer': int(outvec.ptr),
                        'input_preserved_sha256': input_sha, 'full_output_sha256': bits(outvec.numpy()),
                        'bitwise_original_equal': True, 'class_exact': True, 'promoted_torch_exact': True})
                    del reference
                    save(args.receipt, record)
            assert len({p for row in record['cases'] for p in (row['input_pointer'], row['output_pointer'])}) == 18
            assert cache.report()['creates'] == 3
            assert sum(row['hit'] for row in record['cache_observations']) == 6
            assert not cache.rows
            cache.finish()
            assert cache.report()['frees'] == 3
            cache.close()
            assert cache.report()['frees'] == 3
            assert not cache.cleanup_errors and not cache.poisoned
            # Coexistence remains valid after cache release and restoration.
            class_plan.execute()
            assert np.array_equal(class_target.numpy().view(np.uint8), class_expected.view(np.uint8))
            plan.execute(torch_source, torch_target)
            assert torch.all(torch_target == 1+2j).item()
            released_class, class_plan = class_plan, None
            mkl.check_status(mkl.lib.DftiFreeDescriptor(ctypes.byref(released_class.desc)))
            plan._finalizer()
            assert not plan._finalizer.alive
            record['coexisting_plans_explicitly_released'] = True
        if cache is not None:
            record['cache'] = cache.report()
        record['after'] = snapshot()
        record['state'] = 'complete'
    except BaseException as error:
        primary = error
        record.update(state='failed', error=repr(error))
        raise
    finally:
        cleanup = []
        if cache is not None and cache.installed:
            try:
                cache.finish(primary_error=primary)
            except BaseException as error:
                cleanup.append(repr(error))
        if cache is not None:
            record['cache'] = cache.report()
        if class_plan is not None:
            try:
                mkl.check_status(mkl.lib.DftiFreeDescriptor(ctypes.byref(class_plan.desc)))
            except BaseException as error:
                cleanup.append(repr(error))
        if plan is not None and plan._finalizer.alive:
            try:
                plan._finalizer()
            except BaseException as error:
                cleanup.append(repr(error))
        if cleanup:
            record.update(state='failed', cleanup_errors=cleanup)
        record['finished_epoch'] = time.time()
        save(args.receipt, record)
    if record['state'] != 'complete':
        raise RuntimeError('Real descriptor qualification failed')


if __name__ == '__main__':
    main()
