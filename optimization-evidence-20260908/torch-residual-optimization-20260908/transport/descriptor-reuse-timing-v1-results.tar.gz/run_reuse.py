"""Common setup for original-function baseline and cache candidate execution."""
import argparse
import json
from pathlib import Path
import runpy
import sys
import time

from descriptor_reuse import DescriptorReuse, sha


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def baseline_finish(cache, primary):
    errors = []
    def originals():
        assert all(getattr(cache.mkl, n) is cache.original[n] for n in ('fft', 'ifft'))
    for name, operation in (('close', cache.close), ('native', cache.assert_native),
                            ('original-functions', originals)):
        try:
            operation()
        except BaseException as error:
            cache.poisoned = True
            errors.append(error)
            cache.finalization_errors.append({'operation': name, 'error': repr(error)})
    if errors and primary is None:
        raise errors[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reuse', choices=('yes', 'no'), required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    assert command and not args.receipt.exists()
    from pycbc.fft import mkl
    cache = DescriptorReuse(mkl)  # Identical construction point in both variants.
    cached = args.reuse == 'yes'
    root = Path(__file__).resolve().parent
    result = {'state': 'running', 'helper_sha256': sha(__file__),
              'cache_sha256': sha(root / 'descriptor_reuse.py'),
              'parent_cache_sha256': sha(root / 'descriptor_reuse_diagnostic.py'),
              'mkl_source': str(Path(mkl.__file__).resolve()), 'mkl_source_sha256': sha(mkl.__file__),
              'variant': 'cached' if cached else 'original',
              'started_epoch': time.time(), 'command': command}
    save(args.receipt, result)
    previous, primary = sys.argv, None
    try:
        if cached:
            cache.install()
        else:
            assert all(getattr(mkl, n) is cache.original[n] for n in ('fft', 'ifft'))
        sys.argv = command
        try:
            runpy.run_path(command[0], run_name='__main__')
        except SystemExit as error:
            if error.code not in (0, None):
                raise
        assert not cache.rows
        assert len(cache.entries) == (3 if cached else 0)
        cache.assert_native()
    except BaseException as error:
        primary = error
        result.update(state='failed', error=repr(error))
        raise
    finally:
        sys.argv = previous
        try:
            if cached:
                cache.finish(primary_error=primary)
            else:
                baseline_finish(cache, primary)
        except BaseException as error:
            result.update(state='failed', cleanup_error=repr(error))
            raise
        finally:
            result['cache'] = cache.report()
            if (primary is None and not cache.poisoned and cache.closed
                    and not cache.installed and not cache.cleanup_errors
                    and not cache.invariant_errors and not cache.finalization_errors):
                result['state'] = 'complete'
            else:
                result['state'] = 'failed'
            result['finished_epoch'] = time.time()
            save(args.receipt, result)
    if result['state'] != 'complete':
        raise RuntimeError('Descriptor execution was incomplete')


if __name__ == '__main__':
    main()
