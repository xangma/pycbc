"""Fake-native lifecycle contracts executed from the pinned original MKL AST."""
import argparse
import ast
import ctypes
import gc
import json
import os
from pathlib import Path
import sys
import threading
import types
import unittest
from unittest.mock import patch
import weakref

import numpy as np

from descriptor_reuse_diagnostic import DescriptorReuse, SOURCE_SHA256, SYMBOLS, sha

SOURCE = Path(os.environ.get('REUSE_SOURCE',
              '/private/tmp/pycbc-torch-fft-optimization-20260908/pycbc/fft/mkl.py'))


class Vec:
    next_pointer = 10000
    registry = weakref.WeakValueDictionary()

    def __init__(self, n, dtype, ptr=None):
        self.n, self.dtype = n, np.dtype(dtype)
        self.kind = 'complex' if self.dtype.kind == 'c' else 'real'
        self.precision = 'single' if self.dtype in (np.dtype('f4'), np.dtype('c8')) else 'double'
        Vec.next_pointer += 1
        self.ptr = Vec.next_pointer if ptr is None else ptr
        self.data = np.arange(16).astype(dtype)
        Vec.registry[self.ptr] = self

    def __len__(self):
        return self.n


class CPU:
    num_threads = 1


class OtherCPU(CPU):
    pass


class Base:
    def __init__(self, source, target, nbatch, size):
        self.invec, self.outvec, self.nbatch = source, target, nbatch
        self.size = size or max(len(source), len(target))
        self.inplace = source.ptr == target.ptr
        self.idist, self.odist = len(source), len(target)


def simple(value):
    if isinstance(value, ctypes.c_void_p):
        return value.value
    if hasattr(value, '_obj'):
        return value._obj.value
    return value


class Native:
    def __init__(self, lib, name, address):
        self.lib, self.name = lib, name
        self._as_parameter_ = ctypes.c_void_p(address)
        self.argtypes = None
        self.restype = ctypes.c_int

    def __setattr__(self, name, value):
        if name in ('argtypes', 'restype') and hasattr(self, name):
            self.lib.events.append(('signature', self.name, name, repr(value)))
        object.__setattr__(self, name, value)

    def __call__(self, *args):
        lib, name = self.lib, self.name
        lib.events.append(('call', name, tuple(simple(a) for a in args)))
        operation = {'DftiCreateDescriptor_s_1d': 'create',
                     'DftiCreateDescriptor_d_1d': 'create',
                     'DftiCommitDescriptor': 'commit', 'DftiFreeDescriptor': 'free',
                     'DftiComputeForward': 'compute', 'DftiComputeBackward': 'compute',
                     'DftiErrorMessage': 'error'}.get(name)
        if name == 'DftiSetValue':
            operation = 'set:' + str(args[1])
        fault = lib.faults.get(operation)
        if isinstance(fault, BaseException):
            raise fault
        if callable(fault):
            return fault(*args)
        if fault is not None:
            return fault
        if operation == 'create':
            lib.next_handle += 1
            args[0]._obj.value = lib.next_handle
            lib.live.add(lib.next_handle)
        elif operation == 'free':
            value = args[0]._obj.value
            if value not in lib.live:
                raise AssertionError('Invalid/double free: ' + str(value))
            lib.live.remove(value)
            lib.freed.append(value)
            args[0]._obj.value = None
        elif operation == 'compute':
            assert args[0].value in lib.live, 'Use after free'
            source, target = Vec.registry[args[1]], Vec.registry[args[2]]
            target.data[:] = np.real(source.data) * 2
        elif operation == 'error':
            return b'fake native error'
        return 0


class Library:
    def __init__(self):
        self.events, self.freed, self.live, self.faults = [], [], set(), {}
        self.next_handle = 100
        for i, name in enumerate(SYMBOLS):
            setattr(self, name, Native(self, name, 200 + i))


def module():
    assert sha(SOURCE) == SOURCE_SHA256
    m = types.ModuleType('pinned_mkl_fake')
    m.__file__ = str(SOURCE)
    m.__dict__.update(ctypes=ctypes, lib=Library(), zeros=Vec,
                      _scheme=types.SimpleNamespace(mgr=types.SimpleNamespace(state=CPU()), CPUScheme=CPU),
                      _BaseFFT=Base, _BaseIFFT=Base)
    tree = ast.parse(SOURCE.read_text(), filename=str(SOURCE))
    tree.body = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) or (
        isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id != 'lib')]
    exec(compile(tree, str(SOURCE), 'exec'), m.__dict__)
    return m


def vectors(config=0):
    n, inv = (16384, False) if config == 0 else (16777216, config == 2)
    return (Vec(n // 2 + 1, 'c8'), Vec(n, 'f4')) if inv else (Vec(n, 'f4'), Vec(n // 2 + 1, 'c8'))


def execute(m, pair, config=0, tokens=None):
    source, target = pair
    return getattr(m, 'ifft' if config == 2 else 'fft')(
        source, target, *(tokens or (source.precision, source.kind, target.kind)))


def calls(lib, name):
    return [e for e in lib.events if e[:2] == ('call', name)]


class Contracts(unittest.TestCase):
    def test_pinned_bodies_miss_hit_new_buffers_and_uncached_baseline(self):
        for config in range(3):
            baseline, cached, uncached = module(), module(), module()
            pair = vectors(config)
            original = pair[0].data.copy()
            self.assertIsNone(execute(baseline, pair, config))
            expected = pair[1].data.copy()
            original_events = baseline.lib.events[:]
            for reuse, m in ((True, cached), (False, uncached)):
                c = DescriptorReuse(m, reuse=reuse)
                c.install()
                self.assertIsNone(execute(m, pair, config))
                events = m.lib.events[:]
                if reuse:
                    self.assertEqual(events, [e for e in original_events if e[1] != 'DftiFreeDescriptor'])
                else:
                    self.assertEqual(events, original_events)
                np.testing.assert_array_equal(pair[0].data, original)
                np.testing.assert_array_equal(pair[1].data, expected)
                for _ in range(3):
                    new = vectors(config)
                    new[0].data += 5
                    before = new[0].data.copy()
                    m.lib.events.clear()
                    execute(m, new, config)
                    np.testing.assert_array_equal(new[0].data, before)
                    np.testing.assert_array_equal(new[1].data, np.real(before) * 2)
                    if reuse:
                        self.assertEqual(len(m.lib.events), 2)  # Exact signature assignment and compute.
                        self.assertTrue(c.rows[-1]['hit'])
                    else:
                        self.assertFalse(c.rows[-1]['hit'])
                c.finish()
                count = len(m.lib.freed)
                c.close()
                self.assertEqual(len(m.lib.freed), count)
                self.assertEqual(count, 1 if reuse else 4)
                self.assertFalse(m.lib.live)
                self.assertTrue(all(p['inverse_ast_equal'] for p in c.proofs.values()))
                self.assertTrue(all(e['free_attempts'] == e['free_successes'] == 1 for e in c.entries))

    def test_three_entries_no_cross_direction_and_capacity_fallback(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        for _ in range(2):
            for config in range(3):
                execute(m, vectors(config), config)
        self.assertEqual((len(c.cache), c.report()['creates'], c.report()['hits']), (3, 3, 3))
        m._scheme.mgr.state = OtherCPU()
        execute(m, vectors())
        self.assertFalse(c.rows[-1]['eligible'])
        self.assertEqual(len(c.cache), 3)
        c.finish()
        self.assertEqual(len(m.lib.freed), 4)

    def test_every_configuration_component_avoids_stale_hit(self):
        def set_dtype(pair, i, dtype):
            pair[i].dtype = np.dtype(dtype)

        mutations = {
            'input_length': lambda m, p: setattr(p[0], 'n', 16383),
            'output_length_same_max': lambda m, p: setattr(p[1], 'n', 8192),
            'input_dtype': lambda m, p: set_dtype(p, 0, 'f8'),
            'output_dtype': lambda m, p: set_dtype(p, 1, 'c16'),
            'placement': lambda m, p: setattr(p[1], 'ptr', p[0].ptr),
            'thread_count': lambda m, p: setattr(m._scheme.mgr.state, 'num_threads', 2),
            'scheme_class': lambda m, p: setattr(m._scheme.mgr, 'state', OtherCPU()),
            'device': lambda m, p: setattr(m._scheme.mgr.state, 'device', 'different'),
            'device_num': lambda m, p: setattr(m._scheme.mgr.state, 'device_num', 1),
            'device_spec': lambda m, p: setattr(m._scheme.mgr.state, 'device_spec', 'cpu'),
            'torch_device': lambda m, p: setattr(m._scheme.mgr.state, 'torch_device', 'cpu'),
        }
        for name, change in mutations.items():
            with self.subTest(component=name):
                m = module()
                c = DescriptorReuse(m)
                c.install()
                execute(m, vectors())
                pair = vectors()
                change(m, pair)
                execute(m, pair)
                self.assertFalse(c.rows[-1]['hit'])
                c.finish()
                self.assertFalse(m.lib.live)
        for i, token in enumerate(('double', 'complex', 'real')):
            m = module()
            c = DescriptorReuse(m)
            c.install()
            execute(m, vectors())
            tokens = ['single', 'real', 'complex']
            tokens[i] = token
            execute(m, vectors(), tokens=tokens)
            self.assertFalse(c.rows[-1]['eligible'])
            c.finish()

    def test_unsupported_and_inplace_exact_original_sequence(self):
        for inplace in (False, True):
            m, baseline = module(), module()
            pair = (Vec(8, 'c8'), Vec(8, 'c8'))
            if inplace:
                pair = (pair[0], pair[0])
            execute(baseline, pair)
            c = DescriptorReuse(m)
            c.install()
            execute(m, pair)
            self.assertEqual(m.lib.events, baseline.lib.events)
            self.assertFalse(c.rows[-1]['eligible'])
            c.finish()
            self.assertFalse(c.entries)

    def test_class_plan_identity_signatures_and_operation_sequence(self):
        pair = vectors()
        def sequence(m, cached):
            c = DescriptorReuse(m, reuse=cached)
            c.install()
            plan = m.FFT(*pair)
            snapshots = [c.signatures()]
            execute(m, pair)
            snapshots.append(c.signatures())
            plan.execute()
            snapshots.append(c.signatures())
            c.assert_native()
            m.lib.DftiFreeDescriptor(ctypes.byref(plan.desc))
            events = m.lib.events[:]
            c.finish()
            return snapshots, events
        original, cached = module(), module()
        s1, e1 = sequence(original, False)
        s2, e2 = sequence(cached, True)
        self.assertEqual(s1, s2)
        removed = False
        expected = []
        for event in e1:
            if event[1] == 'DftiFreeDescriptor' and not removed:
                removed = True
            else:
                expected.append(event)
        self.assertEqual(e2, expected)

    def test_secondary_invariant_and_finalization_errors_preserve_primary(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        primary = RuntimeError('workload primary')
        def fail(*args):
            m.lib.DftiComputeForward = Native(m.lib, 'DftiComputeForward', 990)
            raise primary
        m.lib.faults['compute'] = fail
        with self.assertRaises(RuntimeError) as caught:
            execute(m, vectors())
        self.assertIs(caught.exception, primary)
        self.assertTrue(c.poisoned)
        self.assertEqual(len(c.invariant_errors), 1)
        c.finish(primary_error=primary)
        self.assertTrue(c.closed)
        self.assertFalse(c.installed)
        self.assertEqual(c.finalization_errors[0]['operation'], 'restore')
        self.assertIs(m.fft, c.original['fft'])

    def test_finish_records_both_errors_restores_python_and_preserves_close_error(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        execute(m, vectors())
        primary = RuntimeError('free primary')
        m.lib.faults['free'] = primary
        m.fft = lambda *args: None
        with self.assertRaises(RuntimeError) as caught:
            c.finish()
        self.assertIs(caught.exception, primary)
        self.assertEqual([e['operation'] for e in c.finalization_errors], ['close', 'restore'])
        self.assertIs(m.fft, c.original['fft'])
        self.assertTrue(c.closed)
        c.close()
        self.assertEqual(len(calls(m.lib, 'DftiFreeDescriptor')), 1)

    def test_failure_cleanup_and_primary_exception_identity(self):
        for operation in ('compute', 'set:27', 'commit'):
            for python_error in (False, True):
                if operation == 'commit' and not python_error:
                    continue  # Original ignores the commit return; tested separately.
                with self.subTest(operation=operation, python_error=python_error):
                    m = module()
                    error = RuntimeError('injected ' + operation)
                    m.lib.faults[operation] = error if python_error else 9
                    c = DescriptorReuse(m)
                    c.install()
                    with self.assertRaises(RuntimeError) as caught:
                        execute(m, vectors())
                    if python_error:
                        self.assertIs(caught.exception, error)
                    else:
                        self.assertEqual(str(caught.exception), "b'fake native error'")
                    self.assertEqual(len(m.lib.freed), 1)
                    self.assertFalse(c.cache)
                    c.finish()
                    self.assertEqual(len(m.lib.freed), 1)

    def test_native_status_free_precedes_original_status_check(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        execute(m, vectors())
        m.lib.events.clear()
        m.lib.faults['compute'] = 9
        with self.assertRaisesRegex(RuntimeError, 'fake native error'):
            execute(m, vectors())
        names = [e[1] for e in m.lib.events if e[0] == 'call']
        self.assertEqual(names, ['DftiComputeForward', 'DftiFreeDescriptor', 'DftiErrorMessage'])
        c.finish()

    def test_original_unchecked_returns_are_not_silently_fixed(self):
        for operation in ('set:11', 'set:10', 'commit'):
            m, baseline = module(), module()
            m.lib.faults[operation] = baseline.lib.faults[operation] = 9
            pair = vectors()
            execute(baseline, pair)
            c = DescriptorReuse(m)
            c.install()
            execute(m, pair)
            self.assertEqual(m.lib.events, [e for e in baseline.lib.events if e[1] != 'DftiFreeDescriptor'])
            c.finish()

    def test_creation_fail_closed_status_null_sentinel_and_preallocation_exception(self):
        def null_create(desc, domain, size):
            desc._obj.value = None
            return 0
        def ambiguous_create(desc, domain, size):
            desc._obj.value = 777
            return 9
        for fault in (9, 0, null_create, ambiguous_create, RuntimeError('create exception')):
            m = module()
            m.lib.faults['create'] = fault
            c = DescriptorReuse(m)
            c.install()
            with self.assertRaises(RuntimeError) as caught:
                execute(m, vectors())
            if isinstance(fault, BaseException):
                self.assertIs(caught.exception, fault)
            else:
                self.assertIn('Diagnostic fail-closed descriptor creation', str(caught.exception))
                self.assertTrue(c.poisoned)
            self.assertEqual(len(c.entries), 0)
            self.assertFalse(calls(m.lib, 'DftiSetValue'))
            self.assertFalse(calls(m.lib, 'DftiFreeDescriptor'))
            c.finish()

    def test_free_failure_poison_no_retry_preserve_primary_restore(self):
        for native_error in (False, True):
            for fault in (9, RuntimeError('free exception')):
                m = module()
                c = DescriptorReuse(m)
                c.install()
                execute(m, vectors())
                m.lib.faults['free'] = fault
                if native_error:
                    primary = RuntimeError('compute primary')
                    m.lib.faults['compute'] = primary
                    with self.assertRaises(RuntimeError) as caught:
                        execute(m, vectors())
                    self.assertIs(caught.exception, primary)
                    c.finish()
                else:
                    with self.assertRaises(RuntimeError):
                        c.finish()
                self.assertTrue(c.poisoned)
                self.assertTrue(c.closed)
                self.assertFalse(c.installed)
                c.close()
                self.assertEqual(len(calls(m.lib, 'DftiFreeDescriptor')), 1)
                self.assertEqual(c.entries[0]['state'], 'uncertain')
                self.assertEqual(len(c.cleanup_errors), 1)
                with self.assertRaises(RuntimeError):
                    c.wrappers['fft'](*vectors(), 'single', 'real', 'complex')

    def test_nonzero_compute_and_failed_free_preserves_native_error(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        m.lib.faults.update(compute=9, free=8)
        with self.assertRaisesRegex(RuntimeError, 'fake native error'):
            execute(m, vectors())
        self.assertTrue(c.poisoned)
        c.finish()
        self.assertEqual(len(calls(m.lib, 'DftiFreeDescriptor')), 1)

    def test_reentry_owner_thread_recycled_identifier_and_fork(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        pair = vectors()
        execute(m, pair)
        errors = []
        def attempt():
            for operation in (lambda: execute(m, pair), c.close):
                try:
                    operation()
                except RuntimeError as error:
                    errors.append(str(error))
        before = len(m.lib.events)
        t = threading.Thread(target=attempt)
        t.start()
        t.join()
        recycled = types.SimpleNamespace(ident=threading.get_ident())
        with patch('threading.current_thread', return_value=recycled):
            attempt()
        self.assertEqual(len(errors), 4)
        self.assertEqual(len(m.lib.events), before)
        if hasattr(os, 'fork'):
            read_fd, write_fd = os.pipe()
            pid = os.fork()
            if pid == 0:
                os.close(read_fd)
                try:
                    errors.clear()
                    attempt()
                    os.write(write_fd, json.dumps({'errors': errors,
                             'unchanged': len(m.lib.events) == before}).encode())
                    os._exit(0)
                except BaseException:
                    os._exit(1)
            os.close(write_fd)
            child = json.loads(os.read(read_fd, 10000))
            os.close(read_fd)
            self.assertEqual(os.waitpid(pid, 0)[1], 0)
            self.assertEqual(len(child['errors']), 2)
            self.assertTrue(child['unchanged'])
        m.lib.faults['compute'] = lambda *args: execute(m, pair)
        with self.assertRaisesRegex(RuntimeError, 'reentrant'):
            execute(m, pair)
        self.assertFalse(c.cache)
        c.finish()

    def test_no_retained_buffers_or_use_after_release(self):
        m = module()
        c = DescriptorReuse(m)
        c.install()
        pair = vectors()
        refs = [weakref.ref(v) for v in pair]
        execute(m, pair)
        del pair
        gc.collect()
        self.assertTrue(all(r() is None for r in refs))
        execute(m, vectors())
        self.assertTrue(c.rows[-1]['hit'])
        c.finish()
        with self.assertRaisesRegex(RuntimeError, 'Closed'):
            c.wrappers['fft'](*vectors(), 'single', 'real', 'complex')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Contracts))
    receipt = {'state': 'pass' if result.wasSuccessful() else 'failed', 'tests': result.testsRun,
               'failures': result.failures, 'errors': result.errors,
               'source_sha256': sha(SOURCE), 'helper_sha256': sha(Path(__file__).with_name('descriptor_reuse.py')),
               'test_sha256': sha(__file__),
               'scope': 'Fake-native pinned-body contracts; no real MKL or performance evidence.'}
    if args.receipt:
        args.receipt.write_text(json.dumps(receipt, indent=2, default=str) + '\n')
    if not result.wasSuccessful():
        sys.exit(1)


if __name__ == '__main__':
    main()
