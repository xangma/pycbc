"""Fresh native/science gates followed by four balanced timing repetitions."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
LOADER = Path('/home/xangma/pycbc-torch-fft-optimization-20260908/loader-v1')
SOURCE = LOADER / 'source-candidate'
REFERENCES = {name: LOADER / 'runs' / f'qual-{name}-candidate' for name in ('standard', 'cuda')}
PYTHON = '/home/xangma/pycbc-torch-split-20260905/venv/bin/python'
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
STATUS = ROOT / 'reuse-status.json'
CELLS = ('standard-original', 'standard-cached', 'cuda-original', 'cuda-cached')
ORDERS = ((0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1))
QUAL_CASES = tuple('qual-' + cell for cell in CELLS)
TIMING_CASES = tuple(f'timing-{repeat}-{CELLS[i]}' for repeat, order in enumerate(ORDERS, 1) for i in order)
CASES = QUAL_CASES + TIMING_CASES


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def pins():
    for name, expected in read(ROOT / 'manifest.json').items():
        assert sha(ROOT / name) == expected, name
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD']).decode().strip() == read(ROOT / 'source-pins.json')['revisions']['candidate']
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'])
    for name, expected in read(ROOT / 'current-source-pins.json').items():
        assert sha(SOURCE / name) == expected, name
    for path, expected in read(ROOT / 'input-pins.json').items():
        assert sha(path) == expected, path
    for scheme, records in read(ROOT / 'reference-pins.json').items():
        for name, expected in records.items():
            assert sha(REFERENCES[scheme] / name) == expected, (scheme, name)
    for record in read(ROOT / 'library-pins.json').values():
        assert sha(record['path']) == record['sha256']
    for name in ('checked-inspiral.py', 'threadpoolctl.py', 'config.json',
                 'source-pins.json', 'source-staging.json'):
        assert sha(LOADER / name) == sha(ROOT / name), name
    return {'manifest_sha256': sha(ROOT / 'manifest.json'),
            'source_pins_sha256': sha(ROOT / 'current-source-pins.json'),
            'reference_pins_sha256': sha(ROOT / 'reference-pins.json')}


def bind_provenance_verifiers(current, reference):
    """Only exact predeclared run paths choose original versus current helpers."""
    current.ROOT, reference.ROOT = ROOT, LOADER
    verify_current, verify_reference = current.verified_run, reference.verified_run
    current_paths = {(ROOT / 'runs' / name).resolve() for name in CASES}
    reference_paths = {folder.resolve() for folder in REFERENCES.values()}
    def verified_run(folder, role):
        folder = Path(folder).resolve()
        if folder in reference_paths:
            return verify_reference(folder, role)
        if folder in current_paths:
            return verify_current(folder, role)
        raise ValueError('Unexpected run location for helper provenance: ' + str(folder))
    current.verified_run = verified_run
    return verified_run


def verify_cache(record, cached):
    assert record['reuse'] and record['closed'] and record['restored']
    assert not record['poisoned'] and not record['cleanup_errors']
    assert not record['invariant_errors'] and not record['finalization_errors']
    assert all(p['inverse_ast_equal'] for p in record['ast'].values())
    assert 'rows' not in record and 'hits' not in record
    entries = record['entries']
    assert len(entries) == record['creates'] == record['frees'] == (3 if cached else 0)
    assert all(e['state'] == 'freed' and e['free_attempts'] == e['free_successes'] == 1
               and e['free_reason'] == 'close' for e in entries)
    return {'owned_descriptors': len(entries), 'frees': record['frees']}


def verify_real():
    result = read(ROOT / 'real-contracts.json')
    assert result['state'] == 'complete' and result['helper_sha256'] == sha(ROOT / 'real_contracts.py')
    assert result['cache_sha256'] == sha(ROOT / 'descriptor_reuse.py')
    assert result['parent_cache_sha256'] == sha(ROOT / 'descriptor_reuse_diagnostic.py')
    assert result['source'] == str(SOURCE) and result['source_sha256'] == read(ROOT / 'current-source-pins.json')['pycbc/fft/mkl.py']
    assert result['libraries'] == read(ROOT / 'library-pins.json')
    assert len(result['cases']) == 9 and result['coexisting_plans_explicitly_released']
    assert all(c['bitwise_original_equal'] and c['class_exact'] and c['promoted_torch_exact'] for c in result['cases'])
    assert [(c['direction'], c['size'], c['allocation']) for c in result['cases']] == [
        (direction, n, allocation) for direction, n in (('fft', 16384), ('fft', 16777216), ('ifft', 16777216)) for allocation in range(3)]
    assert len({p for c in result['cases'] for p in (c['input_pointer'], c['output_pointer'])}) == 18
    assert result['torch_plan'] == {'class': '_MKLCPUDirectIFFTPlan', 'size': 2097152,
                                    'promote': True, 'inplace': True, 'execution_argument_count': 2}
    for phase in ('before', 'after'):
        snapshot = result[phase]
        assert snapshot['intra_op'] == snapshot['inter_op'] == 1 and snapshot['affinity'] == [8]
        assert snapshot['native_pools'] and all(p['num_threads'] == 1 for p in snapshot['native_pools'])
    metrics = verify_cache(result['cache'], True)
    obs = result['cache_observations']
    assert len(obs) == 9 and [row['hit'] for row in obs] == [False, True, True] * 3
    assert len({row['descriptor'] for row in obs}) == 3
    for start in range(0, 9, 3):
        assert len({row['descriptor'] for row in obs[start:start + 3]}) == 1
    assert len({p for row in obs for p in (row['input_pointer'], row['output_pointer'])}) == 18
    for case, row in zip(result['cases'], obs, strict=True):
        assert case['direction'] == row['key']['direction'] and case['size'] == row['key']['size']
        for name in ('input_pointer', 'output_pointer'):
            assert case[name] == row[name]
    metrics.update(calls=9, hits=6)
    return {'receipt_sha256': sha(ROOT / 'real-contracts.json'), 'metrics': metrics}


def main():
    assert not STATUS.exists()
    assert Path(sys.executable).resolve() == Path(PYTHON).resolve()
    os.environ.update(read(ROOT / 'config.json')['environment'])
    os.sched_setaffinity(0, {8})
    status = {'state': 'starting', 'pid': os.getpid(), 'pgid': os.getpgrp(),
              'start_ticks': Path('/proc/self/stat').read_text().split()[21],
              'started_epoch': time.time(), 'workers': [], 'comparisons': {},
              'timing_orders': [[CELLS[i] for i in order] for order in ORDERS]}
    save(STATUS, status)
    try:
        with LOCK.open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            frozen = pins()
            campaign = module('fast_campaign', 'loader_campaign.py')
            reference = module('fast_reference', 'loader_campaign.py')
            bind_provenance_verifiers(campaign, reference)
            checker = module('fast_runtime', 'checked-inspiral.py')
            controls = module('fast_controls', 'campaign_controls.py')
            comparator = module('fast_comparator', 'compare-triggers.py')
            roles = {name: (name + '-candidate', SOURCE,
                      'cpu:1' if name == 'standard' else 'torch:cuda:0', 'candidate') for name in REFERENCES}
            science = {}
            for name, folder in REFERENCES.items():
                _, science[name] = reference.qualified_science(folder, roles[name], controls)
                assert science[name] == read(ROOT / 'science-reference.json')['by_scheme'][roles[name][2]]
            status.update(state='running', phase='native', pins=frozen)
            save(STATUS, status)

            def run(name, command, env):
                assert pins() == frozen
                log = ROOT / (name + '.log')
                worker = {'name': name, 'command': command, 'cwd': str(ROOT), 'log': str(log),
                          'started_epoch': time.time()}
                with log.open('x') as output:
                    process = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                        stdout=output, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),))
                    worker.update(pid=process.pid, pgid=os.getpgid(process.pid),
                        start_ticks=Path(f'/proc/{process.pid}/stat').read_text().split()[21])
                    status['workers'].append(worker)
                    save(STATUS, status)
                    try:
                        worker['exit'] = process.wait(timeout=1800)
                    except subprocess.TimeoutExpired:
                        status.update(state='failed', error='Worker timeout; terminating process group')
                        save(STATUS, status)
                        os.killpg(os.getpgrp(), signal.SIGTERM)
                        raise
                worker.update(finished_epoch=time.time(), log_sha256=sha(log))
                save(STATUS, status)
                assert worker['exit'] == 0, worker
                assert pins() == frozen
                return worker

            def run_case(name, cell, qualify):
                family, variant = cell.split('-')
                role, cached = roles[family], variant == 'cached'
                mode = 'reuse-qualify' if qualify else 'timing'
                command = [PYTHON, str(ROOT / 'run-case.py'), '--config', str(ROOT / 'config.json'),
                           '--case', name, '--mode', mode, '--reuse', 'yes' if cached else 'no',
                           '--scheme', role[2], '--source', str(SOURCE), '--bank', str(campaign.BANK),
                           '--segment-length', '512', '--start-pad', '112', '--end-pad', '16']
                worker = run(name, command, dict(os.environ, PYCBC_BENCHMARK_LOCK_FD=str(lock.fileno())))
                folder = ROOT / 'runs' / name
                receipt = campaign.verified_run(folder, role)
                assert receipt['mode'] == mode and receipt['reuse'] == ('yes' if cached else 'no')
                result = read(folder / 'descriptors.json')
                assert result['state'] == 'complete' and result['helper_sha256'] == sha(ROOT / 'run_reuse.py')
                assert result['cache_sha256'] == sha(ROOT / 'descriptor_reuse.py')
                assert result['parent_cache_sha256'] == sha(ROOT / 'descriptor_reuse_diagnostic.py')
                assert result['variant'] == variant
                assert result['mkl_source'] == str(SOURCE / 'pycbc/fft/mkl.py')
                assert result['mkl_source_sha256'] == read(ROOT / 'current-source-pins.json')['pycbc/fft/mkl.py']
                worker.update(descriptors=verify_cache(result['cache'], cached),
                              descriptors_sha256=sha(folder / 'descriptors.json'))
                if not qualify:
                    assert not (folder / 'qualification.json').exists()
                    assert result['command'] == receipt['executable_cli']
                return folder, role, worker

            def compare(name, left, left_role, right, right_role):
                status['comparisons'][name] = campaign.compare_runs(name, left, left_role, right, right_role, comparator)
                save(STATUS, status)

            native_command = [PYTHON, str(ROOT / 'real_contracts.py'), '--source', str(SOURCE),
                              '--receipt', str(ROOT / 'real-contracts.json'), '--lock-fd', str(lock.fileno())]
            native = run('real-contracts', native_command,
                         checker.clean_environment(os.environ, read(ROOT / 'config.json'), SOURCE))
            native['qualification'] = verify_real()
            status['phase'] = 'qualification'
            save(STATUS, status)
            qualifications = {}
            for name, cell in zip(QUAL_CASES, CELLS, strict=True):
                family, variant = cell.split('-')
                folder, role, worker = run_case(name, cell, True)
                qualification, measured = campaign.qualified_science(folder, role, controls)
                assert measured == science[family]
                qualifications[cell] = qualification
                worker['qualification'] = qualification
                compare(name + '-vs-qualified-own', REFERENCES[family], role, folder, role)
                if variant == 'cached':
                    compare(name + '-vs-original', ROOT / 'runs' / ('qual-' + family + '-original'), role, folder, role)
            compare('qual-cuda-cached-vs-standard-cached', ROOT / 'runs/qual-standard-cached', roles['standard'],
                    ROOT / 'runs/qual-cuda-cached', roles['cuda'])
            save(ROOT / 'qualifications.json', qualifications)
            # This exact helper and interpreter have now passed native and both
            # schemes' full science gates. Timed children contain no science hooks.
            status.update(phase='timing', qualification_gate_epoch=time.time(),
                          qualification_sha256=sha(ROOT / 'qualifications.json'))
            save(STATUS, status)
            samples = {cell: [] for cell in CELLS}
            for repeat, order in enumerate(ORDERS, 1):
                for i in order:
                    cell = CELLS[i]
                    name = f'timing-{repeat}-{cell}'
                    folder, role, worker = run_case(name, cell, False)
                    compare(name + '-vs-own-qualification', ROOT / 'runs' / ('qual-' + cell), role, folder, role)
                    compare(name + '-vs-standard-cached-qualification', ROOT / 'runs/qual-standard-cached',
                            roles['standard'], folder, role)
                    metric = controls.timing(folder, 384, read(ROOT / 'source-pins.json')['revisions']['candidate'],
                                             campaign.BANK_SHA, qualifications[cell])
                    samples[cell].append({'repeat': repeat, 'case': name, 'metrics': metric})
                    worker['timing'] = metric
                    save(ROOT / 'samples.json', samples)
                    save(STATUS, status)
                # Pair all numerical comparisons with contemporaneous controls.
                for family in ('standard', 'cuda'):
                    compare(f'timing-{repeat}-{family}-cached-vs-original',
                            ROOT / 'runs' / f'timing-{repeat}-{family}-original', roles[family],
                            ROOT / 'runs' / f'timing-{repeat}-{family}-cached', roles[family])
                compare(f'timing-{repeat}-cuda-cached-vs-standard-cached',
                        ROOT / 'runs' / f'timing-{repeat}-standard-cached', roles['standard'],
                        ROOT / 'runs' / f'timing-{repeat}-cuda-cached', roles['cuda'])
            assert pins() == frozen
            status.update(state='complete', phase='complete')
    except BaseException as error:
        status.update(state='failed', error=repr(error))
        raise
    finally:
        status['finished_epoch'] = time.time()
        save(STATUS, status)


if __name__ == '__main__':
    main()
