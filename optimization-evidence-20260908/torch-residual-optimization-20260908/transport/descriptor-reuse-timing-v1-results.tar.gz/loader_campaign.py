"""Fresh serial inspiral qualification and timing with immutable evidence."""
import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REMOTE = Path('/home/xangma/pycbc-torch-fft-optimization-20260908')
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
BANK = Path('/home/xangma/pycbc-torch-reference-protocol-20260907/inputs/bank-compressed.hdf')
BANK_SHA = '26050d48322a1d71092bb0e024e71a89ace56b3e7b1c5e4cf20c7b769213fb7f'
BASE = REMOTE / 'diagnostics-v5/source-candidate'
CAND = ROOT / 'source-candidate'
ROLES = [('standard-baseline', BASE, 'cpu:1', 'baseline'),
         ('standard-candidate', CAND, 'cpu:1', 'candidate'),
         ('cpu-baseline', BASE, 'torch:cpu:1', 'baseline'),
         ('cpu-candidate', CAND, 'torch:cpu:1', 'candidate'),
         ('cuda-baseline', BASE, 'torch:cuda:0', 'baseline'),
         ('cuda-candidate', CAND, 'torch:cuda:0', 'candidate')]


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def git(source, *args):
    return subprocess.check_output(['git', '-C', str(source), *args])


def pins():
    for name, expected in read(ROOT / 'manifest.json').items():
        assert sha(ROOT / name) == expected, name
    expected = read(ROOT / 'source-pins.json')
    staged = read(ROOT / 'source-staging.json')
    for key, source in [('baseline', BASE), ('candidate', CAND)]:
        assert git(source, 'rev-parse', 'HEAD').decode().strip() == expected['revisions'][key]
        assert not git(source, 'status', '--porcelain'), source
        assert sha(source / 'bin/pycbc_inspiral') == expected['executable_sha256']
        for name, digest in staged['native_sha256'].items():
            assert sha(source / name) == digest, name
    args = [expected['revisions'][x] for x in ('baseline', 'candidate')]
    assert git(CAND, 'diff', '--name-only', *args).decode().splitlines() == expected['changed_files']
    assert hashlib.sha256(git(CAND, 'diff', '--binary', '--full-index', *args)).hexdigest() == expected['diff_sha256']
    for path, digest in read(ROOT / 'input-pins.json').items():
        assert sha(path) == digest, path
    assert sha(BANK) == BANK_SHA
    return {'manifest_sha256': sha(ROOT / 'manifest.json'),
            'source_pins_sha256': sha(ROOT / 'source-pins.json'),
            'staging_sha256': sha(ROOT / 'source-staging.json')}


def verified_run(folder, role):
    name, source, scheme, revision = role
    expected = read(ROOT / 'source-pins.json')
    receipt, runtime = read(folder / 'receipt.json'), read(folder / 'runtime.json')
    assert receipt['state'] == runtime['state'] == 'complete'
    assert receipt['returncode'] == 0 and receipt['scheme'] == scheme
    assert receipt['source'] == runtime['source'] == runtime['imported_source'] == str(source)
    assert receipt['source_info'] == {'commit': expected['revisions'][revision], 'status': '', 'tracked_diff': ''}
    assert receipt['source_status_after'] == ''
    assert receipt['input_sha256'] == receipt['input_sha256_after']
    for path, digest in receipt['input_sha256'].items():
        assert sha(path) == digest, path
    assert receipt['trigger_sha256'] == sha(folder / 'triggers.hdf')
    assert receipt['runtime_sha256'] == sha(folder / 'runtime.json')
    assert runtime['helper_sha256'] == sha(ROOT / 'checked-inspiral.py')
    assert runtime['processing_scheme'] == scheme
    checker = module('runtime_checker', 'checked-inspiral.py')
    environment = checker.fixed_environment(read(ROOT / 'config.json'), source)
    assert receipt['environment'] == runtime['environment'] == environment
    for stage in ('before_executable', 'at_first_bank', 'after_executable'):
        checker.check(runtime[stage], environment, bank=stage == 'at_first_bank', scheme=scheme)
    native = read(ROOT / 'source-staging.json')['native_sha256']
    for path, digest in runtime['source_modules'].items():
        relative = str(Path(path).relative_to(source))
        assert sha(path) == digest
        if path.endswith('.so'):
            assert native[relative] == digest
    return receipt


def qualified_science(folder, role, controls):
    import numpy as np
    verified_run(folder, role)
    result = controls.qualify(folder / 'qualification.json', 384, BANK_SHA)
    assert result['segments'] == 5
    obs = read(folder / 'qualification.json')['observations']
    assert len(obs['conditioned_strain']) == 1 and obs['psd_arrays']
    psds = []
    for record in obs['psd_arrays']:
        path = folder / record['relative_path']
        assert path.resolve() == Path(record['path']).resolve()
        assert sha(path) == record['sha256'] and path.stat().st_size == record['bytes']
        values = np.load(path, allow_pickle=False)
        assert list(values.shape) == record['shape']
        assert values.dtype.str == record['dtype_str'] and values.nbytes == record['nbytes']
        assert hashlib.sha256(memoryview(values).cast('B')).hexdigest() == record['data_sha256']
        assert record['validity']['valid_for_filter']
        psds.append({k: v for k, v in record.items() if k != 'path'})
    engines = [row for row in obs['fft_engines'] if row['kind'] == 'IFFT']
    assert len(engines) == 1
    engine = engines[0]
    assert engine['size'] == 2097152 and engine['nbatch'] == 1
    assert engine['execute_attempts'] == engine['execute_successes'] == 1920
    if role[2] == 'torch:cpu:1':
        assert engine['class'] == 'pycbc.fft.torchfft.IFFT'
        assert engine['executed_routes'] == {'pycbc.fft.torchfft._execute_mkl_cpu_ifft_plan': 1920}
        assert engine['plans_after_execution']['_mkl_plan'] == 'pycbc.fft.torchfft._MKLCPUDirectIFFTPlan'
    return result, {'conditioned_strain': obs['conditioned_strain'], 'psd_arrays': psds,
                    'segment_geometry': obs['segment_geometry']}


def compare_runs(name, base_folder, base_role, candidate_folder, candidate_role, comparator):
    verified_run(base_folder, base_role)
    verified_run(candidate_folder, candidate_role)
    base = comparator.load(base_folder / 'triggers.hdf')
    candidate = comparator.load(candidate_folder / 'triggers.hdf')
    raw = comparator.compare(base, candidate, comparator.DEFAULTS)
    # Preserve the strict comparator's outcome before explicit source attribution.
    save(ROOT / (name + '-raw.json'), raw)
    fixed = copy.deepcopy(candidate)
    substitutions = []
    for key in ('source_snapshot', 'consumed_input_sha256'):
        if base['metadata'][key] == candidate['metadata'][key]:
            continue
        before = copy.deepcopy(candidate['metadata'][key])
        if key == 'source_snapshot':
            assert before['status'] == before['tracked_diff'] == ''
            fixed['metadata'][key] = copy.deepcopy(base['metadata'][key])
        else:
            old = str(candidate_role[1] / 'bin/pycbc_inspiral')
            new = str(base_role[1] / 'bin/pycbc_inspiral')
            assert old != new and before[old] == base['metadata'][key][new]
            fixed['metadata'][key][new] = fixed['metadata'][key].pop(old)
            assert fixed['metadata'][key] == base['metadata'][key]
        substitutions.append({'field': key, 'before': before, 'after': fixed['metadata'][key]})
    result = comparator.compare(base, fixed, comparator.DEFAULTS)
    exact = None
    if base_role[2] == candidate_role[2]:
        import h5py
        import numpy as np
        exact = {}
        with h5py.File(base_folder / 'triggers.hdf', 'r') as a, h5py.File(candidate_folder / 'triggers.hdf', 'r') as b:
            datasets = []
            for handle in (a, b):
                paths = {}
                handle['H1'].visititems(lambda key, value: paths.update({key: value})
                                       if isinstance(value, h5py.Dataset) else None)
                datasets.append(paths)
            assert sorted(datasets[0]) == sorted(datasets[1])
            telemetry = {'search/run_time', 'search/filter_rate_per_core',
                         'search/setup_time_fraction', 'search/templates_per_core'}
            assert telemetry.issubset(datasets[0])
            assert len([key for key in datasets[0] if '/' not in key]) == 13
            for key in sorted(set(datasets[0]) - telemetry):
                av, bv = datasets[0][key][()], datasets[1][key][()]
                assert av.dtype == bv.dtype and av.shape == bv.shape
                assert np.array_equal(av, bv), key
                digest = hashlib.sha256(av.tobytes()).hexdigest()
                assert digest == hashlib.sha256(bv.tobytes()).hexdigest(), key
                exact[key] = {'shape': list(av.shape), 'dtype': av.dtype.str, 'data_sha256': digest}
    save(ROOT / (name + '-verified.json'), {'raw_report': name + '-raw.json',
         'same_scheme_exact_H1': exact,
         'source_pins_sha256': sha(ROOT / 'source-pins.json'), 'substitutions': substitutions,
         'tolerances': comparator.DEFAULTS, 'result': result})
    assert result['status'] == 'pass', (name, result)
    return {'raw': raw['status'], 'verified': result['status'],
            'raw_sha256': sha(ROOT / (name + '-raw.json')),
            'verified_sha256': sha(ROOT / (name + '-verified.json'))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('qualify', 'timing'), required=True)
    parser.add_argument('--run', required=True)
    args = parser.parse_args()
    assert Path(args.run).name == args.run
    status_path = ROOT / (args.run + '-status.json')
    assert not status_path.exists()
    os.environ.update(read(ROOT / 'config.json')['environment'])
    os.sched_setaffinity(0, {8})
    status = {'phase': args.phase, 'state': 'starting', 'pid': os.getpid(),
              'pgid': os.getpgrp(), 'start_ticks': Path('/proc/self/stat').read_text().split()[21],
              'started_epoch': time.time(), 'workers': [], 'comparisons': {}}
    save(status_path, status)
    with LOCK.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        frozen = pins()
        tests = read(ROOT / 'native-tests-status.json')
        test_audit = read(ROOT / 'native-tests-terminal-audit.json')
        assert tests['state'] == 'complete'
        assert test_audit['status_sha256'] == sha(ROOT / 'native-tests-status.json')
        assert test_audit['whole_process_group_absent'] and test_audit['lock_reacquired']
        for name, digest in tests['artifacts'].items():
            assert sha(ROOT / name) == digest
        assert tests['revisions'] == read(ROOT / 'source-pins.json')['revisions']
        assert tests['staging_sha256'] == sha(ROOT / 'source-staging.json')
        semantics = read(ROOT / 'frame-semantics.json')
        assert semantics['state'] == 'complete' and len(semantics['reads']) == 28
        assert len(semantics['stream_positions']) == 8
        assert semantics['sources'] == read(ROOT / 'source-staging.json')['sources']
        controls = module('controls', 'campaign_controls.py')
        comparator = module('comparator', 'compare-triggers.py')
        status.update(state='running', pins=frozen)

        def check():
            assert pins() == frozen

        def run_case(name, role, mode):
            check()
            command = [sys.executable, str(ROOT / 'run-case.py'), '--config', str(ROOT / 'config.json'),
                       '--case', name, '--mode', mode, '--scheme', role[2], '--source', str(role[1]),
                       '--bank', str(BANK), '--segment-length', '512', '--start-pad', '112', '--end-pad', '16']
            log = ROOT / (name + '.log')
            record = {'name': name, 'command': command, 'cwd': str(ROOT), 'log': str(log),
                      'started_epoch': time.time()}
            env = dict(os.environ, PYCBC_BENCHMARK_LOCK_FD=str(lock.fileno()))
            with log.open('x') as output:
                child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                         stdout=output, stderr=subprocess.STDOUT, pass_fds=(lock.fileno(),))
                record.update(pid=child.pid, pgid=os.getpgid(child.pid),
                              start_ticks=Path(f'/proc/{child.pid}/stat').read_text().split()[21])
                status['workers'].append(record)
                save(status_path, status)
                try:
                    record['exit'] = child.wait(timeout=3600)
                except subprocess.TimeoutExpired:
                    status.update(state='failed', error='worker timeout; terminating entire process group')
                    save(status_path, status)
                    os.killpg(os.getpgrp(), signal.SIGTERM)
                    raise
            record.update(finished_epoch=time.time(), log_sha256=sha(log))
            save(status_path, status)
            assert record['exit'] == 0, record
            check()
            folder = ROOT / 'runs' / name
            verified_run(folder, role)
            return folder

        try:
            qualifications, science = {}, {}
            if args.phase == 'qualify':
                for role in ROLES:
                    folder = run_case('qual-' + role[0], role, 'qualify')
                    qualifications[role[0]], science[role[0]] = qualified_science(folder, role, controls)
                    save(ROOT / 'qualifications.json', qualifications)
                    save(ROOT / 'science.json', science)
                    assert science[role[0]] == read(ROOT / 'science-reference.json')['by_scheme'][role[2]], role[0]
                    if role[0].endswith('-candidate'):
                        baseline_name = role[0].replace('-candidate', '-baseline')
                        assert science[role[0]] == science[baseline_name], role[0]
                        baseline_role = next(r for r in ROLES if r[0] == baseline_name)
                        key = 'qualification-' + role[0] + '-vs-own-baseline'
                        status['comparisons'][key] = compare_runs(key, ROOT / 'runs' / ('qual-' + baseline_name), baseline_role, folder, role, comparator)
                    if role[0] != 'standard-baseline':
                        key = 'qualification-' + role[0]
                        status['comparisons'][key] = compare_runs(key, ROOT / 'runs/qual-standard-baseline', ROLES[0], folder, role, comparator)
                    save(status_path, status)
            else:
                prerequisite = read(ROOT / 'qualification-v1-status.json')
                audit = read(ROOT / 'qualification-v1-terminal-audit.json')
                assert prerequisite['state'] == 'complete' and prerequisite['pins'] == frozen
                assert audit['status_sha256'] == sha(ROOT / 'qualification-v1-status.json')
                assert audit['whole_process_group_absent'] and audit['lock_reacquired']
                for role in ROLES:
                    qualifications[role[0]], science[role[0]] = qualified_science(ROOT / 'runs' / ('qual-' + role[0]), role, controls)
                    assert science[role[0]] == read(ROOT / 'science-reference.json')['by_scheme'][role[2]], role[0]
                    if role[0].endswith('-candidate'):
                        assert science[role[0]] == science[role[0].replace('-candidate', '-baseline')], role[0]
                samples = {role[0]: [] for role in ROLES}
                for repeat, order in enumerate((ROLES, list(reversed(ROLES)), ROLES), 1):
                    for role in order:
                        name = f'timing-{repeat}-{role[0]}'
                        folder = run_case(name, role, 'timing')
                        for label, base_folder, base_role in [
                            ('standard', ROOT / 'runs/qual-standard-baseline', ROLES[0]),
                            ('own', ROOT / 'runs' / ('qual-' + role[0]), role)]:
                            key = name + '-vs-' + label
                            status['comparisons'][key] = compare_runs(key, base_folder, base_role, folder, role, comparator)
                        metric = controls.timing(folder, 384, read(ROOT / 'source-pins.json')['revisions'][role[3]], BANK_SHA, qualifications[role[0]])
                        samples[role[0]].append(metric)
                        save(ROOT / 'samples.json', samples)
                        save(status_path, status)
            check()
            status['state'] = 'complete'
        except BaseException as error:
            status.update(state='failed', error=repr(error))
            raise
        finally:
            status['finished_epoch'] = time.time()
            save(status_path, status)


if __name__ == '__main__':
    main()
