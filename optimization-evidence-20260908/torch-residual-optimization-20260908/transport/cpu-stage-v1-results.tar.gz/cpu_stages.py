"""Measure stages of the unchanged, qualified 2M promoted in-place CPU IFFT."""
import argparse
from datetime import datetime, timezone
import gc
import json
import os
from pathlib import Path
import platform
import statistics
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--rotation', required=True, type=int, choices=range(3))
args = parser.parse_args()
source = args.source.resolve(strict=True)
sys.path.insert(0, str(source))
sys.path.insert(1, str(Path(__file__).resolve().parent))

import qualify_runtime as q
from pycbc.fft import mkl

assert source == Path(q.pycbc.__file__).resolve().parent.parent
assert not args.output.exists()
assert not args.output.with_suffix('.tmp').exists()
assert sorted(os.sched_getaffinity(0)) == [8]
q.torch.set_num_threads(1)
q.fftw.set_measure_level(0)
args.size = 2**21
args.route = 'accepted_mkl_promoted'
args.seeds = q.SEEDS


def summary(values):
    return {'samples_seconds': values, 'median_seconds': statistics.median(values),
            'range_seconds': [min(values), max(values)]}


record = {
    'schema': 'cpu-current-plan-stages-v1', 'state': 'running',
    'pid': os.getpid(), 'pgid': os.getpgrp(), 'cwd': os.getcwd(),
    'start_ticks': Path('/proc/self/stat').read_text().split()[21],
    'host': platform.node(), 'command': sys.argv,
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'source_state': q.state(source), 'helper_sha256': q.sha(__file__),
    'qualification_helper_sha256': q.sha(q.__file__),
    'libraries': {
        'mkl': q.library_identity(mkl.lib.DftiComputeBackward),
        'fftw_float': q.library_identity(q.fftw.float_lib.fftwf_execute_dft),
        'fftw_double': q.library_identity(q.fftw.double_lib.fftw_execute_dft),
    },
    'versions': {'python': sys.version, 'numpy': q.np.__version__, 'torch': q.torch.__version__},
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'environment': {key: os.environ.get(key) for key in (
        'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
        'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS',
        'MKL_DYNAMIC', 'MKL_THREADING_LAYER', 'PYTHONHASHSEED', 'PYTHONPATH',
        'LD_PRELOAD', 'LD_LIBRARY_PATH')},
    'policy': 'Source unchanged; frozen 36-case L2/max-absolute FFTW budgets and '
              'bitwise complex128 MKL parity before and after timing. '
              'Stages include timer boundaries; no timer subtraction. '
              'Microbenchmark attribution only; no executable speedup claim.',
    'qualification': {}, 'blocks': [],
}

candidate = None
try:
    assert record['source_state']['head'] == 'ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f'
    assert not record['source_state']['source_status']
    assert record['source_state']['torchfft_sha256'] == '0b9109bbf99a4eb591a4c006b1220ec36c8587e56352352277eb1478cf876c0c'
    candidate = q.Route(args.route, args.size)
    record['runtime_identity'] = q.runtime_identity(candidate)
    owner = candidate.owner
    engine_execute = candidate.engine.execute
    source_tensor, target_tensor = candidate.source, candidate.target
    stage_samples = None

    def plan_execute():
        owner.execute(source_tensor, target_tensor)

    def stages_execute():
        # Match _MKLCPUDirectIFFTPlan.execute for this exact promoted/in-place
        # plan, retaining pointer lookups and the version/status bookkeeping.
        t0 = time.perf_counter_ns()
        owner._native_source.copy_(source_tensor)
        t1 = time.perf_counter_ns()
        status = owner._execute(owner._descriptor, owner._native_source.data_ptr())
        t2 = time.perf_counter_ns()
        owner._increment_version(owner._native_target)
        owner._check_status(status)
        t3 = time.perf_counter_ns()
        target_tensor.copy_(owner._native_target)
        t4 = time.perf_counter_ns()
        if stage_samples is not None:
            stage_samples.append([t1-t0, t2-t1, t3-t2, t4-t3, t4-t0])

    def qualify(name, execute):
        candidate.execute = execute
        cases = q.validate_plan(args, candidate)
        expected = [(s, p, v) for s in q.SEEDS for p in q.PATTERNS for v in q.SCALES]
        assert [(c['seed'], c['pattern'], c['scale']) for c in cases] == expected
        record['qualification'][name] = cases
        assert all(c['passed'] and c['bitwise_matching_precision_mkl'] for c in cases)
        print(name, '36 cases passed', flush=True)

    qualify('engine_before', engine_execute)
    qualify('stages_before', stages_execute)
    values = q.values_for(args.size, q.SEEDS[0], 'dense', 1.0)
    candidate.assign(values)
    candidate.check()
    executions = {'engine': engine_execute, 'plan': plan_execute, 'stages': stages_execute}
    names = list(executions)
    # Every fresh process uses all three cyclic block orders, beginning at a
    # different rotation. Each block warms its exact path before 15 samples.
    gc.collect()
    gc.disable()
    for block in range(3):
        offset = (block + args.rotation) % 3
        for name in names[offset:] + names[:offset]:
            execute = executions[name]
            for _ in range(3):
                execute()
            stage_samples = [] if name == 'stages' else None
            whole_samples = []
            for _ in range(15):
                start = time.perf_counter_ns()
                execute()
                whole_samples.append((time.perf_counter_ns() - start) / 1e9)
            row = {'block': block, 'path': name, 'warmups': 3,
                   'whole_call': summary(whole_samples)}
            if stage_samples is not None:
                row['stages'] = {
                    label: summary([sample[i] / 1e9 for sample in stage_samples])
                    for i, label in enumerate(('promotion', 'native_fft', 'bookkeeping',
                                               'demotion', 'sum'))
                }
                assert all(sum(sample[:4]) == sample[4] for sample in stage_samples)
                row['outside_stages'] = summary([
                    full - sample[4] / 1e9
                    for full, sample in zip(whole_samples, stage_samples)
                ])
            stage_samples = None
            record['blocks'].append(row)
            candidate.check()
            q.np.testing.assert_array_equal(candidate.source_buffer.view(q.np.uint32),
                                           values.view(q.np.uint32))
    gc.enable()
    # Five consecutive reads reproduce the stage timer count without work.
    controls = []
    for _ in range(1000):
        t0 = time.perf_counter_ns()
        t1 = time.perf_counter_ns()
        t2 = time.perf_counter_ns()
        t3 = time.perf_counter_ns()
        t4 = time.perf_counter_ns()
        controls.append((t4 - t0) / 1e9)
    record['timer_control'] = summary(controls)
    qualify('stages_after', stages_execute)
    qualify('engine_after', engine_execute)
    assert q.runtime_identity(candidate) == record['runtime_identity']
    assert q.state(source) == record['source_state']
    record['all_144_precision_cases_passed'] = True
    record['state'] = 'complete'
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    gc.enable()
    if candidate is not None:
        candidate.close()
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    temporary = args.output.with_suffix('.tmp')
    temporary.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
    temporary.replace(args.output)
