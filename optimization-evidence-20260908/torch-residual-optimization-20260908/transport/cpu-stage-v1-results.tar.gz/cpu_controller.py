"""Run three fresh serial CPU stage diagnostics under the campaign lock."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/xangma/pycbc-torch-fft-optimization-20260908/loader-v1/source-candidate')
PYTHON = '/home/xangma/pycbc-torch-split-20260905/venv/bin/python'
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
STATUS = ROOT / 'cpu-status.json'
assert not STATUS.exists()
ENV = {key: os.environ[key] for key in ('HOME', 'USER', 'LOGNAME', 'PATH', 'LANG') if key in os.environ}
ENV.update({key: '1' for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS',
    'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS')})
ENV.update(MKL_DYNAMIC='FALSE', MKL_THREADING_LAYER='GNU', PYTHONHASHSEED='0',
           PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pins():
    for name, expected in json.loads((ROOT / 'transfer_manifest.json').read_text()).items():
        assert sha(ROOT / name) == expected, name
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD']).decode().strip() == 'ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f'
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'])
    source_files = json.loads((ROOT / 'source-pins.json').read_text())
    for name, expected in source_files.items():
        assert sha(SOURCE / name) == expected, name
    return {'manifest_sha256': sha(ROOT / 'transfer_manifest.json'),
            'source_pins_sha256': sha(ROOT / 'source-pins.json'),
            'controller_sha256': sha(Path(__file__))}


def save():
    temporary = STATUS.with_suffix('.tmp')
    temporary.write_text(json.dumps(status, indent=2) + '\n')
    temporary.replace(STATUS)


status = {'state': 'starting', 'pid': os.getpid(), 'pgid': os.getpgrp(),
          'start_ticks': Path('/proc/self/stat').read_text().split()[21],
          'started_epoch': time.time(), 'workers': [], 'environment': ENV}
save()
try:
    os.sched_setaffinity(0, {8})
    with LOCK.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        frozen = pins()
        status.update(state='running', pins=frozen)
        save()
        for rotation in range(3):
            assert pins() == frozen
            name = f'cpu-stages-{rotation+1}'
            command = [PYTHON, str(ROOT / 'worker_receipt.py'), '--source', str(SOURCE),
                       '--receipt', str(ROOT / (name + '-receipt.json')),
                       '--helper', str(ROOT / 'cpu_stages.py'), '--', '--source', str(SOURCE),
                       '--output', str(ROOT / (name + '.json')), '--rotation', str(rotation)]
            log = ROOT / (name + '.log')
            worker = {'name': name, 'command': command, 'cwd': str(SOURCE),
                      'log': str(log), 'started_epoch': time.time()}
            with log.open('x') as handle:
                process = subprocess.Popen(command, cwd=SOURCE, env=ENV,
                    stdin=subprocess.DEVNULL, stdout=handle, stderr=subprocess.STDOUT,
                    pass_fds=(lock.fileno(),))
                worker.update(pid=process.pid, pgid=os.getpgid(process.pid),
                              start_ticks=Path(f'/proc/{process.pid}/stat').read_text().split()[21])
                status['workers'].append(worker)
                save()
                worker['exit'] = process.wait()
            worker.update(finished_epoch=time.time(), log_sha256=sha(log))
            save()
            assert worker['exit'] == 0, worker
            assert pins() == frozen
            result = json.loads((ROOT / (name + '.json')).read_text())
            receipt = json.loads((ROOT / (name + '-receipt.json')).read_text())
            assert result['state'] == receipt['state'] == 'complete'
            assert result['all_144_precision_cases_passed']
        status['state'] = 'complete'
except BaseException as error:
    status.update(state='failed', error=repr(error))
    raise
finally:
    status['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
