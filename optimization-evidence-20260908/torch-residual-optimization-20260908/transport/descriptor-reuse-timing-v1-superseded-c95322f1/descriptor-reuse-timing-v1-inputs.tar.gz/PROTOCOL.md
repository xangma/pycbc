# Descriptor reuse timing v1

## Scope and prior evidence

Artifact-only fast Python wrapper on the qualified clean ecd5d08231d8ce0a938bc31cfde27c9a5d6f901f source. No production edits, C/CUDA/native symbol replacement, integration or publication. The frozen instrumented qualification passed native and both-scheme science gates, with independent replay ca074bc81beb3eb807802bde1b1327e6545b2fb05c26b038b6f7d5b56731d71a. Its durations are not performance evidence.

## Exact helper and fairness

`descriptor_reuse.py` subclasses byte-identical frozen `descriptor_reuse_diagnostic.py`. Unchanged inherited code owns the inverse-verified original MKL AST clones, PID/current-thread ownership, native identities, free lifecycle, install/close/restore/finish. The fast overrides remove per-call rows, pointer histories, public-key formatting, signature recording and per-call native-invariant sweeps. Native identity checks remain at construction, install and final boundaries. Every call retains owner, complete key, reentry, capacity and eligible/fallback checks. No per-call clock, profiler, stack capture or hit counter is introduced. Only owned-descriptor lifecycle/error records remain. Successful cached execution owns at most three descriptors.

Full key: direction, exact input/output lengths and canonical dtypes, precision/kind tokens, maximum length, actual placement, concrete scheme class, device/device_num/device_spec/torch_device values, scheme threads, PID and owning thread object. Eligibility remains single-thread CPU-scheme out-of-place float32 real-to-complex64 16384->8193 and 16777216->8388609, and the inverse large pair. Unsupported or fourth-distinct configurations invoke exact original functions. No arrays are retained or exported.

Original creation/set/commit/compute argument signatures and order remain unchanged. Original ignored commit return values remain ignored: creates means original creator returned after commit invocation. Failed/nonzero/null/sentinel/ambiguous allocations deliberately fail closed before setup and do not claim ownership. Confirmed later failures free once; uncertain frees poison without retry. Primary workload errors survive cleanup and boundary errors. Removing hot invariant sweeps deliberately delays detection of native-symbol tampering until a boundary; no native monkey patching or concurrent callers are permitted in this experiment.

Both baseline and candidate import and construct the identical Fast cache at the same point in `run_reuse.py`, including early MKL import and AST construction. Baseline (`--reuse no`) never installs: it calls exact original FFT functions and closes the empty object, checking original-function/native identities at exit. Candidate (`--reuse yes`) installs and finally closes/restores. Each run receipt binds fast helper, diagnostic parent, runner and source hashes. Full child wall includes interpreter startup, imports/cache setup, workload, final frees/restoration, receipts/runtime checks and process exit. Internal inspiral/setup telemetry is secondary.

## Gates before measured children

One controller holds the exclusive inherited benchmark lock throughout. Before any timing it runs a fresh real-MKL gate, then four fresh science qualifications in cell order A,B,C,D. Native gate checks nine cases, three simultaneously retained allocation pairs per eligible configuration, 18 distinct pointers, full output bytes equal to original MKL and preserved input. It externally observes three misses/six hits and coexisting class FFT and promoted complex128-workspace Torch in-place two-argument MKL IFFT plan behavior after every call and cache closure. External hit observations exist only in this gate. Both plans are explicitly released.

Each fast baseline/candidate standard/CUDA qualification retains prior 384-template compressed-bank, 512-second segment/112+16-pad geometry, five segments, 1904 valid seconds, 1920 IFFT calls, PSD files/data and conditioned-strain identity gates. Each matches its exact frozen own-scheme reference. Cached versus original passes all 18 H1 scientific datasets byte-for-byte within scheme; standard/CUDA default comparison also passes. Pin changes or any failure stop the controller before timings.

## Prespecified timing schedule and comparisons

A=standard-original (`cpu:1`); B=standard-cached (`cpu:1`); C=cuda-original (`torch:cuda:0`); D=cuda-cached (`torch:cuda:0`). Four fresh serial subprocess repeats, retaining every run:

1. A, B, D, C
2. B, C, A, D
3. C, D, B, A
4. D, A, C, B

Each cell appears once in each position; each within-scheme cached/original pair runs in each direction twice. No warmup runs or adaptive resampling. The native/science gates naturally precede timing, so filesystem/library caches may already be warm; no cold-cache claim.

Timed mode is `timing`, preserving the established metrics validator. Timed children use the same fast runner but invoke the executable directly without qualification/PSD/strain hooks. No descriptor-call instrumentation exists. Runtime checks remain unchanged, including exact helper provenance, source/modules, affinity core 8, native pools one, CUDA torch intra/inter-op one at the relevant boundaries. Standard runtime retains its original no-Torch reporting semantics. All source/input/native/reference pins are checked before and after each worker.

Every timed output passes exact own-qualification H1 comparison and the default comparator against updated standard-cached qualification. Each repeat additionally compares same-scheme cached/original contemporaneously and CUDA-cached against contemporaneous standard-cached. Work inferred from HDF timing metadata must match the qualified templates, segments and valid duration. The fast report confirms three owned descriptors freed once for candidate and an empty baseline object; no timed hit-count claim is made.

Report all raw full-wall samples, per-cell medians/ranges, paired cached-minus-original wall differences and cached/original ratios by repeat for both schemes; compare CUDA-cached against both contemporaneous standard-original and standard-cached, preserving the effect of common setup optimization. Report whole-process speedup as original/cached where used. Internal/setup and throughput telemetry remain secondary. Four samples support a bounded experiment, not a statistical significance claim or general workload guarantee. No Torch-CPU parity claim: this phase does not measure Torch CPU.

## Execution and closure

Host len; cwd `/home/xangma/pycbc-torch-residual-optimization-20260908/descriptor-reuse-timing-v1`. Launch via `/home/xangma/pycbc-torch-split-20260905/venv/bin/python manage.py launch`; command detaches the controller and records actual PID/PGID/start ticks/command/cwd/log in launch.json. Read-only checks use `manage.py status`; expected first check within 30 seconds and every 30-60 seconds while running. Approximate duration 15-20 minutes for native, four qualification and 16 full runs, plus gates. Stop only this recorded group with `kill -TERM -- -<recorded-pgid>` after matching start ticks. Per-worker timeout is 1800 seconds and stops the entire group.

Owner alone controls len and shared lock. After terminal state and zero whole-group members, `manage.py close` independently reacquires the lock, checks final immutable pins, seals audit/results manifest/archive. Acquire archive and independently replay raw outputs and timings locally before a result claim. Failed campaigns retain all artifacts and are never relabeled as successful runs.
