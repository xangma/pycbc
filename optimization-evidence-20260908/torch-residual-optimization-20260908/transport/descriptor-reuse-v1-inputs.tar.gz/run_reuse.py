"""Instrumented executable qualification for bounded descriptor reuse."""
import argparse
import json
from pathlib import Path
import runpy
import sys
import time

from descriptor_reuse import DescriptorReuse, sha


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--reuse', choices=('yes', 'no'), required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    assert command and not args.receipt.exists()
    from pycbc.fft import mkl
    cache = DescriptorReuse(mkl, reuse=args.reuse == 'yes')
    result = {'state': 'running', 'helper_sha256': sha(__file__),
              'cache_sha256': sha(Path(__file__).with_name('descriptor_reuse.py')),
              'mkl_source': str(Path(mkl.__file__).resolve()), 'mkl_source_sha256': sha(mkl.__file__),
              'purpose': 'Instrumented qualification only; no executable performance claim.',
              'commit_semantics': 'create_successes counts original creator returns after commit invocation. Original ignores commit return; no new status query or unrelated check added.',
              'started_epoch': time.time(), 'command': command}
    save(args.receipt, result)
    previous, primary = sys.argv, None
    try:
        cache.install()
        sys.argv = command
        try:
            runpy.run_path(command[0], run_name='__main__')
        except SystemExit as error:
            if error.code not in (0, None):
                raise
        assert cache.rows and all(row['state'] == 'complete' for row in cache.rows)
        assert all(row['native_status'] == 0 for row in cache.rows if row['eligible'])
        cache.assert_native()
    except BaseException as error:
        primary = error
        result.update(state='failed', error=repr(error))
        raise
    finally:
        sys.argv = previous
        try:
            cache.finish(primary_error=primary)
        except BaseException as error:
            result.update(state='failed', cleanup_error=repr(error))
            raise
        finally:
            result['cache'] = cache.report()
            if (primary is None and not cache.poisoned and cache.closed
                    and not cache.installed and not cache.cleanup_errors
                    and not cache.invariant_errors and not cache.finalization_errors):
                result['state'] = 'complete'
            else:
                result['state'] = 'failed'
            result['finished_epoch'] = time.time()
            save(args.receipt, result)
    if result['state'] != 'complete':
        raise RuntimeError('Descriptor qualification was incomplete')


if __name__ == '__main__':
    main()
