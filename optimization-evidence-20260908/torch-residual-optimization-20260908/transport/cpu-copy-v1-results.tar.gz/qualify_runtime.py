#!/usr/bin/env python3
"""Diagnostic FFT routes; never changes PyCBC dispatch or precision budgets.

Run qualification first, then fresh serial timing workers under the campaign
lock. A timing worker requires this route's successful qualification record.
No performance recommendation follows from this microbenchmark alone.
"""

import argparse
import ctypes
from datetime import datetime, timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time
import weakref

if __name__ == "__main__":
    bootstrap = argparse.ArgumentParser(add_help=False)
    bootstrap.add_argument("--source", required=True, type=Path)
    boot, _ = bootstrap.parse_known_args()
    sys.path.insert(0, str(boot.source.resolve(strict=True)))

import numpy as np
import torch

import pycbc
from pycbc import PYCBC_ALIGNMENT, scheme
from pycbc.fft import fftw, torchfft
from pycbc.types import Array, zeros
from pycbc.types.array_torch import TorchArrayData


ROUTES = (
    "legacy_mkl_single", "accepted_mkl_promoted", "mkl_promoted_inplace",
    "mkl_single_rejected_control", "fftw_single_direct", "fftw_single_retained",
    "fftw_single_retained_measure", "fftw_promoted_measure",
)
REFERENCE_ONLY = {"legacy_mkl_single", "mkl_single_rejected_control"}
SEEDS = (7, 91, 812, 20260906)
PATTERNS = ("dense", "banded", "impulse")
SCALES = (1e-12, 1.0, 1e12)


class InplaceMKLPlan(torchfft._MKLCPUDirectIFFTPlan):
    """Diagnostic variant retaining one private complex128 workspace."""

    def __init__(self, mkl, size, source, target):
        super().__init__(mkl, size, source, target, nthreads=1, promote=True)
        # Reconfigure only this descriptor. Keep the diagnostic distinct from
        # any eventual constructor change; record its extra commit as setup.
        mkl.check_status(mkl.lib.DftiSetValue(
            self._descriptor, mkl.DFTI_PLACEMENT, mkl.DFTI_INPLACE
        ))
        mkl.check_status(mkl.lib.DftiCommitDescriptor(self._descriptor))
        self._native_target = self._native_source
        # DftiComputeBackward is variadic. Bind a separate two-argument call
        # without changing the shared ctypes function used by out-of-place plans.
        self._library = mkl.lib
        address = ctypes.cast(mkl.lib.DftiComputeBackward, ctypes.c_void_p).value
        self._inplace_execute = ctypes.CFUNCTYPE(
            ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p
        )(address)

    def execute(self, source, target):
        self._native_source.copy_(source)
        status = self._inplace_execute(
            self._descriptor, self._native_source.data_ptr()
        )
        self._increment_version(self._native_source)
        self._check_status(status)
        target.copy_(self._native_source)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def state(source):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(source), *args])
    return {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "diff_sha256": hashlib.sha256(git("diff", "HEAD", "--binary")).hexdigest(),
        "torchfft_sha256": sha(torchfft.__file__),
        "helper_sha256": sha(__file__),
        "source_status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
        "python_sha256": {
            str(path.relative_to(source)): sha(path)
            for path in sorted((source / "pycbc").rglob("*.py"))
        },
        "native_sha256": {
            str(path.relative_to(source)): sha(path)
            for path in sorted((source / "pycbc").rglob("*.so"))
        },
    }


def library_identity(function):
    class DlInfo(ctypes.Structure):
        _fields_ = [("fname", ctypes.c_char_p), ("base", ctypes.c_void_p),
                    ("sname", ctypes.c_char_p), ("saddr", ctypes.c_void_p)]
    query = ctypes.CDLL(None).dladdr
    query.argtypes = [ctypes.c_void_p, ctypes.POINTER(DlInfo)]
    query.restype = ctypes.c_int
    info = DlInfo()
    if not query(ctypes.cast(function, ctypes.c_void_p), ctypes.byref(info)):
        raise RuntimeError("cannot resolve loaded FFT library")
    path = Path(os.fsdecode(info.fname)).resolve(strict=True)
    return {"path": str(path), "sha256": sha(path)}


class Route:
    def __init__(self, name, size):
        self.name, self.size = name, size
        self.close = lambda: None
        if name.startswith("legacy_"):
            if name == "legacy_fftw_single":
                backend = fftw
            else:
                from pycbc.fft import mkl
                backend = mkl
            with scheme.CPUScheme(num_threads=1):
                dtype = np.complex128 if name.endswith("double") else np.complex64
                self.source = zeros(size, dtype=dtype)
                self.target = zeros(size, dtype=dtype)
                self.owner = backend.IFFT(self.source, self.target)
                # Retain exact CPU storage across scheme changes.
                self.source_buffer = self.source.data
                self.target_buffer = self.target.data
            self.execute = self.owner.execute
            if name.startswith("legacy_mkl_"):
                def close():
                    mkl.check_status(mkl.lib.DftiFreeDescriptor(
                        ctypes.byref(self.owner.desc)
                    ))
                self.close = close
        else:
            self.source = torch.empty(size, dtype=torch.complex64)
            self.target = torch.empty_like(self.source)
            self.source_buffer = self.source.numpy()
            self.target_buffer = self.target.numpy()
            if name.startswith("fftw_single_"):
                aligned = all(
                    tensor.data_ptr() % PYCBC_ALIGNMENT == 0
                    for tensor in (self.source, self.target)
                )
                with fftw._FFTW_PLANNING_LOCK:
                    self.owner = torchfft._FFTWCPUDirectPlan(
                        fftw, size, False, self.source, self.target, aligned, 0
                    )
                if name.endswith("measure"):
                    # This is a diagnostic-only measured plan on private
                    # storage, without expanding any runtime dispatch gate.
                    self.owner._finalizer()
                    geometry = np.asarray([size], dtype=np.int32)
                    with fftw._FFTW_PLANNING_LOCK:
                        plan = fftw.plan_many_c2c_f(
                            1, geometry.ctypes.data, 1,
                            self.owner._scratch_input.ctypes.data,
                            geometry.ctypes.data, 1, size,
                            self.owner._scratch_output.ctypes.data,
                            geometry.ctypes.data, 1, size,
                            fftw.FFTW_BACKWARD, fftw.get_flag(1, aligned),
                        )
                    if not plan:
                        raise RuntimeError("FFTW returned a null measured plan")
                    self.owner._plan = plan
                    self.owner._measure_level = 1
                    self.owner._finalizer = weakref.finalize(
                        self.owner, torchfft._destroy_batch_plan_in_owner,
                        fftw, fftw.float_lib.fftwf_destroy_plan, plan, os.getpid(),
                    )
                self.owner._use_retained_workspace = "retained" in name
                if self.owner._use_retained_workspace:
                    self.owner._scratch_output_tensor = torch.from_numpy(
                        self.owner._scratch_output
                    )
            elif name == "fftw_promoted_measure":
                self.owner = torchfft._FFTWCPUWorkPlan(fftw, size, False, 1)
            else:
                from pycbc.fft import mkl
                if name == "accepted_mkl_promoted":
                    with scheme.TorchScheme("cpu"):
                        self.engine = torchfft.IFFT(
                            Array(TorchArrayData(self.source), copy=False),
                            Array(TorchArrayData(self.target), copy=False),
                        )
                    self.owner = self.engine._mkl_plan
                elif name == "mkl_promoted_inplace":
                    self.owner = InplaceMKLPlan(mkl, size, self.source, self.target)
                else:
                    self.owner = torchfft._MKLCPUDirectIFFTPlan(
                        mkl, size, self.source, self.target, nthreads=1,
                        promote=name != "mkl_single_rejected_control",
                    )
            self.execute = lambda: self.owner.execute(self.source, self.target)
            if hasattr(self, "engine"):
                self.execute = self.engine.execute
        torch.set_num_threads(1)
        self.pointers = (self.source_buffer.ctypes.data, self.target_buffer.ctypes.data)

    def assign(self, values):
        if isinstance(self.source, torch.Tensor):
            self.source.copy_(torch.from_numpy(values))
        else:
            self.source_buffer[:] = values

    def check(self):
        assert self.pointers == (
            self.source_buffer.ctypes.data, self.target_buffer.ctypes.data
        )
        if isinstance(self.source, torch.Tensor):
            assert self.owner.can_execute(self.source, self.target)
            assert self.source.data_ptr() == self.pointers[0]
            assert self.target.data_ptr() == self.pointers[1]
        else:
            assert self.source._data is self.source_buffer
            assert self.target._data is self.target_buffer
            assert self.owner.iptr == self.pointers[0]
            assert self.owner.optr == self.pointers[1]

    def checked_execute(self, values):
        self.assign(values)
        self.check()
        versions = None
        if isinstance(self.source, torch.Tensor):
            versions = self.source._version, self.target._version
        self.execute()
        self.check()
        expected_input = values.astype(self.source_buffer.dtype, copy=False)
        np.testing.assert_array_equal(self.source_buffer.view(np.uint32), expected_input.view(np.uint32))
        if versions is not None:
            assert self.source._version == versions[0]
            assert self.target._version == versions[1] + 1
        return self.target_buffer.copy()


def values_for(size, seed, pattern, scale):
    rng = np.random.default_rng(seed)
    values = (rng.normal(size=size) + 1j * rng.normal(size=size)).astype(np.complex64)
    if pattern == "banded":
        values[:size // 128] = 0
        values[size // 3:] = 0
    elif pattern == "impulse":
        values[:] = 0
        values[0], values[size // 8] = 2 - 3j, 0.5 + 0.25j
    values *= np.float32(scale)
    return values


def errors(actual, truth):
    difference = actual.astype(np.complex128) - truth
    return {"l2": float(np.linalg.norm(difference)),
            "max_abs": float(np.max(np.abs(difference)))}


def validate_plan(args, candidate):
    # Wisdom affects planner choices but not already constructed plans. Use
    # fresh fixed ESTIMATE references for every exact candidate plan, including
    # the plan retained by a fresh timing worker after its samples are recorded.
    with fftw._FFTW_PLANNING_LOCK:
        fftw.float_lib.fftwf_forget_wisdom()
        fftw.double_lib.fftw_forget_wisdom()
    reference = Route("legacy_fftw_single", args.size)
    parity = None
    if args.route in {"accepted_mkl_promoted", "mkl_promoted_inplace"}:
        parity = Route("legacy_mkl_double", args.size)
    elif args.route == "mkl_single_rejected_control":
        parity = Route("legacy_mkl_single", args.size)
    cases = []
    try:
        for seed in args.seeds:
            for pattern in PATTERNS:
                for scale in SCALES:
                    values = values_for(args.size, seed, pattern, scale)
                    truth = np.fft.ifft(values.astype(np.complex128)) * args.size
                    baseline = reference.checked_execute(values)
                    actual = candidate.checked_execute(values)
                    ref_error, error = errors(baseline, truth), errors(actual, truth)
                    case = {
                        "seed": seed, "pattern": pattern, "scale": scale,
                        "reference": ref_error, "candidate": error,
                        "bitwise_legacy_fftw": np.array_equal(actual.view(np.uint32), baseline.view(np.uint32)),
                        "passed": all(error[key] <= ref_error[key] for key in error),
                    }
                    if parity is not None:
                        parity_output = parity.checked_execute(values).astype(np.complex64)
                        case["bitwise_matching_precision_mkl"] = np.array_equal(
                            actual.view(np.uint32), parity_output.view(np.uint32)
                        )
                        case["passed"] &= case["bitwise_matching_precision_mkl"]
                    cases.append(case)
                print(seed, pattern, "qualified", flush=True)
        return cases
    finally:
        reference.close()
        if parity is not None:
            parity.close()


def runtime_identity(candidate):
    owner = candidate.owner
    assert type(candidate.engine) is torchfft.IFFT
    assert type(owner) is torchfft._MKLCPUDirectIFFTPlan
    assert owner._inplace and owner._promote
    assert owner._size == 2097152 and owner._nthreads == 1
    assert owner._native_source is owner._native_target
    assert owner._native_source.dtype == torch.complex128
    assert owner._execute.argtypes == (ctypes.c_void_p, ctypes.c_void_p)
    assert owner._native_source.data_ptr() not in candidate.pointers
    return {"engine_class": type(candidate.engine).__qualname__,
            "plan_class": type(owner).__qualname__, "inplace": owner._inplace,
            "promote": owner._promote, "size": owner._size, "threads": owner._nthreads,
            "private_source_pointer": owner._native_source.data_ptr(),
            "private_target_pointer": owner._native_target.data_ptr(),
            "execution_argument_count": len(owner._execute.argtypes),
            "public_source_pointer": candidate.pointers[0],
            "public_target_pointer": candidate.pointers[1]}


def qualify(args, record):
    candidate = Route(args.route, args.size)
    try:
        record["runtime_identity"] = runtime_identity(candidate)
        record["cases"] = validate_plan(args, candidate)
        record["all_precision_cases_passed"] = all(c["passed"] for c in record["cases"])
    finally:
        candidate.close()


def require_qualification(qualification, record):
    for key in ("source_state", "route", "size", "host", "versions", "environment", "cpu_affinity", "libraries"):
        if qualification[key] != record[key]:
            raise ValueError(f"qualification mismatch: {key}")
    expected = [(seed, pattern, scale) for seed in SEEDS for pattern in PATTERNS for scale in SCALES]
    actual = [(c["seed"], c["pattern"], c["scale"]) for c in qualification.get("cases", [])]
    if qualification.get("mode") != "qualify" or actual != expected:
        raise ValueError("qualification must contain the exact complete 36-case matrix")
    if qualification["state"] != "complete" or (
        record["route"] not in REFERENCE_ONLY
        and not all(c["passed"] for c in qualification["cases"])
    ):
        raise ValueError("route must pass precision qualification before timing")


def timing(args, record):
    qualification = json.loads(args.qualification.read_text())
    require_qualification(qualification, record)
    record["qualification_sha256"] = sha(args.qualification)
    values = values_for(args.size, args.seeds[0], "dense", 1.0)
    started = time.perf_counter()
    candidate = Route(args.route, args.size)
    record["construction_seconds"] = time.perf_counter() - started
    try:
        record["runtime_identity"] = runtime_identity(candidate)
        candidate.assign(values)
        candidate.check()
        started = time.perf_counter()
        candidate.execute()
        record["first_seconds"] = time.perf_counter() - started
        for _ in range(3):
            candidate.execute()
        samples = []
        for _ in range(args.repeats):
            started = time.perf_counter()
            candidate.execute()
            samples.append(time.perf_counter() - started)
        record["samples_seconds"] = samples
        record["median_seconds"] = statistics.median(samples)
        record["warmup_executions"] = 3
        candidate.check()
        np.testing.assert_array_equal(candidate.source_buffer.view(np.uint32), values.view(np.uint32))
        record["timed_plan_cases"] = validate_plan(args, candidate)
        record["timed_plan_all_precision_cases_passed"] = all(c["passed"] for c in record["timed_plan_cases"])
        record["eligible_candidate_timing"] = (
            args.route not in REFERENCE_ONLY
            and record["timed_plan_all_precision_cases_passed"]
        )
    finally:
        candidate.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--route", required=True, choices=ROUTES)
    parser.add_argument("--mode", required=True, choices=("qualify", "timing"))
    parser.add_argument("--qualification", type=Path)
    parser.add_argument("--size", type=int, default=2**21)
    parser.add_argument("--seeds", type=int, nargs="+", default=list(SEEDS))
    parser.add_argument("--repeats", type=int, default=15)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    if source != Path(pycbc.__file__).resolve().parent.parent:
        parser.error("imported PyCBC differs from --source")
    if args.output.exists() or args.output.with_suffix(".tmp").exists():
        parser.error("preserve existing output; choose a new path")
    if args.size < 128 or args.repeats < 3:
        parser.error("size >= 128 and repeats >= 3 required")
    if args.mode == "timing" and args.qualification is None:
        parser.error("timing requires --qualification")
    if args.mode == "timing" and tuple(args.seeds) != SEEDS:
        parser.error("timing requires the complete frozen seed matrix")
    torch.set_num_threads(1)
    fftw.set_measure_level(0)
    libraries = {
        "fftw_float": library_identity(fftw.float_lib.fftwf_execute_dft),
        "fftw_double": library_identity(fftw.double_lib.fftw_execute_dft),
    }
    if "mkl" in args.route:
        from pycbc.fft import mkl
        libraries["mkl"] = library_identity(mkl.lib.DftiComputeBackward)
    record = {
        "schema": "torch-ifft-routes-20260908-v1", "state": "running",
        "mode": args.mode, "route": args.route, "size": args.size,
        "reference_only": args.route in REFERENCE_ONLY,
        "libraries": libraries,
        "source_state": state(source), "host": platform.node(),
        "pid": os.getpid(), "pgid": os.getpgid(0), "cwd": os.getcwd(),
        "command": sys.argv, "started_utc": datetime.now(timezone.utc).isoformat(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "environment": {k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "MKL_DYNAMIC", "MKL_THREADING_LAYER", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "PYTHONHASHSEED")},
        "versions": {"python": sys.version, "numpy": np.__version__, "torch": torch.__version__},
        "policy": "complex128 NumPy truth; candidate L2 and maximum error each <= legacy FFTW; no tolerance floor; no runtime dispatch changes",
    }
    try:
        if args.mode == "qualify":
            qualify(args, record)
        else:
            timing(args, record)
        gc.collect()
        if state(source) != record["source_state"]:
            raise RuntimeError("source changed during diagnostic")
        record["state"] = "complete"
    except BaseException as error:
        record["state"], record["error"] = "failed", repr(error)
        raise
    finally:
        record["finished_utc"] = datetime.now(timezone.utc).isoformat()
        temporary = args.output.with_suffix(".tmp")
        temporary.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.output)


if __name__ == "__main__":
    main()
