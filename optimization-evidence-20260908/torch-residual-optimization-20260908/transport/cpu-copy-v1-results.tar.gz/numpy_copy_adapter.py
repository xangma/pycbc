"""Diagnostic-only conversions around the unchanged qualified MKL plan."""
import ctypes

import numpy as np
import torch


def pointer_view(tensor, dtype):
    """Borrow storage without Tensor.numpy() changing storage resizability.

    The caller must retain the tensor and check its exact storage, shape and
    dtype before accessing this view. The ctypes buffer never owns the memory.
    """
    dtype = np.dtype(dtype)
    assert tensor.ndim == 1 and tensor.is_contiguous() and tensor.is_cpu
    assert tensor.element_size() == dtype.itemsize
    buffer = (ctypes.c_ubyte * (tensor.numel() * dtype.itemsize)).from_address(
        tensor.data_ptr()
    )
    view = np.ndarray((tensor.numel(),), dtype=dtype, buffer=buffer)
    assert view.ctypes.data == tensor.data_ptr() and not view.flags.owndata
    return view


class NumpyCopyAdapter:
    """Retain one current plan and use guarded NumPy dtype conversions."""

    def __init__(self, owner, source, target):
        assert owner._promote and owner._inplace
        assert owner._size == 2**21 and owner._nthreads == 1
        assert owner._native_source is owner._native_target
        assert owner._native_source.dtype == torch.complex128
        assert owner.can_execute(source, target)
        self.owner = owner
        self.source = source
        self.target = target
        self.native = owner._native_source
        self._native_ptr = self.native.data_ptr()
        before = [t.untyped_storage().resizable() for t in (source, target, self.native)]
        self._source_view = pointer_view(source, np.complex64)
        self._target_view = pointer_view(target, np.complex64)
        self._native_view = pointer_view(self.native, np.complex128)
        assert before == [t.untyped_storage().resizable() for t in (source, target, self.native)]

    def execute(self):
        owner = self.owner
        # The cached external-memory views must never be accessed after the
        # public tensors change storage or cease to satisfy the existing gate.
        if not owner.can_execute(self.source, self.target):
            raise ValueError('bound tensors no longer satisfy the current plan gate')
        assert owner._native_source is owner._native_target is self.native
        assert self.native.data_ptr() == self._native_ptr
        assert self.native.ndim == 1 and self.native.numel() == owner._size
        assert self.native.is_cpu and not self.native.requires_grad
        assert self.native.dtype == torch.complex128 and self.native.is_contiguous()
        np.copyto(self._native_view, self._source_view)
        owner._increment_version(self.native)
        status = owner._execute(owner._descriptor, self.native.data_ptr())
        owner._increment_version(self.native)
        owner._check_status(status)
        np.copyto(self._target_view, self._native_view)
        owner._increment_version(self.target)
