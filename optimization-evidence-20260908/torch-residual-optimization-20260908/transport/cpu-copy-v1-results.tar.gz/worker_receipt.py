"""Record and enforce observed one-thread pools around an unchanged FFT helper."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--receipt', required=True, type=Path)
parser.add_argument('--helper', required=True, type=Path)
parser.add_argument('arguments', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert not args.receipt.exists()
source = args.source.resolve(strict=True)
sys.path.insert(0, str(source))
import pycbc
import torch
from pycbc.fft import fftw, mkl
import threadpoolctl

assert Path(pycbc.__file__).resolve().parent.parent == source
torch.set_num_threads(1)


def snapshot():
    pools = threadpoolctl.threadpool_info()
    assert pools, 'native thread pool discovery returned no libraries'
    assert all(pool['num_threads'] == 1 for pool in pools), pools
    assert torch.get_num_threads() == 1
    return {'torch_intraop_threads': torch.get_num_threads(),
            'torch_interop_threads': torch.get_num_interop_threads(),
            'native_pools': pools, 'cpu_affinity': sorted(os.sched_getaffinity(0))}


record = {'state': 'running', 'pid': os.getpid(), 'pgid': os.getpgid(0),
          'interpreter': sys.executable, 'command': sys.argv,
          'wrapper_sha256': sha(__file__), 'helper_sha256': sha(args.helper),
          'fft_libraries': {'fftw': fftw.float_lib._name, 'mkl': mkl.lib._name},
          'threadpoolctl_sha256': sha(threadpoolctl.__file__)}
try:
    record['before'] = snapshot()
    arguments = args.arguments[1:] if args.arguments[:1] == ['--'] else args.arguments
    sys.argv = [str(args.helper), *arguments]
    runpy.run_path(str(args.helper), run_name='__main__')
    record['after'] = snapshot()
    record['state'] = 'complete'
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    args.receipt.write_text(json.dumps(record, indent=2) + '\n')
