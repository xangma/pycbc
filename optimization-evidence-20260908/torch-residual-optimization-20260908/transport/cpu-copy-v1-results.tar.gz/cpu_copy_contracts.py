"""Check borrowed-view storage and mutation contracts without NumPy exports."""
import argparse
import gc
import json
from pathlib import Path
import sys
import weakref

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.source.resolve(strict=True)))
sys.path.insert(1, str(Path(__file__).resolve().parent))

import torch
from pycbc import scheme
from pycbc.fft import torchfft
from pycbc.types import Array
from pycbc.types.array_torch import TorchArrayData
from numpy_copy_adapter import NumpyCopyAdapter

torch.set_num_threads(1)
assert not args.output.exists()
record = {'state': 'running', 'checks': []}


def make():
    source = torch.zeros(2**21, dtype=torch.complex64)
    target = torch.full_like(source, 3+4j)
    source[0] = 1+2j
    assert source.untyped_storage().resizable() and target.untyped_storage().resizable()
    with scheme.TorchScheme('cpu'):
        engine = torchfft.IFFT(Array(TorchArrayData(source), copy=False),
                               Array(TorchArrayData(target), copy=False))
    owner = engine._mkl_plan
    assert type(owner) is torchfft._MKLCPUDirectIFFTPlan
    assert source.untyped_storage().resizable() and target.untyped_storage().resizable()
    adapter = NumpyCopyAdapter(owner, source, target)
    assert source.untyped_storage().resizable() and target.untyped_storage().resizable()
    return adapter, source, target


def bits(tensor):
    return tensor.detach().view(torch.uint8)


try:
    probe = torch.empty(8, dtype=torch.complex64)
    assert probe.untyped_storage().resizable()
    exported = probe.numpy()
    assert not probe.untyped_storage().resizable()
    record['checks'].append('negative control: Tensor.numpy export changes resizability')
    adapter, source, target = make()
    source_before = source.clone()
    versions = [t._version for t in (source, target, adapter.native)]
    adapter.execute()
    assert torch.equal(bits(source), bits(source_before))
    assert torch.all(target == 1+2j).item()
    assert [t._version for t in (source, target, adapter.native)] == [
        versions[0], versions[1]+1, versions[2]+2]
    assert source.untyped_storage().resizable() and target.untyped_storage().resizable()
    record['checks'].append('exact impulse result, input preserved, public/private versions and resizability')
    del adapter, source, target, source_before
    gc.collect()
    for name, mutate in (
        ('source resize', lambda s, t: s.resize_(2**21+1)),
        ('target resize', lambda s, t: t.resize_(2**21+1)),
        ('source same-shape replacement storage', lambda s, t: s.set_(s.clone())),
        ('target same-shape replacement storage', lambda s, t: t.set_(t.clone())),
        ('source shape mutation', lambda s, t: s.resize_(2, 2**20)),
        ('target shape mutation', lambda s, t: t.resize_(2, 2**20)),
        ('source aliases target', lambda s, t: s.set_(t)),
        ('source requires grad', lambda s, t: s.requires_grad_(True)),
        ('target requires grad', lambda s, t: t.requires_grad_(True)),
    ):
        adapter, source, target = make()
        mutate(source, target)
        copies = [bits(t).clone() for t in (source, target)]
        versions = [t._version for t in (source, target, adapter.native)]
        try:
            adapter.execute()
        except ValueError:
            pass
        else:
            raise AssertionError(name + ' did not reject stale or ineligible buffers')
        assert [t._version for t in (source, target, adapter.native)] == versions
        assert all(torch.equal(bits(t), saved) for t, saved in zip((source, target), copies))
        record['checks'].append(name + ': rejected before external-memory writes')
        del adapter, source, target, copies
        gc.collect()
    adapter, source, target = make()
    versions = [t._version for t in (source, target, adapter.native)]
    copies = [bits(t).clone() for t in (source, target)]
    old_native = adapter.native
    adapter.owner._native_source = adapter.owner._native_target = old_native.clone()
    try:
        adapter.execute()
    except AssertionError:
        pass
    else:
        raise AssertionError('private workspace replacement was accepted')
    assert [t._version for t in (source, target, old_native)] == versions
    assert all(torch.equal(bits(t), saved) for t, saved in zip((source, target), copies))
    record['checks'].append('private workspace replacement: rejected before external-memory writes')
    del adapter, source, target, old_native, copies
    gc.collect()
    adapter, source, target = make()
    target_before = target.clone()
    versions = [t._version for t in (source, target, adapter.native)]
    adapter.owner._execute = lambda *args: -123
    def fail_status(status):
        assert status == -123
        raise RuntimeError('controlled native failure')
    adapter.owner._check_status = fail_status
    try:
        adapter.execute()
    except RuntimeError as error:
        assert str(error) == 'controlled native failure'
    else:
        raise AssertionError('native failure was suppressed')
    assert torch.equal(bits(target), bits(target_before))
    assert [t._version for t in (source, target, adapter.native)] == [versions[0], versions[1], versions[2]+2]
    record['checks'].append('native failure: propagated before public target write/version increment')
    del adapter, source, target, target_before
    gc.collect()
    adapter, source, target = make()
    refs = weakref.ref(source), weakref.ref(target), weakref.ref(adapter.owner)
    del source, target
    gc.collect()
    assert all(ref() is not None for ref in refs)
    adapter.execute()
    assert torch.all(refs[1]() == 1+2j).item()
    del adapter
    gc.collect()
    assert all(ref() is None for ref in refs)
    record['checks'].append('tensor/descriptor owners retained until adapter release')
    record['state'] = 'complete'
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    args.output.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record), flush=True)
