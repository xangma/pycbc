#!/usr/bin/env python3
"""Run the frozen CLI inside the separately pinned runtime-checking worker."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import subprocess
import sys
import time


LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')


def inherited_lock_fd(environment):
    """Retain the supervisor's exact locked open file description in the worker."""
    fd = int(environment['PYCBC_BENCHMARK_LOCK_FD'])
    if fd < 3:
        raise ValueError('Benchmark lock descriptor must not be a standard stream')
    actual, expected = os.fstat(fd), LOCK.stat()
    if (not stat.S_ISREG(actual.st_mode) or
            (actual.st_dev, actual.st_ino) != (expected.st_dev, expected.st_ino)):
        raise ValueError('Inherited descriptor does not identify the shared lock')
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return fd


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--case', required=True)
    parser.add_argument('--mode', choices=['timing', 'qualify'],
                        default='timing')
    parser.add_argument('--scheme', default='cpu:1')
    parser.add_argument('--segment-length', type=int, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--start-pad', type=int, default=112)
    parser.add_argument('--end-pad', type=int, default=16)
    args = parser.parse_args()
    if Path(args.case).name != args.case:
        parser.error('--case must be a directory basename')
    cfg = json.loads(args.config.read_text())
    lock_fd = inherited_lock_fd(os.environ)
    root = args.config.resolve().parent
    out = root / 'runs' / args.case
    out.mkdir(parents=True, exist_ok=False)
    source = args.source.resolve()
    executable = source / 'bin' / 'pycbc_inspiral'
    spec = importlib.util.spec_from_file_location('checked_inspiral',
                                                 root / 'checked-inspiral.py')
    runtime = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime)
    fixed_env = runtime.fixed_environment(cfg, source)
    env = runtime.clean_environment(os.environ, cfg, source)
    cli = [str(executable), *cfg['common_args'],
           '--bank-file', str(args.bank.resolve()),
           '--processing-scheme', args.scheme,
           '--segment-length', str(args.segment_length),
           '--segment-start-pad', str(args.start_pad),
           '--segment-end-pad', str(args.end_pad),
           '--output', str(out / 'triggers.hdf')]
    workload = cli
    if args.mode == 'qualify':
        workload = [str(root / 'qualify-inspiral.py'),
                    '--receipt', str(out / 'qualification.json'), '--', *cli]
    command = [sys.executable, str(root / 'checked-inspiral.py'),
               '--receipt', str(out / 'runtime.json'),
               '--config', str(args.config.resolve()), '--source', str(source),
               '--', *workload]
    command = ['taskset', '-c', str(cfg['core']), *command]
    command = ['/usr/bin/time', '-v', '-o', str(out / 'time.txt'), *command]
    source_info = {
        'commit': subprocess.check_output(
            ['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip(),
        'status': subprocess.check_output(
            ['git', '-C', str(source), 'status', '--porcelain'], text=True),
        'tracked_diff': subprocess.check_output(
            ['git', '-C', str(source), 'diff', 'HEAD', '--'], text=True),
    }
    if source_info['status']:
        raise RuntimeError('Source must be clean before running')
    inputs = [args.config.resolve(), args.bank.resolve(), executable,
              Path(__file__).resolve(), root / 'checked-inspiral.py',
              *map(Path, cfg['input_files'])]
    if args.mode == 'qualify':
        inputs.append(root / 'qualify-inspiral.py')
    record = dict(case=args.case, mode=args.mode, scheme=args.scheme,
                  segment_length=args.segment_length, start_pad=args.start_pad,
                  end_pad=args.end_pad, source=str(source), source_info=source_info,
                  command=command, executable_cli=cli, environment=fixed_env,
                  hostname=os.uname().nodename, cwd=str(root), parent_pid=os.getpid(),
                  inherited_lock=dict(path=str(LOCK), fd=lock_fd),
                  input_sha256={str(p): digest(p) for p in inputs},
                  started_utc=utc(), state='running')
    receipt = out / 'receipt.json'

    def save():
        temporary = receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(receipt)

    save()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    started = time.perf_counter()
    with open(out / 'stdout.log', 'w') as stdout, open(out / 'stderr.log', 'w') as stderr:
        child = subprocess.Popen(command, cwd=root, env=env,
                                 pass_fds=(lock_fd,),
                                 stdout=stdout, stderr=stderr)
        record['child_pid'] = child.pid
        save()
        code = child.wait()
    elapsed = time.perf_counter() - started
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    record.update(state='complete' if code == 0 else 'failed', returncode=code,
                  finished_utc=utc(), elapsed_wall_seconds=elapsed,
                  child_user_cpu_seconds=after.ru_utime - before.ru_utime,
                  child_system_cpu_seconds=after.ru_stime - before.ru_stime,
                  peak_child_rss_kib=after.ru_maxrss)
    record['input_sha256_after'] = {str(p): digest(p) for p in inputs}
    record['source_status_after'] = subprocess.check_output(
        ['git', '-C', str(source), 'status', '--porcelain'], text=True)
    if record['input_sha256_after'] != record['input_sha256'] or record['source_status_after']:
        record['state'] = 'invalid-input-mutation'
        code = 1
    if (out / 'runtime.json').exists():
        record['runtime_sha256'] = digest(out / 'runtime.json')
    else:
        record['state'] = 'missing-runtime-receipt'
        code = 1
    if (out / 'triggers.hdf').exists():
        record['trigger_sha256'] = digest(out / 'triggers.hdf')
    save()
    print(json.dumps(record))
    return code


if __name__ == '__main__':
    sys.exit(main())
