#!/usr/bin/env python3
"""Verify the runtime of one fresh, single-core inspiral worker."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import socket
import sys
import time


PREFIXES = ('PYCBC_', 'OMP_', 'MKL_', 'OPENBLAS_', 'NUMEXPR_',
            'BLIS_', 'VECLIB_', 'TORCH_')
EXACT = ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'PYTHONHASHSEED',
         'CUDA_VISIBLE_DEVICES')
EXTRA_ENV = {'OMP_DYNAMIC': 'FALSE', 'CUDA_VISIBLE_DEVICES': ''}


def relevant_environment(environment):
    return {k: v for k, v in sorted(environment.items())
            if k.startswith(PREFIXES) or k in EXACT}


def fixed_environment(config, source):
    return dict(config['environment'], **EXTRA_ENV, PYTHONPATH=str(source),
                PYTHONDONTWRITEBYTECODE='1')


def clean_environment(environment, config, source):
    result = {k: v for k, v in environment.items()
              if not (k.startswith(PREFIXES) or k in EXACT)}
    result.update(fixed_environment(config, source))
    return result


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def expected_threadpoolctl():
    path = Path(__file__).resolve().parent / 'threadpoolctl.py'
    return dict(path=str(path), version='3.6.0', sha256=digest(path))


def snapshot(torch):
    # Introspection must not enable threadpoolctl's duplicate-OpenMP escape hatch.
    duplicate_policy = os.environ.get('KMP_DUPLICATE_LIB_OK')
    try:
        import threadpoolctl
    finally:
        if duplicate_policy is None:
            os.environ.pop('KMP_DUPLICATE_LIB_OK', None)
        else:
            os.environ['KMP_DUPLICATE_LIB_OK'] = duplicate_policy
    from pycbc import scheme
    affinity = sorted(os.sched_getaffinity(0))
    topology = {str(cpu): (Path('/sys/devices/system/cpu') /
                f'cpu{cpu}/topology/thread_siblings_list').read_text().strip()
                for cpu in affinity}
    state = scheme.mgr.state
    return dict(intra_op=torch.get_num_threads(),
                inter_op=torch.get_num_interop_threads(),
                affinity=affinity, smt_siblings=topology,
                scheme=type(state).__name__, device=str(getattr(state, 'device', '')),
                threadpools=threadpoolctl.threadpool_info(),
                threadpoolctl=dict(path=str(Path(threadpoolctl.__file__).resolve()),
                                   version=threadpoolctl.__version__,
                                   sha256=digest(threadpoolctl.__file__)),
                environment=relevant_environment(os.environ), observed_at=time.time())


def check(value, environment, bank=False):
    if value['threadpoolctl'] != expected_threadpoolctl():
        raise ValueError('Native threadpool observation imported another helper')
    if (value['intra_op'] != 1 or value['inter_op'] != 1 or
            value['affinity'] != [8] or value['smt_siblings'] != {'8': '8,72'}):
        raise ValueError('Observed thread counts or affinity differ from one-core setup')
    if value['environment'] != environment:
        raise ValueError('Unexpected inherited runtime environment')
    if not value['threadpools'] or any(p['num_threads'] != 1
                                     for p in value['threadpools']):
        raise ValueError('A loaded native thread pool is not single-threaded')
    if bank and (value['scheme'] != 'TorchScheme' or value['device'] != 'cpu'):
        raise ValueError('Bank was not consumed under Torch CPU scheme')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not command:
        parser.error('Missing executable command')
    source = args.source.resolve()
    environment = fixed_environment(json.loads(args.config.read_text()), source)
    record = dict(state='running', pid=os.getpid(), hostname=socket.gethostname(),
                  command=command, source=str(source), started_at=time.time(),
                  helper_sha256=digest(__file__), environment=environment)
    previous_argv, bank, original = sys.argv, None, None

    def save():
        temporary = args.receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(args.receipt)

    try:
        if relevant_environment(os.environ) != environment:
            raise ValueError('Runner did not sanitize inherited environment')
        import torch
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        import pycbc
        from pycbc.types import array_torch
        from pycbc.waveform.bank import FilterBank
        record.update(torch_version=str(torch.__version__),
                      torch_cuda_version=torch.version.cuda,
                      imported_source=str(Path(pycbc.__file__).resolve().parent.parent),
                      imported_module=str(Path(array_torch.__file__).resolve()),
                      module_sha256=digest(array_torch.__file__))
        if record['imported_source'] != str(source) or record['imported_module'] != str(
                source / 'pycbc/types/array_torch.py'):
            raise ValueError('Worker imported another source checkout')
        record['before_executable'] = snapshot(torch)
        check(record['before_executable'], environment)
        bank, original = FilterBank, FilterBank.__getitem__

        def first_bank(self, index):
            if 'at_first_bank' not in record:
                record['at_first_bank'] = snapshot(torch)
                check(record['at_first_bank'], environment, bank=True)
                if bank.__getitem__ is first_bank:
                    bank.__getitem__ = original
                save()
            return original(self, index)

        bank.__getitem__ = first_bank
        save()
        sys.argv = command
        try:
            runpy.run_path(command[0], run_name='__main__')
        except SystemExit as error:
            if error.code not in (None, 0):
                raise
        record['after_executable'] = snapshot(torch)
        check(record['after_executable'], environment)
        if 'at_first_bank' not in record:
            raise ValueError('Workload did not consume a bank')
        record['state'] = 'complete'
    except BaseException as error:
        record.update(state='failed', error=repr(error))
        raise
    finally:
        if bank is not None and original is not None:
            bank.__getitem__ = original
        sys.argv = previous_argv
        record['finished_at'] = time.time()
        save()


if __name__ == '__main__':
    main()
