#!/usr/bin/env python3
"""Fresh-worker public Array.squared_norm baseline/candidate experiment.

Use the candidate checkout on PYTHONPATH. The baseline worker replaces only
the backend function, extracted from the pinned full baseline source file.
Setup, qualification and output hashing are outside the per-call timer.
No FFTs, batching, PSD estimation or filtering are timed by this experiment.
"""

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import statistics
import subprocess
import sys
import time


BASE_REVISION = "9578a710479b924e882857c4dffab6ed372a634b"
SIZES = (16, 512, 4095, 4096, 8193, 131072, 1048577)
THREAD_ENV = ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
              "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def host_state():
    result = {"loadavg": os.getloadavg(), "time_ns": time.time_ns()}
    if hasattr(os, "sched_getaffinity"):
        result["affinity"] = sorted(os.sched_getaffinity(0))
        result["smt_siblings"] = {
            str(cpu): Path(f"/sys/devices/system/cpu/cpu{cpu}/topology/"
                           "thread_siblings_list").read_text().strip()
            for cpu in result["affinity"]
        }
    for name in ("stat", "meminfo", "loadavg"):
        path = Path("/proc") / name
        if path.exists():
            result[name] = path.read_text()
    return result


def worker(args):
    import numpy as np
    import torch
    from pycbc import scheme
    from pycbc.types import Array, array_torch

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    baseline_source = Path(args.baseline_source).read_text()
    node = next(n for n in ast.parse(baseline_source).body
                if isinstance(n, ast.FunctionDef) and n.name == "squared_norm")
    namespace = dict(vars(array_torch))
    exec(compile(ast.Module(body=[node], type_ignores=[]),
                 "pinned-baseline-squared-norm", "exec"), namespace)
    baseline = namespace["squared_norm"]
    if args.variant == "baseline":
        array_torch.squared_norm = baseline

    result = {
        "variant": args.variant, "base_revision": BASE_REVISION,
        "baseline_source_sha256": sha(args.baseline_source),
        "candidate_source": array_torch.__file__,
        "candidate_source_sha256": sha(array_torch.__file__),
        "harness_sha256": sha(__file__), "pid": os.getpid(),
        "host": socket.gethostname(), "platform": platform.platform(),
        "python": sys.version, "torch": torch.__version__,
        "numpy": np.__version__, "threads": torch.get_num_threads(),
        "interop_threads": torch.get_num_interop_threads(),
        "thread_environment": {k: os.environ.get(k) for k in THREAD_ENV},
        "before": host_state(), "cells": [],
        "scope": "public Array.squared_norm CPU call; setup, validation and "
                 "hashing excluded; no FFT or batching; shared local/remote host",
    }
    context = scheme.TorchScheme("cpu", num_threads=1)
    try:
        with context:
            cases = [(size, 1) for size in SIZES] + [(4096, 3), (131072, 3)]
            for dtype in (np.complex64, np.complex128):
                for size, stride in cases:
                    rng = np.random.default_rng(170817)
                    values = (rng.standard_normal(size * stride + 1)
                              + 1j * rng.standard_normal(size * stride + 1))
                    values = values.astype(dtype)
                    tensor = torch.from_numpy(values)[1::stride]
                    array = Array(array_torch.TorchArrayData(tensor), copy=False)
                    expected = baseline(array).tensor
                    actual = array.squared_norm()._data.tensor
                    assert torch.equal(actual, expected)
                    assert actual.dtype == expected.dtype
                    before = values.copy()
                    for _ in range(5):
                        array.squared_norm()
                    start = time.perf_counter_ns()
                    for _ in range(5):
                        array.squared_norm()
                    estimate = (time.perf_counter_ns() - start) / 5e9
                    count = max(1, min(10000, int(0.03 / estimate)))
                    samples = []
                    for _ in range(7):
                        start = time.perf_counter_ns()
                        for _ in range(count):
                            actual = array.squared_norm()
                        samples.append((time.perf_counter_ns() - start) / count / 1e9)
                    np.testing.assert_array_equal(values, before)
                    assert torch.equal(actual._data.tensor, expected)
                    result["cells"].append({
                        "dtype": np.dtype(dtype).name, "size": size,
                        "stride": stride, "calls_per_sample": count,
                        "seconds_per_call": samples,
                        "median_seconds": statistics.median(samples),
                        "input_sha256": hashlib.sha256(values.tobytes()).hexdigest(),
                        "output_sha256": hashlib.sha256(expected.numpy().tobytes()).hexdigest(),
                        "exact_parity": True, "input_unchanged": True,
                    })
    finally:
        del context
        scheme.Scheme._single = None
    result["after"] = host_state()
    Path(args.output).write_text(json.dumps(result, indent=2) + "\n")


def campaign(args):
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update({key: "1" for key in THREAD_ENV})
    results = []
    for repeat in range(3):
        order = ("baseline", "candidate") if repeat % 2 == 0 else ("candidate", "baseline")
        for variant in order:
            path = output / f"{variant}-r{repeat + 1}.json"
            command = [sys.executable, __file__, "--worker", "--variant", variant,
                       "--baseline-source", args.baseline_source, "--output", str(path)]
            print("running", variant, repeat + 1, flush=True)
            subprocess.run(command, env=env, check=True)
            results.append(json.loads(path.read_text()))
    grouped = {}
    for result in results:
        for cell in result["cells"]:
            key = (cell["dtype"], cell["size"], cell["stride"])
            group = grouped.setdefault(key, {"baseline": [], "candidate": [],
                                            "input": set(), "output": set()})
            group[result["variant"]].append(cell["median_seconds"])
            group["input"].add(cell["input_sha256"])
            group["output"].add(cell["output_sha256"])
    summary = {"scope": results[0]["scope"], "workers": 6,
               "base_revision": BASE_REVISION, "cells": []}
    for (dtype, size, stride), group in grouped.items():
        assert len(group["input"]) == len(group["output"]) == 1
        row = {"dtype": dtype, "size": size, "stride": stride,
               "baseline_seconds": group["baseline"],
               "candidate_seconds": group["candidate"],
               "ratio": statistics.median(group["baseline"]) /
                        statistics.median(group["candidate"]), "exact_parity": True}
        summary["cells"].append(row)
        print(dtype, size, stride, round(row["ratio"], 3), flush=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--variant", choices=("baseline", "candidate"))
    parser.add_argument("--baseline-source", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.worker:
        worker(args)
    else:
        campaign(args)


if __name__ == "__main__":
    main()
