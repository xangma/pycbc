"""Small HDF/receipt fixtures; these are comparator tests, not campaign evidence."""

import copy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

import h5py
import numpy as np
import pytest


SPEC = importlib.util.spec_from_file_location(
    "compare_candidate", Path(__file__).with_name("compare-candidate.py")
)
candidate = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(candidate)
frozen = candidate.frozen_comparator()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


@pytest.fixture
def evidence(tmp_path):
    """Manufactured sources/native manifest plus actual small HDFs/receipts."""
    config = candidate.read(candidate.ROOT / "config.json")
    before = {
        "hostname": "fixture-host", "started_at": 1000, "finished_at": 1001,
        "helpers": candidate.trusted_helpers(), "input_sha256": dict(candidate.INPUTS),
        "changed_files": list(candidate.CHANGED), "diff_sha256": candidate.DIFF_SHA,
        "sources": {},
    }
    paths, receipts = [], []
    for i, (role, revision) in enumerate(candidate.REVISIONS.items()):
        source = str(tmp_path / ("source-" + role))
        before["sources"][role] = {
            "path": source,
            "source_snapshot": {"commit": revision, "status": "", "tracked_diff": ""},
            "module_sha256": candidate.MODULE_SHA[role],
            "executable_sha256": candidate.EXEC_SHA,
            "native_sha256": candidate.expected_native(),
        }
        case = role + "-r1"
        folder = tmp_path / "runs" / case
        folder.mkdir(parents=True)
        path = folder / "triggers.hdf"
        with h5py.File(path, "w") as stream:
            epoch = 1187007160.0
            stream["H1/search/start_time"] = [epoch]
            stream["H1/search/end_time"] = [epoch + 1904]
            stream["H1/template_hash"] = np.array([7, 8], dtype=np.int64)
            stream["H1/end_time"] = [epoch + 1, epoch + 2]
            stream["H1/snr"] = np.array([8., 9.], dtype=np.float32)
            stream["H1/chisq"] = np.array([30., 30.], dtype=np.float32)
            stream["H1/chisq_dof"] = [16., 16.]
            stream["H1/sigmasq"] = np.array([1e6, 2e6], dtype=np.float32)
        executable = source + "/bin/pycbc_inspiral"
        cli = [executable, *config["common_args"], "--bank-file", candidate.BANK,
               "--processing-scheme", "torch:cpu:1", "--segment-length", "512",
               "--segment-start-pad", "112", "--segment-end-pad", "16",
               "--output", str(path)]
        command = ["/usr/bin/time", "-v", "-o", str(folder / "time.txt"),
                   "taskset", "-c", "8", candidate.PYTHON,
                   str(tmp_path / "checked-inspiral.py"), "--receipt",
                   str(folder / "runtime.json"), "--config", str(tmp_path / "config.json"),
                   "--source", source, "--", *cli]
        inputs = dict(candidate.INPUTS, **{
            executable: candidate.EXEC_SHA,
            str(tmp_path / "config.json"): candidate.HELPERS["config.json"],
            str(tmp_path / "run-case-verified.py"): candidate.HELPERS["run-case-verified.py"],
            str(tmp_path / "checked-inspiral.py"): candidate.HELPERS["checked-inspiral.py"],
        })
        receipt = {
            "case": case, "cwd": str(tmp_path), "mode": "timing",
            "scheme": "torch:cpu:1", "segment_length": 512,
            "start_pad": 112, "end_pad": 16, "source": source,
            "source_info": copy.deepcopy(before["sources"][role]["source_snapshot"]),
            "source_status_after": "", "command": command, "executable_cli": cli,
            "environment": dict(config["environment"], PYTHONPATH=source,
                                PYTHONDONTWRITEBYTECODE="1", OMP_DYNAMIC="FALSE",
                                CUDA_VISIBLE_DEVICES=""),
            "hostname": "fixture-host", "state": "complete", "returncode": 0,
            "started_utc": datetime.fromtimestamp(1010 + i * 10, timezone.utc).isoformat(),
            "finished_utc": datetime.fromtimestamp(1015 + i * 10, timezone.utc).isoformat(),
            "input_sha256": inputs, "input_sha256_after": copy.deepcopy(inputs),
            "trigger_sha256": candidate.digest(path),
        }
        runtime = dict(state="complete", pid=200 + i, hostname="fixture-host",
                       command=cli, source=source, imported_source=source,
                       imported_module=source + "/pycbc/types/array_torch.py",
                       module_sha256=candidate.MODULE_SHA[role],
                       helper_sha256=candidate.HELPERS["checked-inspiral.py"],
                       torch_version="fixture-version", torch_cuda_version=None,
                       environment=receipt["environment"],
                       started_at=1011 + i * 10, finished_at=1014 + i * 10)
        for offset, phase in enumerate(("before_executable", "at_first_bank", "after_executable")):
            runtime[phase] = dict(intra_op=1, inter_op=1, affinity=[8],
                smt_siblings={"8": "8,72"}, scheme="TorchScheme", device="cpu",
                threadpools=[{"num_threads": 1}],
                threadpoolctl=dict(path=str(candidate.ROOT / "threadpoolctl.py"), version="3.6.0",
                                   sha256=candidate.HELPERS["threadpoolctl.py"]),
                environment=receipt["environment"],
                observed_at=1011.1 + i * 10 + offset)
        write_json(folder / "runtime.json", runtime)
        receipt["runtime_sha256"] = candidate.digest(folder / "runtime.json")
        write_json(folder / "receipt.json", receipt)
        paths.append(path)
        receipts.append(receipt)
    after = copy.deepcopy(before)
    after.update(started_at=1030, finished_at=1031)
    return paths, receipts, before, after


def compare(evidence):
    paths, receipts, before, after = evidence
    items = [frozen.load(p) for p in paths]
    return candidate.cross_revision(frozen, *items, receipts, before, after)


def test_exact_pair_keeps_raw_failure_and_untouched_receipts(evidence, tmp_path, monkeypatch):
    paths, receipts, before, after = evidence
    originals = [p.with_name("receipt.json").read_bytes() for p in paths]
    original_snapshots = copy.deepcopy([before, after])
    raw = frozen.compare(*(frozen.load(p) for p in paths), frozen.DEFAULTS)
    assert raw["status"] == "fail"
    assert set(raw["failures"]) == {
        "configuration mismatch: source_snapshot",
        "configuration mismatch: consumed_input_sha256",
    }
    result = compare(evidence)
    assert result["status"] == "pass"
    assert result["tolerances"] == frozen.DEFAULTS
    assert result["scope"] == "cross-revision scientific parity"
    assert [before, after] == original_snapshots
    write_json(tmp_path / "before.json", before)
    write_json(tmp_path / "after.json", after)
    monkeypatch.setattr("sys.argv", ["compare-candidate.py", "compare",
        "--baseline", str(paths[0]), "--candidate", str(paths[1]),
        "--before", str(tmp_path / "before.json"), "--after", str(tmp_path / "after.json"),
        "--output", str(tmp_path / "comparison")])
    assert candidate.main() == 0
    assert candidate.read(tmp_path / "comparison/raw-strict-comparison.json") == raw
    assert candidate.read(tmp_path / "comparison/cross-revision-comparison.json")["status"] == "pass"
    assert [p.with_name("receipt.json").read_bytes() for p in paths] == originals


@pytest.mark.parametrize("mutation", [
    "wrong_revision", "dirty", "diff_files", "diff_bytes", "native", "extra_native",
    "executable", "module", "helpers", "input", "checkout_drift", "host", "time_window",
])
def test_rejects_provenance_changes(evidence, mutation):
    paths, receipts, before, after = evidence
    source = after["sources"]["candidate"]
    if mutation == "wrong_revision": source["source_snapshot"]["commit"] = "0" * 40
    elif mutation == "dirty": source["source_snapshot"]["status"] = " M file"
    elif mutation == "diff_files": after["changed_files"].append("pycbc/filter/other.py")
    elif mutation == "diff_bytes": after["diff_sha256"] = "0" * 64
    elif mutation == "native": source["native_sha256"][next(iter(source["native_sha256"]))] = "0" * 64
    elif mutation == "extra_native": source["native_sha256"]["pycbc/extra.so"] = "0" * 64
    elif mutation == "executable": source["executable_sha256"] = "0" * 64
    elif mutation == "module": source["module_sha256"] = "0" * 64
    elif mutation == "helpers": after["helpers"]["run-case.py"] = "0" * 64
    elif mutation == "input": after["input_sha256"][candidate.BANK] = "0" * 64
    elif mutation == "checkout_drift": source["path"] += "-other"
    elif mutation == "host": after["hostname"] = "other-host"
    elif mutation == "time_window": after["started_at"] = 1022
    with pytest.raises(ValueError):
        compare(evidence)


@pytest.mark.parametrize("mutation", [
    "wrong_source", "source_path", "source_dirty_after", "executable_bytes",
    "input_hash", "input_after", "cli", "affinity", "threads", "returncode",
    "scheme", "geometry", "missing_input",
])
def test_rejects_run_receipt_changes(evidence, mutation):
    paths, receipts, before, after = evidence
    receipt = receipts[1]
    if mutation == "wrong_source": receipt["source_info"]["commit"] = candidate.BASE
    elif mutation == "source_path": receipt["source"] += "-other"
    elif mutation == "source_dirty_after": receipt["source_status_after"] = " M file"
    elif mutation == "executable_bytes": receipt["input_sha256"][receipt["executable_cli"][0]] = "0" * 64
    elif mutation == "input_hash": receipt["input_sha256"][candidate.BANK] = "0" * 64
    elif mutation == "input_after": receipt["input_sha256_after"][candidate.FRAME] = "0" * 64
    elif mutation == "cli": receipt["executable_cli"][receipt["executable_cli"].index("--snr-threshold") + 1] = "5"
    elif mutation == "affinity": receipt["command"][6] = "72"
    elif mutation == "threads": receipt["environment"]["OMP_NUM_THREADS"] = "2"
    elif mutation == "returncode": receipt["returncode"] = 1
    elif mutation == "scheme": receipt["scheme"] = "cpu:1"
    elif mutation == "geometry": receipt["segment_length"] = 256
    elif mutation == "missing_input": del receipt["input_sha256"][candidate.FRAME]
    with pytest.raises(ValueError):
        compare(evidence)


@pytest.mark.parametrize("field,value", [
    ("snr", 50), ("sigmasq", 1e9), ("chisq_dof", 17),
    ("end_time", 1187007161 + 1 / 4096), ("template_hash", 900),
])
def test_scientific_changes_still_fail(evidence, field, value):
    paths, receipts, before, after = evidence
    with h5py.File(paths[1], "r+") as stream:
        stream["H1/" + field][0] = value
    receipts[1]["trigger_sha256"] = candidate.digest(paths[1])
    write_json(paths[1].with_name("receipt.json"), receipts[1])
    assert compare(evidence)["status"] == "fail"


def test_unchanged_frozen_comparator_self_tests():
    result = frozen.self_test()
    assert result["status"] == "pass"
    assert result["count"] > 0


def test_qualification_mode_keeps_same_policy(evidence):
    paths, receipts, before, after = evidence
    for path, receipt in zip(paths, receipts):
        root = Path(receipt["cwd"])
        receipt["mode"] = "qualify"
        workload = [str(root / "qualify-inspiral.py"), "--receipt",
            str(path.with_name("qualification.json")), "--", *receipt["executable_cli"],
        ]
        receipt["command"] = receipt["command"][:16] + workload
        runtime = candidate.read(path.with_name("runtime.json"))
        runtime["command"] = workload
        write_json(path.with_name("runtime.json"), runtime)
        receipt["runtime_sha256"] = candidate.digest(path.with_name("runtime.json"))
        for key in ("input_sha256", "input_sha256_after"):
            receipt[key][str(root / "qualify-inspiral.py")] = candidate.HELPERS["qualify-inspiral.py"]
        write_json(path.with_name("receipt.json"), receipt)
    assert compare(evidence)["status"] == "pass"


def test_near_threshold_missing_trigger_never_passes(evidence):
    paths, receipts, before, after = evidence
    with h5py.File(paths[0], "r+") as stream:
        stream["H1/snr"][1] = 5.50001
    with h5py.File(paths[1], "r+") as stream:
        for key in ("snr", "chisq", "chisq_dof", "sigmasq", "template_hash", "end_time"):
            values = stream["H1/" + key][:1]
            del stream["H1/" + key]
            stream["H1/" + key] = values
    for path, receipt in zip(paths, receipts):
        receipt["trigger_sha256"] = candidate.digest(path)
        write_json(path.with_name("receipt.json"), receipt)
    assert compare(evidence)["status"] == "review"


def test_changed_frozen_helper_is_rejected(monkeypatch):
    original = candidate.digest
    monkeypatch.setattr(candidate, "digest", lambda p: "0" * 64
                        if Path(p).name == "config.json" else original(p))
    with pytest.raises(ValueError, match="Changed helper"):
        candidate.trusted_helpers()


@pytest.mark.parametrize("mutation", ["missing", "hash", "state", "helper", "command",
    "source", "module", "host", "time", "environment", "intra", "inter", "affinity",
    "sibling", "pool", "scheme", "phase", "version", "pid", "threadpool_module"])
def test_rejects_runtime_drift(evidence, mutation):
    paths, receipts, before, after = evidence
    path = paths[1].with_name("runtime.json")
    runtime = candidate.read(path)
    first = runtime["at_first_bank"]
    if mutation == "missing": path.unlink()
    elif mutation == "hash": receipts[1]["runtime_sha256"] = "0" * 64
    elif mutation == "state": runtime["state"] = "failed"
    elif mutation == "helper": runtime["helper_sha256"] = "0" * 64
    elif mutation == "command": runtime["command"] = ["other"]
    elif mutation == "source": runtime["imported_source"] += "-other"
    elif mutation == "module": runtime["module_sha256"] = "0" * 64
    elif mutation == "host": runtime["hostname"] = "other"
    elif mutation == "time": first["observed_at"] = 0
    elif mutation == "environment": first["environment"]["PYCBC_TORCH_TRUSTED_ARRAYS"] = "1"
    elif mutation == "intra": first["intra_op"] = 2
    elif mutation == "inter": first["inter_op"] = 2
    elif mutation == "affinity": first["affinity"] = [8, 72]
    elif mutation == "sibling": first["smt_siblings"]["8"] = "8"
    elif mutation == "pool": first["threadpools"][0]["num_threads"] = 2
    elif mutation == "threadpool_module": first["threadpoolctl"]["path"] += "-other"
    elif mutation == "scheme": first["scheme"] = "CPUScheme"
    elif mutation == "phase": del runtime["at_first_bank"]
    elif mutation == "version": runtime["torch_version"] = "other"
    elif mutation == "pid": runtime["pid"] = 200
    if mutation not in ("missing", "hash"):
        write_json(path, runtime)
        receipts[1]["runtime_sha256"] = candidate.digest(path)
    with pytest.raises((ValueError, OSError, KeyError)):
        compare(evidence)
