#!/usr/bin/env python3
"""Sanitize and exec one frozen public-API worker without dropping the lock."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import socket
import sys
import time

ROOT = Path(__file__).resolve().parent


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--variant', choices=('baseline', 'candidate'), required=True)
    parser.add_argument('--repeat', type=int, choices=(1, 2, 3), required=True)
    args = parser.parse_args()
    runner = load('verified_runner', 'run-case-verified.py')
    runtime = load('checked_runtime', 'checked-inspiral.py')
    fd = runner.inherited_lock_fd(os.environ)
    os.set_inheritable(fd, True)
    if sorted(os.sched_getaffinity(0)) != [8]:
        raise ValueError('Public API worker is not pinned to CPU8')
    config = json.loads((ROOT / 'config.json').read_text())
    environment = runtime.clean_environment(os.environ, config, args.source.resolve())
    os.environ.clear()
    os.environ.update(environment)
    case = f'{args.variant}-r{args.repeat}'
    output = ROOT / 'api-results' / (case + '.json')
    if output.exists():
        raise FileExistsError(output)
    harness = ROOT / 'benchmark-squared-norm.py'
    command = [sys.executable, str(harness), '--worker', '--variant', args.variant,
               '--baseline-source', str(ROOT / 'baseline-array-torch.py'),
               '--output', str(output)]
    record = dict(pid=os.getpid(), hostname=socket.gethostname(), started_at=time.time(),
                  command=command, inherited_lock=dict(fd=fd, path=str(runner.LOCK)),
                  affinity=sorted(os.sched_getaffinity(0)),
                  environment=runtime.relevant_environment(os.environ),
                  helper_sha256=runner.digest(__file__), harness_sha256=runner.digest(harness))
    with (ROOT / 'api-launches' / (case + '.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    os.execv(sys.executable, command)


if __name__ == '__main__':
    main()
