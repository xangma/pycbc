"""Linux fake-workload test of the real runner's inherited-lock exec chain."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import pytest

ROOT = Path(__file__).resolve().parent


def active_group(pgid):
    result = []
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            try:
                fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            except FileNotFoundError:
                continue
            if fields[0] != 'Z' and int(fields[2]) == pgid:
                result.append(int(path.name))
    return result


def wait_until(predicate, seconds=3):
    deadline = time.monotonic() + seconds
    while not predicate():
        if time.monotonic() >= deadline:
            raise TimeoutError('Synthetic process did not reach its expected state')
        time.sleep(.01)


@pytest.mark.skipif(not sys.platform.startswith('linux'), reason='Linux exec/PGID contract')
def test_real_runner_keeps_lock_after_parent_close_and_runner_sigkill(tmp_path):
    """No PyCBC workload: a bounded fake leaf proves actual pass_fds transport."""
    assert 8 in os.sched_getaffinity(0), 'Required Linux test CPU8 is unavailable'
    source = tmp_path / 'source'
    (source / 'bin').mkdir(parents=True)
    (source / 'bin/pycbc_inspiral').write_text('# fake executable\n')
    bank = tmp_path / 'bank.hdf'
    bank.write_bytes(b'fake input')
    config = json.loads((ROOT / 'config.json').read_text())
    config.update(common_args=[], input_files=[])
    cfg = tmp_path / 'config.json'
    cfg.write_text(json.dumps(config))
    lock_path = tmp_path / 'shared-lock'
    # Imported by the real runner, then launched through real time/taskset/Python.
    # This deliberately substitutes only the scientific worker with a fake leaf.
    leaf = tmp_path / 'checked-inspiral.py'
    leaf.write_text(f'''import importlib.util,json,os,pathlib,time
spec=importlib.util.spec_from_file_location('real_runtime',{str(ROOT / 'checked-inspiral.py')!r})
real=importlib.util.module_from_spec(spec)
spec.loader.exec_module(real)
fixed_environment=real.fixed_environment
clean_environment=real.clean_environment
if __name__ == '__main__':
 assert 'PYCBC_BENCHMARK_LOCK_FD' not in os.environ
 expected=pathlib.Path('shared-lock').stat()
 inherited=[]
 for p in pathlib.Path('/proc/self/fd').iterdir():
  try: actual=os.fstat(int(p.name))
  except OSError: continue
  if (actual.st_dev,actual.st_ino)==(expected.st_dev,expected.st_ino): inherited.append(int(p.name))
 assert inherited
 pathlib.Path('ready').write_text(json.dumps(dict(pid=os.getpid(),pgid=os.getpgrp(),fds=inherited)))
 deadline=time.monotonic()+10
 while not pathlib.Path('release').exists():
  if time.monotonic() >= deadline: raise SystemExit(2)
  time.sleep(.01)
''')
    bootstrap = tmp_path / 'bootstrap.py'
    bootstrap.write_text(f'''import importlib.util,pathlib,sys
spec=importlib.util.spec_from_file_location('real_runner',{str(ROOT / 'run-case-verified.py')!r})
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.LOCK=pathlib.Path({str(lock_path)!r})
runner.subprocess.check_output=lambda command,**kw:'fixture-commit\\n' if 'rev-parse' in command else ''
sys.argv=['runner','--config',{str(cfg)!r},'--case','fixture','--mode','timing',
          '--scheme','torch:cpu:1','--segment-length','512','--source',{str(source)!r},'--bank',{str(bank)!r}]
raise SystemExit(runner.main())
''')
    lock = lock_path.open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    child = subprocess.Popen([sys.executable, bootstrap], cwd=tmp_path,
        env=dict(os.environ, PYCBC_BENCHMARK_LOCK_FD=str(lock.fileno())),
        pass_fds=(lock.fileno(),), start_new_session=True,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        wait_until(lambda: (tmp_path / 'ready').exists())
        ready = json.loads((tmp_path / 'ready').read_text())
        assert ready['pgid'] == child.pid and ready['pid'] != child.pid
        lock.close()
        with lock_path.open('a+') as contender:
            with pytest.raises(BlockingIOError):
                fcntl.flock(contender, fcntl.LOCK_EX | fcntl.LOCK_NB)
            child.kill()  # Only the runner leader; time/taskset/Python keep the FD.
            child.wait(timeout=3)
            with pytest.raises(BlockingIOError):
                fcntl.flock(contender, fcntl.LOCK_EX | fcntl.LOCK_NB)
            (tmp_path / 'release').touch()
            wait_until(lambda: not active_group(child.pid))
            fcntl.flock(contender, fcntl.LOCK_EX | fcntl.LOCK_NB)
    finally:
        lock.close()
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=3)
        wait_until(lambda: not active_group(child.pid))
