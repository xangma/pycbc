"""Exercise runner command/environment/receipt assembly with a fake child."""
import importlib.util
import fcntl
import json
import os
from pathlib import Path
import shutil
import sys

import pytest

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('run_verified', ROOT / 'run-case-verified.py')
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


@pytest.mark.parametrize('mode', ['timing', 'qualify'])
def test_runner_sanitizes_environment_and_records_worker_hash(tmp_path, monkeypatch, mode):
    for name in ('checked-inspiral.py', 'qualify-inspiral.py'):
        shutil.copyfile(ROOT / name, tmp_path / name)
    source = tmp_path / 'source'
    (source / 'bin').mkdir(parents=True)
    (source / 'bin/pycbc_inspiral').write_text('# fixture executable\n')
    bank, frame = tmp_path / 'bank.hdf', tmp_path / 'frame.gwf'
    bank.write_bytes(b'fixture bank')
    frame.write_bytes(b'fixture frame')
    config = json.loads((ROOT / 'config.json').read_text())
    config.update(common_args=[], input_files=[str(frame)])
    cfg = tmp_path / 'config.json'
    cfg.write_text(json.dumps(config))
    monkeypatch.setenv('PYCBC_TORCH_TRUSTED_ARRAYS', '1')
    monkeypatch.setenv('OMP_PLACES', 'cores')
    monkeypatch.setenv('MKL_NUM_THREADS', '64')
    monkeypatch.setenv('PYCBC_BENCHMARK_LOCK_FD', '13')
    monkeypatch.setattr(runner, 'inherited_lock_fd', lambda env: int(env['PYCBC_BENCHMARK_LOCK_FD']))
    monkeypatch.setattr(sys, 'argv', ['run-case-verified.py', '--config', str(cfg),
        '--case', 'fixture', '--mode', mode, '--scheme', 'torch:cpu:1',
        '--segment-length', '512', '--source', str(source), '--bank', str(bank)])
    monkeypatch.setattr(runner.subprocess, 'check_output', lambda cmd, **kwargs:
                        'fixture-commit\n' if 'rev-parse' in cmd else '')

    class Child:
        pid = 123

        def __init__(self, command, cwd, env, **kwargs):
            assert kwargs['pass_fds'] == (13,)
            assert 'PYCBC_BENCHMARK_LOCK_FD' not in env
            assert command[:3] == ['/usr/bin/time', '-v', '-o']
            assert command[4:7] == ['taskset', '-c', '8']
            assert command[7:9] == [sys.executable, str(tmp_path / 'checked-inspiral.py')]
            assert 'PYCBC_TORCH_TRUSTED_ARRAYS' not in env
            assert 'OMP_PLACES' not in env
            assert env['MKL_NUM_THREADS'] == '1' and env['OMP_DYNAMIC'] == 'FALSE'
            assert env['CUDA_VISIBLE_DEVICES'] == '' and env['PYTHONPATH'] == str(source)
            expected = (source / 'bin/pycbc_inspiral' if mode == 'timing'
                        else tmp_path / 'qualify-inspiral.py')
            assert command[16] == str(expected)
            (tmp_path / 'runs/fixture/runtime.json').write_text('{"state":"fixture"}')
            (tmp_path / 'runs/fixture/triggers.hdf').write_bytes(b'fixture output')

        def wait(self):
            return 0

    monkeypatch.setattr(runner.subprocess, 'Popen', Child)
    assert runner.main() == 0
    record = json.loads((tmp_path / 'runs/fixture/receipt.json').read_text())
    assert record['state'] == 'complete'
    assert record['runtime_sha256'] == runner.digest(tmp_path / 'runs/fixture/runtime.json')
    assert record['input_sha256'] == record['input_sha256_after']
    assert str(tmp_path / 'checked-inspiral.py') in record['input_sha256']


def test_inherited_lock_rejects_missing_closed_and_wrong_descriptors(tmp_path, monkeypatch):
    path = tmp_path / 'shared-lock'
    path.touch()
    monkeypatch.setattr(runner, 'LOCK', path)
    with pytest.raises(KeyError):
        runner.inherited_lock_fd({})
    for value in ('invalid', '0', '2', '-1'):
        with pytest.raises(ValueError):
            runner.inherited_lock_fd({'PYCBC_BENCHMARK_LOCK_FD': value})
    with (tmp_path / 'wrong-file').open('a+') as other:
        with pytest.raises(ValueError, match='shared lock'):
            runner.inherited_lock_fd({'PYCBC_BENCHMARK_LOCK_FD': str(other.fileno())})
    fd = os.open(path, os.O_RDWR)
    os.close(fd)
    with pytest.raises(OSError):
        runner.inherited_lock_fd({'PYCBC_BENCHMARK_LOCK_FD': str(fd)})


def test_inherited_lock_keeps_same_open_file_description(tmp_path, monkeypatch):
    path = tmp_path / 'shared-lock'
    monkeypatch.setattr(runner, 'LOCK', path)
    with path.open('a+') as held, path.open('a+') as competing:
        fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert runner.inherited_lock_fd({'PYCBC_BENCHMARK_LOCK_FD': str(held.fileno())}) == held.fileno()
        with pytest.raises(BlockingIOError):
            runner.inherited_lock_fd({'PYCBC_BENCHMARK_LOCK_FD': str(competing.fileno())})
