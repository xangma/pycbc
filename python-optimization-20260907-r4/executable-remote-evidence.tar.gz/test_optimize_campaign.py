"""Portable negative controls for the offline optimization supervisor."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest


ROOT = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def worker_fixture(monkeypatch):
    api = load('verify-api')
    compare = load('compare-candidate')
    runtime = load('checked-inspiral')
    source = '/fixture/source-candidate'
    before = dict(finished_at=1, hostname='len', sources={'candidate': {'path': source}})
    after = dict(started_at=10)
    pins = {'benchmark-squared-norm.py': 'harness', 'api-worker.py': 'worker'}
    observation = dict(time_ns=4_000_000_000, affinity=[8], smt_siblings={'8': '8,72'})
    cells = [dict(dtype=dtype, size=size, stride=stride, seconds_per_call=[0.1] * 7,
                  calls_per_sample=2, median_seconds=.1, exact_parity=True,
                  input_unchanged=True, input_sha256='a' * 64, output_sha256='b' * 64)
             for dtype, size, stride in sorted(api.CELLS)]
    value = dict(variant='baseline', base_revision=compare.BASE,
                 baseline_source_sha256=compare.MODULE_SHA['baseline'],
                 candidate_source_sha256=compare.MODULE_SHA['candidate'],
                 candidate_source=source + '/pycbc/types/array_torch.py',
                 harness_sha256='harness', threads=1, interop_threads=1, host='len', pid=30,
                 before=observation, after=dict(observation, time_ns=6_000_000_000), cells=cells,
                 thread_environment={k: '1' for k in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS',
                  'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')})
    stage = dict(state='complete', returncode=0, started=2, finished=9, pid=30, pgid=30)
    command = [compare.PYTHON, str(ROOT / 'benchmark-squared-norm.py'), '--worker',
               '--variant', 'baseline', '--baseline-source', str(ROOT / 'baseline-array-torch.py'),
               '--output', '/fixture/baseline-r1.json']
    launch = dict(pid=30, started_at=3, hostname='len', affinity=[8],
                  environment=runtime.fixed_environment(compare.read(ROOT / 'config.json'), source),
                  helper_sha256='worker', harness_sha256='harness', command=command,
                  inherited_lock=dict(fd=4, path=str(load('optimize-campaign').LOCK)))
    return api, [value, launch, stage, 'baseline', before, after, pins]


def test_complete_api_worker(worker_fixture):
    api, args = worker_fixture
    api.validate_worker(*args)


@pytest.mark.parametrize('field,bad', [
    ('threads', 2), ('interop_threads', 2), ('baseline_source_sha256', 'wrong'),
    ('candidate_source', '/other/pycbc/types/array_torch.py'), ('pid', 40),
    ('host', 'other'), ('harness_sha256', 'wrong'),
])
def test_bad_api_identity_rejected(worker_fixture, field, bad):
    api, args = worker_fixture
    args[0][field] = bad
    with pytest.raises(ValueError):
        api.validate_worker(*args)


@pytest.mark.parametrize('change', ['missing-cell', 'duplicate-cell', 'sample-count',
    'nan', 'median', 'parity', 'mutation', 'call-count', 'affinity', 'sibling',
    'environment', 'time-window', 'failed-stage', 'lock'])
def test_bad_api_evidence_rejected(worker_fixture, change):
    api, args = worker_fixture
    value, launch, stage = args[:3]
    cell = value['cells'][0]
    if change == 'missing-cell':
        value['cells'].pop()
    elif change == 'duplicate-cell':
        value['cells'][1] = copy.deepcopy(cell)
    elif change == 'sample-count':
        cell['seconds_per_call'].pop()
    elif change == 'nan':
        cell['seconds_per_call'][0] = float('nan')
    elif change == 'median':
        cell['median_seconds'] = .2
    elif change == 'parity':
        cell['exact_parity'] = False
    elif change == 'mutation':
        cell['input_unchanged'] = False
    elif change == 'call-count':
        cell['calls_per_sample'] = True
    elif change == 'affinity':
        value['after']['affinity'] = [8, 72]
    elif change == 'sibling':
        value['after']['smt_siblings'] = {'8': '8'}
    elif change == 'environment':
        launch['environment']['PYCBC_TORCH_UNREVIEWED'] = '1'
    elif change == 'time-window':
        stage['finished'] = 11
    elif change == 'failed-stage':
        stage['returncode'] = 1
    else:
        launch['inherited_lock']['path'] = '/other/lock'
    with pytest.raises(ValueError):
        api.validate_worker(*args)


@pytest.mark.parametrize('mutation', [None, 'missing-repeat', 'same-pid', 'different-input',
                                     'different-version', 'wrong-stage-command'])
def test_complete_repeat_set(worker_fixture, monkeypatch, tmp_path, mutation):
    api, args = worker_fixture
    compare = load('compare-candidate')
    runtime = load('checked-inspiral')
    monkeypatch.setattr(api, 'ROOT', tmp_path)
    monkeypatch.setattr(compare, 'validate_window', lambda *args: None)
    monkeypatch.setattr(api, 'load', lambda name, file:
                        runtime if file == 'checked-inspiral.py' else compare)
    for folder in ('api-results', 'api-launches', 'stages'):
        (tmp_path / folder).mkdir()
    (tmp_path / 'config.json').write_bytes((ROOT / 'config.json').read_bytes())
    source = args[4]['sources']['candidate']['path']
    for index, (role, repeat) in enumerate(api.ORDER):
        if mutation == 'missing-repeat' and index == 5:
            continue
        value, launch, stage = copy.deepcopy(args[:3])
        name = f'{role}-r{repeat}'
        value.update(variant=role, scope='Synthetic control only', platform='Linux',
                     python='3.11', torch='fixture', numpy='fixture')
        for record in (value, launch, stage):
            record['pid'] = 30 if mutation == 'same-pid' else 30 + index
        stage['pgid'] = stage['pid']
        output = tmp_path / 'api-results' / (name + '.json')
        launch['command'] = [compare.PYTHON, str(tmp_path / 'benchmark-squared-norm.py'),
                             '--worker', '--variant', role, '--baseline-source',
                             str(tmp_path / 'baseline-array-torch.py'), '--output', str(output)]
        stage['command'] = ['taskset', '-c', '8', compare.PYTHON, str(tmp_path / 'api-worker.py'),
                            '--source', source, '--variant', role, '--repeat', str(repeat)]
        if index == 5:
            if mutation == 'different-input':
                value['cells'][0]['input_sha256'] = 'c' * 64
            elif mutation == 'different-version':
                value['torch'] = 'another-version'
            elif mutation == 'wrong-stage-command':
                stage['command'][2] = '9'
        for path, record in [(output, value),
                             (tmp_path / 'api-launches' / (name + '.json'), launch),
                             (tmp_path / 'stages' / ('api-' + name + '.json'), stage)]:
            path.write_text(json.dumps(record))
    if mutation is None:
        summary = api.summarize(args[4], args[5], args[6])
        assert summary['workers'] == 6 and len(summary['cells']) == 18
        assert all(row['ratio'] == 1 for row in summary['cells'])
    else:
        with pytest.raises(ValueError):
            api.summarize(args[4], args[5], args[6])


def test_api_exec_preserves_descriptor_and_sanitizes_environment(tmp_path, monkeypatch):
    worker = load('api-worker')
    runtime = load('checked-inspiral')
    runner = load('run-case-verified')
    for name in ('api-results', 'api-launches'):
        (tmp_path / name).mkdir()
    for name in ('config.json', 'benchmark-squared-norm.py'):
        (tmp_path / name).write_bytes((ROOT / name).read_bytes())
    monkeypatch.setattr(worker, 'ROOT', tmp_path)
    monkeypatch.setattr(worker, 'load', lambda name, file:
                        runtime if file == 'checked-inspiral.py' else runner)
    monkeypatch.setattr(os, 'environ', {'PYCBC_TORCH_UNREVIEWED': '1', 'MKL_NUM_THREADS': '99',
                                      'PATH': '/test', 'PYCBC_BENCHMARK_LOCK_FD': '4'})
    monkeypatch.setattr(os, 'sched_getaffinity', lambda pid: {8}, raising=False)
    monkeypatch.setattr(sys, 'argv', ['worker', '--source', str(tmp_path / 'source'),
                                    '--variant', 'candidate', '--repeat', '2'])
    class ExecReached(Exception):
        pass
    with (tmp_path / 'lock').open('a+') as lock:
        monkeypatch.setattr(runner, 'inherited_lock_fd', lambda env: lock.fileno())
        def execv(python, command):
            assert os.get_inheritable(lock.fileno())
            assert 'PYCBC_BENCHMARK_LOCK_FD' not in os.environ
            assert 'PYCBC_TORCH_UNREVIEWED' not in os.environ
            assert os.environ['MKL_NUM_THREADS'] == '1'
            assert command[2:5] == ['--worker', '--variant', 'candidate']
            raise ExecReached()
        monkeypatch.setattr(os, 'execv', execv)
        with pytest.raises(ExecReached):
            worker.main()
        launch = json.loads((tmp_path / 'api-launches/candidate-r2.json').read_text())
        assert launch['pid'] == os.getpid()
        assert launch['inherited_lock']['fd'] == lock.fileno()


@pytest.mark.parametrize('mutation', [None, 'no-release', 'wrong-thread', 'wrong-profile-hash',
                                      'wrong-profile-pid', 'failed-lifecycle', 'failed-science'])
def test_profile_gate_rejects_missing_evidence(monkeypatch, tmp_path, mutation):
    campaign = load('optimize-campaign')
    monkeypatch.setattr(campaign, 'PROFILE_PID', 123)
    monkeypatch.setattr(campaign, 'ROOT', tmp_path)
    profile = tmp_path / 'profile'
    (profile / 'stages').mkdir(parents=True)
    monkeypatch.setattr(campaign, 'PROFILE', profile)
    gate = SimpleNamespace(check_predecessors=lambda: [], process_table=lambda: [],
                           validate_predecessor=lambda *args: None)
    monkeypatch.setattr(campaign, 'load', lambda *args: gate)
    status = dict(science_parity='pass', native_trace='captured', source_unchanged=True)
    lifecycle = dict(state='complete', returncode=0)
    if mutation == 'failed-science':
        status['science_parity'] = 'review'
    if mutation == 'failed-lifecycle':
        lifecycle['returncode'] = 1
    (profile / 'profile-status.json').write_text(json.dumps(status))
    (profile / 'stages/runner-self-test.json').write_text(json.dumps(lifecycle))
    release = dict(profile_root=str(profile), profile_pid=campaign.PROFILE_PID,
                   released_by_thread=campaign.PROFILER, message='Released',
                   release_received_utc='2026-09-07T12:00:00Z',
                   profile_status_sha256=campaign.control.digest(profile / 'profile-status.json'))
    if mutation == 'wrong-thread':
        release['released_by_thread'] = 'someone-else'
    if mutation == 'wrong-profile-hash':
        release['profile_status_sha256'] = 'changed'
    if mutation == 'wrong-profile-pid':
        release['profile_pid'] = 124
    if mutation != 'no-release':
        (tmp_path / 'profile-release.json').write_text(json.dumps(release))
    if mutation is None:
        assert campaign.gates()['release'] == release
    else:
        with pytest.raises((FileNotFoundError, ValueError)):
            campaign.gates()


def test_unpinned_profile_acquisition_fails_closed(monkeypatch):
    campaign = load('optimize-campaign')
    monkeypatch.setattr(campaign, 'PROFILE_PID', 0)
    with pytest.raises(ValueError, match='PID has not yet been pinned'):
        campaign.gates()


@pytest.mark.parametrize('mutation', [None, 'qualification-count', 'timing-count',
                                     'source-changed', 'changed-receipt', 'active-group'])
def test_reviewed_r4_predecessor_gate(monkeypatch, tmp_path, mutation):
    gate = load('profile-gates')
    predecessors = []
    for pid, name in ((101, 'convergence'), (102, 'r4')):
        root = tmp_path / name
        (root / 'stages').mkdir(parents=True)
        (root / 'status.json').write_text(json.dumps(dict(
            state='complete', finished=1, pid=pid, pgid=pid,
            qualifications_passed=36, timing_workers=54, source_unchanged=True)))
        (root / 'stages/worker.json').write_text(json.dumps(dict(pid=pid + 100, pgid=pid + 100)))
        predecessors.append((root, 'status.json', pid))
    monkeypatch.setattr(gate, 'PREDECESSORS', predecessors)
    processes = [dict(pid=999, pgid=202)] if mutation == 'active-group' else []
    monkeypatch.setattr(gate, 'process_table', lambda: processes)
    path = predecessors[1][0] / 'status.json'
    monkeypatch.setattr(gate, 'BATCH_STATUS_SHA256', gate.control.digest(path))
    value = json.loads(path.read_text())
    if mutation == 'qualification-count':
        value['qualifications_passed'] = 35
    elif mutation == 'timing-count':
        value['timing_workers'] = 53
    elif mutation == 'source-changed':
        value['source_unchanged'] = False
    elif mutation == 'changed-receipt':
        value['unreviewed'] = True
    if mutation not in (None, 'active-group'):
        path.write_text(json.dumps(value))
    if mutation is None:
        assert len(gate.check_predecessors()) == 2
    else:
        with pytest.raises(ValueError):
            gate.check_predecessors()


@pytest.mark.parametrize('mutation', [None, 'incomplete', 'live-supervisor', 'wrong-decision',
                                     'wrong-candidate', 'wrong-reviewer', 'empty-assessment',
                                     'changed-summary'])
def test_executable_requires_reviewed_unchanged_api_evidence(monkeypatch, tmp_path, mutation):
    campaign = load('optimize-campaign')
    compare = load('compare-candidate')
    monkeypatch.setattr(campaign, 'ROOT', tmp_path)
    monkeypatch.setattr(campaign, 'pins', lambda: {'pinned': 'helper'})
    processes = [dict(pid=30, pgid=30)] if mutation == 'live-supervisor' else []
    gate = SimpleNamespace(process_table=lambda: processes)
    monkeypatch.setattr(campaign, 'load', lambda name, file:
                        gate if file == 'profile-gates.py' else compare)
    campaign.control.save(tmp_path / 'api-summary.json', {'evidence_sha256': {}})
    sha = campaign.control.digest(tmp_path / 'api-summary.json')
    status = dict(state='complete', finished=10, pid=30, pgid=30,
                  helper_sha256={'pinned': 'helper'}, result_sha256=sha)
    review = dict(decision='proceed', reviewed_by_thread=campaign.OWNER,
                  candidate_revision=compare.CANDIDATE, api_summary_sha256=sha,
                  cutoff_assessment='Synthetic positive control', reviewed_utc='fixture')
    if mutation == 'incomplete':
        status['state'] = 'running'
    elif mutation == 'wrong-decision':
        review['decision'] = 'pending'
    elif mutation == 'wrong-candidate':
        review['candidate_revision'] = compare.BASE
    elif mutation == 'wrong-reviewer':
        review['reviewed_by_thread'] = '01a07ac4-f4e4-7792-99b5-5bd27522c961'
    elif mutation == 'empty-assessment':
        review['cutoff_assessment'] = ''
    elif mutation == 'changed-summary':
        status['result_sha256'] = 'different'
    campaign.control.save(tmp_path / 'api-status.json', status)
    campaign.control.save(tmp_path / 'api-review.json', review)
    if mutation is None:
        assert campaign.api_review() == review
    else:
        with pytest.raises(ValueError):
            campaign.api_review()
