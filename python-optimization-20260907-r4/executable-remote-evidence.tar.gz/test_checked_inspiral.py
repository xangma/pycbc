"""Synthetic worker-control tests; no Linux timing evidence is produced."""
import importlib.util
import json
from pathlib import Path
import sys
import types

import pytest

SPEC = importlib.util.spec_from_file_location(
    'checked_inspiral', Path(__file__).with_name('checked-inspiral.py'))
worker = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(worker)


def test_sanitizes_inherited_switches_and_thread_controls():
    config = json.loads(Path(__file__).with_name('config.json').read_text())
    inherited = {'PATH': '/bin', 'HOME': '/home/test', 'PYCBC_TORCH_TRUSTED_ARRAYS': '1',
                 'PYCBC_NUM_THREADS': '64', 'OMP_PLACES': 'cores', 'OMP_NUM_THREADS': '8',
                 'MKL_CBWR': 'AUTO', 'TORCHINDUCTOR_CACHE_DIR': '/tmp/cache',
                 'TORCH_NUM_INTEROP_THREADS': '64', 'CUDA_VISIBLE_DEVICES': '0',
                 'PYTHONPATH': '/other', 'PYTHONHASHSEED': '8'}
    actual = worker.clean_environment(inherited, config, '/source')
    assert worker.relevant_environment(actual) == worker.fixed_environment(config, '/source')
    assert actual['PATH'] == '/bin' and actual['HOME'] == '/home/test'
    assert not any(k.startswith('PYCBC_') for k in actual)


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    config = tmp_path / 'config.json'
    config.write_text(Path(__file__).with_name('config.json').read_text())
    source = tmp_path / 'source'
    module = source / 'pycbc/types/array_torch.py'
    module.parent.mkdir(parents=True)
    module.write_text('# fixture\n')
    environment = worker.fixed_environment(json.loads(config.read_text()), source)
    monkeypatch.setattr(worker.os, 'environ', environment)
    torch = types.SimpleNamespace(__version__='fixture', version=types.SimpleNamespace(cuda=None))
    torch.set_num_threads = lambda n: setattr(torch, 'intra', n)
    torch.set_num_interop_threads = lambda n: setattr(torch, 'inter', n)

    class Bank:
        def __getitem__(self, index):
            return index

    original = Bank.__getitem__
    modules = {'torch': torch,
               'pycbc': types.SimpleNamespace(__file__=str(source / 'pycbc/__init__.py')),
               'pycbc.types': types.SimpleNamespace(array_torch=types.SimpleNamespace(__file__=str(module))),
               'pycbc.waveform.bank': types.SimpleNamespace(FilterBank=Bank)}
    for name, value in modules.items():
        monkeypatch.setitem(sys.modules, name, value)
    count = []

    def snapshot(t):
        count.append(1)
        return dict(intra_op=t.intra, inter_op=t.inter, affinity=[8],
                    smt_siblings={'8': '8,72'}, scheme='TorchScheme', device='cpu',
                    threadpools=[{'num_threads': 1}], threadpoolctl=worker.expected_threadpoolctl(),
                    environment=worker.relevant_environment(environment),
                    observed_at=worker.time.time())

    monkeypatch.setattr(worker, 'snapshot', snapshot)
    receipt = tmp_path / 'runtime.json'
    monkeypatch.setattr(sys, 'argv', ['checked-inspiral.py', '--receipt', str(receipt),
                        '--config', str(config), '--source', str(source), '--', '/fixture'])
    return torch, Bank, original, receipt, count


def test_success_checks_first_bank_once_and_restores_hook(runtime, monkeypatch):
    torch, bank, original, receipt, count = runtime

    def workload(*args, **kwargs):
        assert torch.intra == torch.inter == 1
        assert bank()[7] == 7
        assert bank.__getitem__ is original
        assert bank()[8] == 8

    monkeypatch.setattr(worker.runpy, 'run_path', workload)
    worker.main()
    result = json.loads(receipt.read_text())
    assert result['state'] == 'complete' and len(count) == 3
    assert bank.__getitem__ is original


def test_qualification_hook_remains_active(runtime, monkeypatch):
    _, bank, original, receipt, count = runtime
    observed = []

    def workload(*args, **kwargs):
        inner = bank.__getitem__

        def qualifying(self, index):
            observed.append(index)
            return inner(self, index)

        bank.__getitem__ = qualifying
        assert bank()[0] == 0 and bank()[1] == 1
        assert bank.__getitem__ is qualifying

    monkeypatch.setattr(worker.runpy, 'run_path', workload)
    worker.main()
    assert observed == [0, 1] and len(count) == 3
    assert json.loads(receipt.read_text())['state'] == 'complete'
    assert bank.__getitem__ is original


@pytest.mark.parametrize('failure', ['no_bank', 'bad_interop', 'bad_environment', 'workload_error'])
def test_failed_runtime_never_completes(runtime, monkeypatch, failure):
    torch, bank, original, receipt, count = runtime

    def workload(*args, **kwargs):
        if failure == 'no_bank':
            return
        if failure == 'bad_interop':
            torch.inter = 2
        if failure == 'bad_environment':
            worker.os.environ['PYCBC_TORCH_TRUSTED_ARRAYS'] = '1'
        if failure == 'workload_error':
            raise RuntimeError('fixture failure')
        bank()[0]

    monkeypatch.setattr(worker.runpy, 'run_path', workload)
    with pytest.raises((ValueError, RuntimeError)):
        worker.main()
    assert json.loads(receipt.read_text())['state'] == 'failed'
    assert bank.__getitem__ is original
