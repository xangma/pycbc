#!/usr/bin/env python3
"""Collect one qualified CUDA device trace after both owned campaigns exit.

Fresh output directory only. This owns no production changes or reservations.
The Linux flock descriptor is inherited by stage wrappers and science workers;
it is closed only after all owned stage process groups have been cleaned up.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import campaign_controls as control


ROOT = Path(__file__).resolve().parent
REFERENCE = Path('/home/xangma/pycbc-torch-reference-protocol-20260907')
BATCH = Path('/home/xangma/pycbc-torch-current-batch-sweep-20260907-r4')
CONVERGENCE = Path('/home/xangma/pycbc-torch-convergence-20260907')
SOURCE = BATCH / 'source'
REVISION = '9578a710479b924e882857c4dffab6ed372a634b'
BATCH_STATUS_SHA256 = 'a19f0d8862c7a05be182cfa3e8031ac3fe919ff210b7abede1490166adf40d32'
LOCK = Path('/home/xangma/pycbc-torch-performance-coordination-20260907/len-benchmark.lock')
PREDECESSORS = [(CONVERGENCE, 'convergence-status.json', 340874),
                (BATCH, 'batch-status.json', 3789112)]


def process_table(proc=Path('/proc')):
    result = []
    for path in proc.iterdir():
        if not path.name.isdigit():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if fields[0] != 'Z':
                result.append(dict(pid=int(path.name), ppid=int(fields[1]),
                                   pgid=int(fields[2]), start_ticks=int(fields[19])))
        except FileNotFoundError:
            continue
    return result


class NotReady(ValueError):
    pass


def validate_predecessor(status, expected_pid, live, owned_groups):
    if status.get('pid') != expected_pid:
        raise ValueError('Predecessor identity differs from the coordination record')
    if status.get('state') in ('starting', 'waiting', 'running'):
        raise NotReady('Predecessor has not finished')
    if status.get('state') != 'complete' or not status.get('finished'):
        raise ValueError('Predecessor is not successfully terminal; inspect it first')
    owned_pids = {expected_pid, status.get('child_pid')}
    groups = set(owned_groups) | {status.get('pgid'), status.get('child_pgid')}
    if any(p['pid'] in owned_pids or p['pgid'] in groups for p in live):
        raise NotReady('Predecessor still has an active owned process/group')


def check_predecessors():
    live = process_table()
    result = []
    for root, filename, pid in PREDECESSORS:
        status = control.read(root / filename)
        groups = {pid}
        for receipt in (root / 'stages').glob('*.json'):
            value = control.read(receipt)
            groups.update(value.get(key) for key in ('pid', 'pgid'))
        validate_predecessor(status, pid, live, groups)
        result.append(dict(path=str(root / filename), status=status,
                           sha256=control.digest(root / filename),
                           owned_groups=sorted(g for g in groups if g)))
    batch_status = result[1]['status']
    if (batch_status.get('qualifications_passed') != 36 or
            batch_status.get('timing_workers') != 54 or
            batch_status.get('source_unchanged') is not True):
        raise ValueError('Batch campaign lacks its final qualification/timing gates')
    if result[1]['sha256'] != BATCH_STATUS_SHA256:
        raise ValueError('Batch completion differs from the reviewed R4 receipt')
    return result


class Campaign(control.Campaign):
    def update(self, **values):
        self.state.update(values)
        control.save(self.root / 'profile-status.json', self.state)

    def observe(self):
        with (self.root / 'host-samples.jsonl').open('x') as stream:
            while not self.stop.is_set():
                value = dict(utc=time.time(), monotonic_ns=time.monotonic_ns(),
                             phase=self.state.get('current'),
                             child_pid=self.state.get('child_pid'))
                for name in ('stat', 'loadavg', 'meminfo'):
                    value['proc_' + name] = Path('/proc', name).read_text()
                for name, command in [
                    ('processes', ['ps', '-eo', 'pid,ppid,psr,nlwp,pcpu,pmem,comm',
                                   '--sort=-pcpu']),
                    ('gpu', ['nvidia-smi', '--query-gpu=timestamp,name,utilization.gpu,'
                             'utilization.memory,memory.used,memory.free,power.draw',
                             '--format=csv,noheader,nounits'])]:
                    try:
                        value[name] = subprocess.check_output(
                            command, text=True, timeout=3, stderr=subprocess.DEVNULL)
                    except (OSError, subprocess.SubprocessError) as exc:
                        value[name + '_error'] = repr(exc)
                stream.write(json.dumps(value) + '\n')
                stream.flush()
                self.stop.wait(5)

    def case(self, name, mode, scheme='torch:cuda:0'):
        self.stage(name, [sys.executable, ROOT / 'run-case.py',
                         '--config', ROOT / 'config.json', '--case', name,
                         '--mode', mode, '--scheme', scheme,
                         '--source', SOURCE, '--bank', REFERENCE / 'inputs/bank-compressed.hdf',
                         '--segment-length', '512', '--start-pad', '112', '--end-pad', '16'])
        folder = ROOT / 'runs' / name
        r = control.read(folder / 'receipt.json')
        if (r['state'] != 'complete' or r['returncode'] != 0 or
                r['input_sha256'] != r['input_sha256_after'] or
                r['source_info']['commit'] != REVISION or
                r['source_info']['status'] or r['source_status_after']):
            raise ValueError('Run source/input/completion receipt failed')
        if r['trigger_sha256'] != control.digest(folder / 'triggers.hdf'):
            raise ValueError('Trigger receipt hash mismatch')
        runtime = r.get('runtime', {})
        if runtime.get('state') != 'complete':
            raise ValueError('Missing successful worker runtime receipt')
        for key in ('before_executable', 'at_first_bank', 'after_executable'):
            value = runtime.get(key, {})
            if (value.get('intra_op') != 1 or value.get('inter_op') != 1 or
                    value.get('affinity') != [8] or
                    value.get('smt_siblings') != {'8': '8,72'}):
                raise ValueError('Worker thread/affinity receipt differs')
        return folder


def run(campaign):
    source = control.source_record(SOURCE, REVISION)
    manifest = control.read(ROOT / 'staged-helpers.json')
    if manifest != {name: control.digest(ROOT / name) for name in manifest}:
        raise ValueError('Staged helper manifest changed')
    native = control.read(ROOT / 'native-provenance.json')
    pins = [ROOT / name for name in manifest]
    pins += [SOURCE / e['relative_path'] for e in native['extensions']]
    pins += [REFERENCE / 'inputs/bank-compressed.hdf']
    cfg = control.read(ROOT / 'config.json')
    if cfg['core'] != 8:
        raise ValueError('Frozen CPU affinity differs')
    for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS'):
        if cfg['environment'].get(key) != '1':
            raise ValueError('Frozen numerical thread setting differs: ' + key)
    if any(cfg['environment'].get(key) != 'FALSE' for key in ('MKL_DYNAMIC', 'OMP_DYNAMIC')):
        raise ValueError('Dynamic numerical threads must be disabled')
    pins += list(map(Path, cfg['input_files']))
    before = {str(p): control.digest(p) for p in pins}
    expected_inputs = {
        str(REFERENCE / 'inputs/bank-compressed.hdf'): '26050d48322a1d71092bb0e024e71a89ace56b3e7b1c5e4cf20c7b769213fb7f',
        '/home/xangma/pycbc_bench_repo/docs/_include/H-H1_LOSC_CLN_4_V1-1187007040-2048.gwf': '580e238054474fd09be900c47217bbcd0497ab84d1756f886647e934352e4865',
    }
    if any(before.get(name) != sha for name, sha in expected_inputs.items()):
        raise ValueError('Bank/frame differs from the frozen reference inputs')
    for entry in native['extensions']:
        if before[str(SOURCE / entry['relative_path'])] != entry['sha256']:
            raise ValueError('Native extension differs from qualified provenance')
    control.save(ROOT / 'provenance.json', dict(source=source, sha256=before,
                                               native=native, profiler_revision='dc6c3ed48a'))
    campaign.stage('runner-self-test', [sys.executable, ROOT / 'test-profile-campaign.py', '-v'])
    qualified = campaign.case('qualify-current-cuda', 'qualify')
    control.qualify(qualified / 'qualification.json', 384,
                    before[str(REFERENCE / 'inputs/bank-compressed.hdf')])
    cpu = campaign.case('unprofiled-current-cpu', 'timing', 'cpu:1')
    baseline = campaign.case('unprofiled-current-cuda', 'timing')
    trace = campaign.case('trace-current-cuda', 'cuda-trace')
    if campaign.compare('current-parity', baseline / 'triggers.hdf',
                        [qualified / 'triggers.hdf', trace / 'triggers.hdf']) != 'pass':
        raise ValueError('Trace/qualification differs scientifically from current reference')
    if campaign.compare('corrected-science-parity',
                        cpu / 'triggers.hdf',
                        [baseline / 'triggers.hdf']) != 'pass':
        raise ValueError('Current reference differs from corrected scientific baseline')
    campaign.stage('analyze-trace', [sys.executable, ROOT / 'summarize_torch_trace.py',
                                   trace / 'trace/trace.json', '--receipt',
                                   trace / 'trace/receipt.json', '--output',
                                   ROOT / 'device-attribution.json'])
    if before != {str(p): control.digest(p) for p in pins}:
        raise ValueError('Pinned source/native/input/helper changed during acquisition')
    control.source_record(SOURCE, REVISION)
    control.save(ROOT / 'provenance-after.json', dict(sha256=before, source_unchanged=True))
    campaign.update(state='complete', current=None, command=None, finished=time.time(),
                    science_parity='pass', native_trace='captured', source_unchanged=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--shared-host', action='store_true')
    args = parser.parse_args()
    if not args.shared_host or not sys.platform.startswith('linux'):
        parser.error('Linux and explicit --shared-host are required')
    check_predecessors()
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    # Do not LOCK_UN explicitly: descendants inherit this open file description,
    # so the lock survives a supervisor SIGKILL until the last worker exits.
    with LOCK.open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        predecessors = check_predecessors()
        (ROOT / 'stages').mkdir(exist_ok=False)
        (ROOT / 'runs').mkdir(exist_ok=False)
        for key in list(os.environ):
            if key.startswith('PYCBC_TORCH_') or key in (
                    'PYCBC_ENABLE_CUDA_GRAPHS', 'PYCBC_BATCH_MAXELEMENTS'):
                del os.environ[key]
        os.environ['PYCBC_BENCHMARK_LOCK_FD'] = str(lock.fileno())
        campaign = Campaign(ROOT, timeout=900)
        interrupted = False

        def stop(signum, frame):
            nonlocal interrupted
            if not interrupted:
                interrupted = True
                if control._stop_deferrals:
                    control._pending_stop = signum
                else:
                    raise control.Cancelled(f'Received signal {signum}')

        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, stop)
        campaign.update(lock=str(LOCK), lock_fd=lock.fileno(),
                        affinity=sorted(os.sched_getaffinity(0)),
                        numerical_worker_core=8, smt_sibling=72,
                        predecessors=predecessors, next_check_seconds=60)
        campaign.observer = threading.Thread(target=campaign.observe, daemon=True)
        campaign.observer.start()
        try:
            run(campaign)
        except BaseException as exc:
            campaign.update(state='cancelled' if isinstance(exc, control.Cancelled) else 'failed',
                            error=repr(exc), finished=time.time())
            raise
        finally:
            campaign.stop.set()
            campaign.observer.join(timeout=10)


if __name__ == '__main__':
    main()
