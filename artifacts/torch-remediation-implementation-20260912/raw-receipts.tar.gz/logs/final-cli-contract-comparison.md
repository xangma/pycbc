Offline campaign comparison: **PASS**

Exact trigger identity, schema, scientific metadata, and input content checks are separate from floating-point error gates.

Explicit PyCBC contract mode: derived complex-SNR absolute error ≤ 0.001; existing circular phase absolute error ≤ 0.001 radians; power chi-square atol=rtol=0.0001. Raw phase differences remain diagnostic. Source revisions are recorded in the JSON.

Apply these existing criteria to accepted stored triggers only. Other nonidentical floating fields remain unassessed. Derived complex SNR is snr * exp(i * coa_phase), evaluated in float64. This does not reproduce the full-time-series independent-oracle qualification required by the source document.

- native_cuda: triggers per shard [1, 1]; persistent worker True; second-shard batch hits 1.
- reference_cuda: triggers per shard [1, 1]; persistent worker True; second-shard batch hits 0.
- reference_cpu: triggers per shard [1, 1]; persistent worker True; second-shard batch hits 0.

Unassessed numeric field comparisons: 0.

| Comparison | Identity | Field failures | Unassessed |
| --- | --- | ---: | ---: |
| native_cuda:0 vs reference_cuda:0 | PASS | 0 | 0 |
| native_cuda:1 vs reference_cuda:1 | PASS | 0 | 0 |
| native_cuda:0 vs reference_cpu:0 | PASS | 0 | 0 |
| native_cuda:1 vs reference_cpu:1 | PASS | 0 | 0 |
| reference_cuda:0 vs reference_cpu:0 | PASS | 0 | 0 |
| reference_cuda:1 vs reference_cpu:1 | PASS | 0 | 0 |
| native_cuda:1 vs native_cuda:0 | PASS | 0 | 0 |
| reference_cuda:1 vs reference_cuda:0 | PASS | 0 | 0 |
| reference_cpu:1 vs reference_cpu:0 | PASS | 0 | 0 |

Maximum raw error across all compared shards:

| Field | Maximum absolute error | Maximum relative error* |
| --- | ---: | ---: |
| H1/bank_chisq | 0 | n/a |
| H1/bank_chisq_dof | 0 | n/a |
| H1/chisq | 0.000291824341 | 1.19649787e-05 |
| H1/chisq_dof | 0 | 0 |
| H1/coa_phase | 2.32830644e-10 | 9.28999538e-08 |
| H1/cont_chisq | 0 | n/a |
| H1/cont_chisq_dof | 0 | n/a |
| H1/derived_complex_snr | 4.01581062e-08 | 2.32830644e-10 |
| H1/end_time | 0 | 0 |
| H1/sg_chisq | 0 | n/a |
| H1/sigmasq | 0 | 0 |
| H1/snr | 0 | 0 |
| H1/template_duration | 0 | 0 |
| H1/template_hash | 0 | 0 |

*Relative error excludes zero-valued reference elements; the JSON reports their mismatches separately. Phase errors above use direct subtraction; wrapped phase diagnostics are also recorded.

Numeric errors, missing/extra identities, duplicates, per-field gate rules, cache counters, argv, and file SHA256 values are in the JSON report. No acceptance tolerance is inferred.

- Input files are hashed at comparison time; receipts do not attest their content at execution time.
- Receipt flags describe requested provider; batch cache hits support native batch-path execution, but receipts do not enumerate per-row providers.
- Two repeated fixture shards do not establish general scientific or performance qualification.
